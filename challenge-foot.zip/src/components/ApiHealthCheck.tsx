import React, { useState, useEffect } from 'react';
import {
  Server,
  Wifi,
  WifiOff,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Key,
  Database,
  Activity,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  Clock,
  Zap,
} from 'lucide-react';

export interface ApiHealthData {
  success: boolean;
  server: {
    reachable: boolean;
    status: string;
    app: string;
    version: string;
    uptimeSeconds: number;
    timestamp: string;
    nodeVersion: string;
    memoryUsage: {
      rssMb: number;
      heapUsedMb: number;
    };
    database: {
      usersCount: number;
      challengesCount: number;
      predictionsCount: number;
      auditLogsCount: number;
      transactionsCount: number;
    };
  };
  apiFootball: {
    configured: boolean;
    status: 'healthy' | 'missing' | 'invalid_key' | 'network_error' | 'error';
    message: string;
    keyMasked: string | null;
    account?: {
      firstname?: string;
      lastname?: string;
      email?: string;
    } | null;
    subscription?: {
      plan?: string;
      end?: string;
      active?: boolean;
    } | null;
    requests?: {
      current?: number;
      limit_day?: number;
    } | null;
    latencyMs?: number | null;
    testedAt: string;
    errors?: any;
  };
}

export const ApiHealthCheck: React.FC = () => {
  const [data, setData] = useState<ApiHealthData | null>(null);
  const [loading, setLoading] = useState(true);
  const [testingCustomKey, setTestingCustomKey] = useState(false);
  const [customKeyInput, setCustomKeyInput] = useState('');
  const [customKeyResult, setCustomKeyResult] = useState<any | null>(null);
  const [showCustomTester, setShowCustomTester] = useState(false);
  const [lastCheckTime, setLastCheckTime] = useState<Date | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchHealth = async () => {
    setLoading(true);
    setErrorMsg(null);
    const start = performance.now();
    try {
      const res = await fetch('/api/admin/api-health', {
        headers: { 'Cache-Control': 'no-cache' },
      });
      if (!res.ok) {
        throw new Error(`Erreur HTTP ${res.status}`);
      }
      const json: ApiHealthData = await res.json();
      setData(json);
      setLastCheckTime(new Date());
    } catch (err: any) {
      setErrorMsg(err.message || 'Impossible de joindre le serveur backend');
    } finally {
      setLoading(false);
    }
  };

  const testApiKey = async (keyToTest?: string) => {
    setTestingCustomKey(true);
    try {
      const res = await fetch('/api/admin/api-health/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: keyToTest || undefined }),
      });
      const json = await res.json();
      if (keyToTest) {
        setCustomKeyResult(json.apiFootball);
      } else {
        // Refreshed normal key
        if (json.success && json.apiFootball) {
          setData((prev) => (prev ? { ...prev, apiFootball: json.apiFootball } : null));
          setLastCheckTime(new Date());
        }
      }
    } catch (err: any) {
      if (keyToTest) {
        setCustomKeyResult({
          status: 'network_error',
          message: err.message,
        });
      }
    } finally {
      setTestingCustomKey(false);
    }
  };

  const [savingKey, setSavingKey] = useState(false);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);
  const [syncingScores, setSyncingScores] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  const handleSaveKey = async (keyToSave: string) => {
    setSavingKey(true);
    setSaveFeedback(null);
    try {
      const res = await fetch('/api/admin/api-football/save-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: keyToSave }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Erreur lors de l\'enregistrement de la clé');
      }
      setSaveFeedback('Clé officielle enregistrée avec succès dans .env et active immédiatement !');
      await fetchHealth();
      setCustomKeyResult(null);
      setCustomKeyInput('');
    } catch (err: any) {
      setSaveFeedback(`Échec : ${err.message}`);
    } finally {
      setSavingKey(false);
    }
  };

  const handleSyncScores = async () => {
    setSyncingScores(true);
    setSyncFeedback(null);
    try {
      const res = await fetch('/api/admin/football/sync-challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Erreur lors de la synchronisation');
      }
      setSyncFeedback(json.message || `${json.updatedCount} matchs synchronisés`);
      await fetchHealth();
    } catch (err: any) {
      setSyncFeedback(`Échec : ${err.message}`);
    } finally {
      setSyncingScores(false);
    }
  };

  useEffect(() => {
    fetchHealth();
    // Auto-refresh every 45 seconds to monitor server availability
    const interval = setInterval(fetchHealth, 45000);
    return () => clearInterval(interval);
  }, []);

  const formatUptime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hrs > 0) return `${hrs}h ${mins}m ${secs}s`;
    if (mins > 0) return `${mins}m ${secs}s`;
    return `${secs}s`;
  };

  const isServerReachable = !errorMsg && data?.server?.reachable;
  const isApiFootballConfigured = data?.apiFootball?.configured && data?.apiFootball?.status === 'healthy';

  const requestsCurrent = data?.apiFootball?.requests?.current ?? 0;
  const requestsLimit = data?.apiFootball?.requests?.limit_day ?? 100;
  const quotaPercent = Math.min(100, Math.round((requestsCurrent / Math.max(1, requestsLimit)) * 100));

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white tracking-tight">
                État de Santé Système & API Football
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                Diagnostic Temps Réel
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Surveillance continue de la disponibilité du serveur et de la clé d'API officielle API-Football (API-Sports).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {lastCheckTime && (
            <span className="text-[11px] text-slate-500 flex items-center gap-1 font-mono">
              <Clock className="w-3 h-3" />
              {lastCheckTime.toLocaleTimeString()}
            </span>
          )}
          <button
            onClick={() => fetchHealth()}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition disabled:opacity-50 cursor-pointer"
            title="Rafraîchir le statut"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-emerald-400' : ''}`} />
            <span>{loading ? 'Contrôle...' : 'Tester'}</span>
          </button>
        </div>
      </div>

      {/* Main 2-Column Grid: Server Reachability & API-Football Configuration */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. BACKEND SERVER STATUS CARD */}
        <div
          className={`rounded-xl border p-4.5 transition-all ${
            isServerReachable
              ? 'bg-slate-950/70 border-emerald-500/30'
              : 'bg-red-950/20 border-red-500/30'
          }`}
        >
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  isServerReachable
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-red-500/20 text-red-400 border border-red-500/30'
                }`}
              >
                <Server className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                  Serveur Backend Node.js
                </span>
                <span className="text-sm font-semibold text-white">
                  {data?.server?.app || 'Challenge Foot Express'}
                </span>
              </div>
            </div>

            <span
              className={`inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border ${
                isServerReachable
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-red-500/10 text-red-400 border-red-500/30'
              }`}
            >
              {isServerReachable ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>Accessible & En Ligne</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5" />
                  <span>Injoignable</span>
                </>
              )}
            </span>
          </div>

          {errorMsg ? (
            <div className="mt-3 p-3 rounded-lg bg-red-900/30 border border-red-500/30 text-xs text-red-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{errorMsg}</span>
            </div>
          ) : (
            data?.server && (
              <div className="grid grid-cols-2 gap-2.5 pt-2 text-xs">
                <div className="bg-slate-900/90 rounded-lg p-2.5 border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">Uptime Processus</span>
                  <span className="font-mono font-bold text-white text-xs">
                    {formatUptime(data.server.uptimeSeconds)}
                  </span>
                </div>
                <div className="bg-slate-900/90 rounded-lg p-2.5 border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">Mémoire RSS</span>
                  <span className="font-mono font-bold text-white text-xs">
                    {data.server.memoryUsage.rssMb} Mo
                  </span>
                </div>
                <div className="bg-slate-900/90 rounded-lg p-2.5 border border-slate-800 col-span-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                    <span className="flex items-center gap-1">
                      <Database className="w-3 h-3 text-cyan-400" /> Base de Données Persistante
                    </span>
                    <span className="text-emerald-400 font-mono font-bold">Connectée</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-300">
                    <span>
                      {data.server.database.usersCount} utilisateurs • {data.server.database.challengesCount} challenge(s)
                    </span>
                    <span>
                      {data.server.database.predictionsCount} pronostics • {data.server.database.auditLogsCount} logs audit
                    </span>
                  </div>
                </div>
              </div>
            )
          )}
        </div>

        {/* 2. API-FOOTBALL CONFIGURATION & CONNECTION CARD */}
        <div
          className={`rounded-xl border p-4.5 transition-all ${
            isApiFootballConfigured
              ? 'bg-slate-950/70 border-emerald-500/30'
              : data?.apiFootball?.configured
              ? 'bg-amber-950/20 border-amber-500/30'
              : 'bg-red-950/20 border-red-500/30'
          }`}
        >
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  isApiFootballConfigured
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                }`}
              >
                <Key className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                  Intégration API-Football
                </span>
                <span className="text-sm font-semibold text-white">
                  v3.football.api-sports.io
                </span>
              </div>
            </div>

            <span
              className={`inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full border ${
                isApiFootballConfigured
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : data?.apiFootball?.configured
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  : 'bg-red-500/10 text-red-400 border-red-500/30'
              }`}
            >
              {isApiFootballConfigured ? (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Clé Configurée & Valide</span>
                </>
              ) : data?.apiFootball?.configured ? (
                <>
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Erreur API ({data?.apiFootball?.status})</span>
                </>
              ) : (
                <>
                  <XCircle className="w-3.5 h-3.5 text-red-400" />
                  <span>Clé Absente</span>
                </>
              )}
            </span>
          </div>

          {/* Details */}
          <div className="space-y-2.5 pt-1 text-xs">
            {/* Variable Status */}
            <div className="bg-slate-900/90 rounded-lg p-2.5 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-400 block">Variable d'environnement</span>
                <span className="font-mono font-bold text-white text-xs">API_FOOTBALL_KEY</span>
              </div>
              <div className="text-right">
                {data?.apiFootball?.keyMasked ? (
                  <span className="font-mono text-emerald-400 text-xs px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
                    {data.apiFootball.keyMasked}
                  </span>
                ) : (
                  <span className="text-red-400 text-xs font-medium">Non définie</span>
                )}
              </div>
            </div>

            {/* Account & Subscription Info */}
            {data?.apiFootball?.account && (
              <div className="bg-slate-900/90 rounded-lg p-2.5 border border-slate-800 grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-400 block">Titulaire Compte</span>
                  <span className="text-white font-medium truncate block">
                    {data.apiFootball.account.firstname} {data.apiFootball.account.lastname}
                  </span>
                  <span className="text-slate-400 text-[10px] truncate block">
                    {data.apiFootball.account.email}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Forfait & Latence</span>
                  <span className="text-emerald-400 font-semibold">
                    {data.apiFootball.subscription?.plan || 'Free'} (Actif)
                  </span>
                  {data.apiFootball.latencyMs !== null && (
                    <span className="text-cyan-400 text-[10px] block font-mono">
                      Ping: {data.apiFootball.latencyMs} ms
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Quota Gauge */}
            {data?.apiFootball?.requests && (
              <div className="bg-slate-900/90 rounded-lg p-2.5 border border-slate-800">
                <div className="flex items-center justify-between text-[11px] mb-1">
                  <span className="text-slate-400">Quota Quotidien (API-Sports)</span>
                  <span className="font-mono font-bold text-white">
                    {requestsCurrent} / {requestsLimit} requêtes
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ${
                      quotaPercent > 90
                        ? 'bg-red-500'
                        : quotaPercent > 70
                        ? 'bg-amber-500'
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${Math.max(4, quotaPercent)}%` }}
                  />
                </div>
              </div>
            )}

            {/* Status message or error */}
            {data?.apiFootball?.message && (
              <div
                className={`text-[11px] px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 ${
                  isApiFootballConfigured
                    ? 'bg-emerald-950/30 text-emerald-300 border-emerald-500/20'
                    : 'bg-red-950/30 text-red-300 border-red-500/20'
                }`}
              >
                {isApiFootballConfigured ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                )}
                <span className="truncate">{data.apiFootball.message}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Diagnostics & Manual Testing Drawer */}
      <div className="border-t border-slate-800 pt-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-slate-400">
          <Zap className="w-4 h-4 text-amber-400" />
          <span>
            Sécurité : la clé est hébergée sur le serveur privé sécurisé et jamais exposée dans le navigateur ou dans l'APK.
          </span>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button
            onClick={() => setShowCustomTester(!showCustomTester)}
            className="text-slate-400 hover:text-slate-200 underline font-medium text-xs cursor-pointer"
          >
            {showCustomTester ? 'Masquer le testeur' : 'Tester une autre clé...'}
          </button>
          <button
            onClick={() => handleSyncScores()}
            disabled={syncingScores || !isApiFootballConfigured}
            className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer disabled:opacity-50"
            title="Synchroniser les scores des matchs avec API-Sports"
          >
            <Activity className={`w-3.5 h-3.5 ${syncingScores ? 'animate-spin' : ''}`} />
            <span>{syncingScores ? 'Synchronisation...' : 'Synchroniser scores officiels'}</span>
          </button>
          <button
            onClick={() => testApiKey()}
            disabled={testingCustomKey}
            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${testingCustomKey ? 'animate-spin' : ''}`} />
            <span>Tester ping direct API</span>
          </button>
        </div>

        {syncFeedback && (
          <div className="mt-2 p-2.5 rounded-lg bg-blue-950/40 border border-blue-500/30 text-blue-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
            <span>{syncFeedback}</span>
          </div>
        )}
      </div>

      {/* Optional Custom Key Testing Panel */}
      {showCustomTester && (
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider">
            Vérification & Déploiement d'une clé API-Football alternative
          </h4>
          <p className="text-xs text-slate-400">
            Vous pouvez tester une nouvelle clé API-Football ici pour vérifier instantanément sa validité auprès des serveurs api-sports.io avant de l'enregistrer dans la configuration du serveur.
          </p>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={customKeyInput}
              onChange={(e) => setCustomKeyInput(e.target.value)}
              placeholder="Collez votre clé API (ex: 7b56027b2d3d0c8871968e2aefc97e4b)"
              className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-emerald-500"
            />
            <button
              onClick={() => testApiKey(customKeyInput.trim())}
              disabled={testingCustomKey || !customKeyInput.trim()}
              className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition disabled:opacity-50 cursor-pointer"
            >
              {testingCustomKey ? 'Test en cours...' : 'Valider auprès d\'API-Sports'}
            </button>
          </div>

          {saveFeedback && (
            <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{saveFeedback}</span>
            </div>
          )}

          {customKeyResult && (
            <div
              className={`p-3 rounded-lg border text-xs space-y-2.5 ${
                customKeyResult.status === 'healthy'
                  ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-200'
                  : 'bg-red-950/40 border-red-500/30 text-red-200'
              }`}
            >
              <div className="flex items-center gap-2 font-bold mb-1">
                {customKeyResult.status === 'healthy' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-400" />
                )}
                <span>Résultat : {customKeyResult.status}</span>
              </div>
              <p>{customKeyResult.message}</p>
              {customKeyResult.account && (
                <p className="font-mono text-[11px] text-slate-300">
                  Titulaire : {customKeyResult.account.firstname} {customKeyResult.account.lastname} (
                  {customKeyResult.account.email}) • Forfait :{' '}
                  {customKeyResult.subscription?.plan || 'Free'}
                </p>
              )}

              {/* Action to save valid key permanently to backend .env */}
              {customKeyResult.status === 'healthy' && customKeyInput.trim() && (
                <div className="pt-2 border-t border-emerald-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <span className="text-[11px] text-emerald-300">
                    Cette clé est valide et authentifiée auprès d'API-Sports.
                  </span>
                  <button
                    onClick={() => handleSaveKey(customKeyInput.trim())}
                    disabled={savingKey}
                    className="px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs transition cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{savingKey ? 'Enregistrement...' : 'Enregistrer comme clé officielle du serveur'}</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
