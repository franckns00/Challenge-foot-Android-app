import React from 'react';
import { useI18n } from '../i18n';
import { Logo } from './Logo';
import { User } from '../types';
import {
  Home,
  Trophy,
  Calendar,
  CheckSquare,
  BarChart3,
  Award,
  Activity,
  Wallet,
  ArrowUpRight,
  History,
  UserCheck,
  Megaphone,
  Handshake,
  BookOpen,
  Info,
  Settings,
  Download,
  HelpCircle,
  Shield,
  X,
  LogOut,
  ChevronRight,
  Crown,
} from 'lucide-react';

interface MenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenDownload: () => void;
  user: User | null;
  onLogout: () => void;
}

export const MenuDrawer: React.FC<MenuDrawerProps> = ({
  isOpen,
  onClose,
  currentView,
  onNavigate,
  onOpenDownload,
  user,
  onLogout,
}) => {
  const { t } = useI18n();

  if (!isOpen) return null;

  const menuSections = [
    {
      title: 'Compétition & Pronostics',
      items: [
        { id: 'home', label: t('menu.home'), icon: Home },
        { id: 'challenges', label: 'Grille des 10 Matchs', icon: Trophy },
        { id: 'challenge-live', label: 'Challenge Live (10 Matchs en Direct)', icon: Activity, highlight: true },
        { id: 'stats', label: 'Classements des Championnats', icon: BarChart3 },
        { id: 'my-predictions', label: t('menu.my_predictions'), icon: CheckSquare },
        { id: 'club', label: 'Club Challenge Foot (VIP)', icon: Crown, highlight: true },
        { id: 'leaderboard', label: t('menu.leaderboard'), icon: Award },
        { id: 'rewards', label: t('menu.rewards'), icon: Award },
      ],
    },
    {
      title: 'Finances & Portefeuille (Mode Test)',
      items: [
        { id: 'wallet', label: t('menu.wallet'), icon: Wallet },
        { id: 'withdraw', label: t('menu.withdraw'), icon: ArrowUpRight },
        { id: 'history', label: t('menu.history'), icon: History },
      ],
    },
    {
      title: 'Application & Promotion',
      items: [
        { id: 'advertising', label: t('menu.advertising'), icon: Megaphone, highlight: true },
        { id: 'download', label: t('menu.download_app'), icon: Download, isAction: true },
        { id: 'partnership', label: t('menu.partnership'), icon: Handshake },
      ],
    },
    {
      title: 'Compte & Informations',
      items: [
        { id: 'profile', label: t('menu.profile'), icon: UserCheck },
        { id: 'rules', label: t('menu.rules'), icon: BookOpen },
        { id: 'about', label: t('menu.about'), icon: Info },
        { id: 'settings', label: t('menu.settings'), icon: Settings },
        { id: 'support', label: t('menu.support'), icon: HelpCircle },
      ],
    },
  ];

  const handleItemClick = (item: any) => {
    if (item.id === 'download') {
      onOpenDownload();
      onClose();
    } else {
      onNavigate(item.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity duration-300"
        onClick={onClose}
      />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-sm sm:max-w-md bg-[#07101F] border-l border-slate-800 shadow-2xl flex flex-col h-full">
          {/* Drawer Header */}
          <div className="p-4 sm:p-5 border-b border-slate-800/80 flex items-center justify-between">
            <Logo size="sm" />
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* User Quick Info if logged in */}
          {user && (
            <div className="px-5 py-3 bg-[#0D1C34] border-b border-slate-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-white">{user.fullName}</p>
                <p className="text-[11px] text-slate-400 font-mono">{user.phone}</p>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 uppercase font-semibold">Solde Test</span>
                <p className="text-xs font-mono font-bold text-[#38BDF8] tabular-nums">
                  {user.balance.toLocaleString()} HTG
                </p>
              </div>
            </div>
          )}

          {/* Drawer Scrollable Content */}
          <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
            {menuSections.map((sec, idx) => (
              <div key={idx} className="space-y-1">
                <p className="px-3 text-[10px] uppercase font-bold tracking-wider text-slate-400">
                  {sec.title}
                </p>
                <div className="space-y-0.5">
                  {sec.items.map((item) => {
                    const Icon = item.icon;
                    const isActive = currentView === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleItemClick(item)}
                        className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left cursor-pointer group ${
                          isActive
                            ? 'bg-[#0B61DF] text-white font-semibold'
                            : item.highlight
                            ? 'bg-blue-500/10 text-[#38BDF8] border border-blue-500/30 hover:bg-blue-500/20'
                            : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Icon
                            className={`w-4 h-4 shrink-0 ${
                              isActive
                                ? 'text-white'
                                : item.highlight
                                ? 'text-[#38BDF8]'
                                : 'text-slate-400 group-hover:text-white'
                            }`}
                          />
                          <span className="truncate">{item.label}</span>
                        </div>
                        <ChevronRight
                          className={`w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 ${
                            isActive ? 'text-white' : 'text-slate-600'
                          }`}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}

            {/* Admin entry shortcut */}
            {user?.role === 'admin' && (
              <div className="pt-2 border-t border-slate-800">
                <button
                  onClick={() => {
                    onNavigate('admin');
                    onClose();
                  }}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 text-xs font-bold transition-all text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <Shield className="w-4 h-4 text-amber-400" />
                    <span>{t('admin.title')}</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>

          {/* Drawer Footer */}
          <div className="p-4 border-t border-slate-800/80 bg-[#07101F]">
            {user ? (
              <button
                onClick={() => {
                  onLogout();
                  onClose();
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 text-xs font-semibold transition-all cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>{t('nav.logout')}</span>
              </button>
            ) : (
              <div className="text-center text-[11px] text-slate-400">
                Challenge Foot v1.2.0 · Pwouve ou konn foutbòl.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
