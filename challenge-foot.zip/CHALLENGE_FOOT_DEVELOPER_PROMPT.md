# 📋 PROMPT DÉVELOPPEUR OFFICIEL — CHALLENGE FOOT
**Version :** 2.4.0 — Spécifications Fondateur & Architecture Système  
**Application :** Challenge Foot (`ht.challengefoot.app`)  
**Devises :** Gourde Haïtienne (HTG) — MonCash & Natcash  

---

## 1. VISION & DIRECTIVES FONDAMENTALES

1. **Application Réelle & Installable :**
   - Application Android native (`ht.challengefoot.app`) et Web App PWA réactive, sans simulation de données ni faux états.
   - Respect strict des données réelles de la base de données.
   - Pas de fausses cotes, pas de faux gagnants, pas d'adresses ou de données inventées.

2. **Modèle Économique & Répartition Financière :**
   - **Bronze :** 100 HTG/ticket. Répartition : 60 % aux 5 premiers gagnants (40%, 25%, 15%, 12%, 8%), 40 % part opérateur.
   - **Silver :** 250 HTG/ticket. Répartition : 60 % aux 5 premiers gagnants, 40 % part opérateur.
   - **Gold :** 500 HTG/ticket. Répartition : 60 % aux 5 premiers gagnants, 35 % part opérateur, 5 % Jackpot progressif.

---

## 9BIS. TABLEAU DE BORD ADMIN — STATISTIQUES ET CONTRÔLE (Croquis 7 — Administration)

### A. STATISTIQUES UTILISATEURS (TEMPS RÉEL)
1. **Comptes :** Total créés, numéros vérifiés vs non vérifiés, nouveaux inscrits par jour / semaine / mois.
2. **Activité :** Joueurs actifs par semaine (pronostics soumis), répartition par tier (Bronze / Silver / Gold), taux de rétention semaine après semaine.
3. **Financier :** Entrées totales par semaine et par tier, dépôts et retraits (volume + nombre), part opérateur (40 % standard / 35 % Gold).
4. **Alertes :** Comptes bloqués et motif, tentatives suspectes (plusieurs comptes sur un même numéro), retraits en attente de vérification.
5. **Activité en direct :** À chaque connexion d'un joueur, l'admin voit en temps réel : le joueur, l'heure de connexion et la ville de connexion (via IP). Position GPS précise en direct : uniquement pour les joueurs ayant donné l'opt-in.

---

### B. LOCALISATION ET ADRESSES IP (DÉCISIONS DU FONDATEUR)
- **VILLE / PAYS PAR IP :** Détection automatique à chaque connexion, SANS permission nécessaire — condition d'utilisation de la plateforme (obligatoire). Carte de distribution (Port-au-Prince, Cap-Haïtien, Gonaïves, diaspora...).
- **ADRESSES IP ANTI-FRAUDE :** Journal conservé **24 MOIS GLISSANTS** à renouvellement automatique (fenêtre roulante : chaque jour, les IP de plus de 24 mois sont effacées automatiquement et le cycle se renouvelle). Usage strictement limité à la prévention de la fraude (multi-comptes).
- **GPS EN TEMPS RÉEL :** Uniquement sur **OPT-IN EXPLICITE** et séparé du joueur (finalité expliquée : amélioration du service et prévention de la fraude). Le GPS précis n'est **JAMAIS obligatoire**.
- **CONSERVATION 12 MOIS GLISSANTS :** À renouvellement automatique : chaque jour, les positions de plus de 12 mois sont effacées ; tant que le consentement reste actif, un nouveau cycle recommence.
- **RÉVOCATION IMMÉDIATE :** Le joueur peut retirer son consentement à tout moment depuis son profil — la collecte s'arrête immédiatement et ses données sont effacées.
- **CYCLES INDIVIDUELS PAR JOUEUR :** Chaque joueur a sa propre fenêtre (24 mois IP / 12 mois GPS) calculée à partir de ses propres données.
- **JOUEURS DÉJÀ INSCRITS :** Nettoyage unique des données plus anciennes que la fenêtre dès l'activation, puis cycle glissant normal. GPS : opt-in à demander explicitement (aucun consentement rétroactif présumé).
- **NOUVEAUX JOUEURS :** Mêmes règles dès le premier jour.
- **NOTIFICATION ADMIN :** À chaque cycle de renouvellement (rapport : volumes effacés, volumes actifs).
- **AUCUN SUIVI EN ARRIÈRE-PLAN :** Interdiction absolue de géolocalisation en tâche de fond sans consentement spécifique.
- **MENTION OBLIGATOIRE :** Détaillée dans la politique de confidentialité.

---

### C. CARTE GPS EN DIRECT (TABLEAU DE BORD ADMIN)

#### 1. DENSITÉ & CARTE DE CHALEUR (HEATMAP)
- Carte affichant la **DENSITÉ** des joueurs ayant donné l'opt-in GPS, sous forme de carte de chaleur (heatmap) par zone géographique (ex: Port-au-Prince Métropole, Nord / Cap-Haïtien, Artibonite / Gonaïves, Sud / Les Cayes, Centre, Diaspora).
- **AUCUN point individuel n'est affiché par défaut sur la carte.** La vue par défaut ne présente que l'intensité globale des concentrations d'utilisateurs.

#### 2. CONSULTATION SÉCURISÉE & TRAÇABILITÉ INTERNE
- En cliquant sur une zone de la heatmap, l'admin accède à la liste des joueurs opt-in de la zone.
- En sélectionnant un joueur spécifique, l'admin peut consulter sa position précise en direct (coordonnées, rayon de précision, horodatage).
- **Chaque accès individuel est automatiquement et irrévocablement enregistré au journal d'audit interne** : identifiant de l'admin, joueur consulté, date/heure exacte, motif de la consultation.

#### 3. ALERTES AUTOMATIQUES AUTONOMES
Le système signale seul les cas suspects sans que l'admin ait besoin de surveiller la carte en continu :
1. **Multi-comptes sur même position :**  
   • Détection automatique si **5 comptes ou plus** sont connectés depuis la **même position GPS exacte** (suspicion de multi-comptes ou syndicat de jeu).
2. **Déplacement impossible (Téléportation) :**  
   • Détection automatique si **un joueur se connecte depuis des villes incohérentes dans un laps de temps impossible** (ex: connexion à Cap-Haïtien puis à Port-au-Prince à 4 minutes d'intervalle, vitesse physique impossible).

#### 4. GOUVERNANCE DES DONNÉES
- **Données éligibles :** Uniquement les joueurs avec opt-in GPS actif.
- **Conservation :** 12 mois glissants avec effacement quotidien automatique.
- **Révocation du consentement :** Arrêt immédiat de la collecte + effacement instantané et irréversible de toutes les coordonnées précises enregistrées.
- **Pas de suivi en arrière-plan :** La géolocalisation n'est relevée qu'au moment de l'accès applicatif consenti.

#### 5. RÈGLE FONDAMENTALE
> 🛡️ **RÈGLE ABSOLUE :** La carte sert exclusivement à détecter la fraude et à visualiser la distribution globale des joueurs — **en aucun cas à surveiller des individus**.

---

### D. CORRECTIONS MANUELLES AVEC TRAÇABILITÉ INTERNE (DÉCISION DU FONDATEUR)
- **Corrections autorisées par l'admin :** Résultats de matchs mal saisis, recalcul des points et du classement (automatique après correction), disqualification de tricheurs (multi-comptes), erreurs de montants de prix, données de compte joueur.
- **Justification obligatoire :** Chaque correction exige un motif écrit d'au moins 8 caractères et est enregistrée dans un journal d'audit INTERNE (admin uniquement) : qui, quand, quoi (avant → après), pourquoi, joueurs affectés.
- **Affichage joueur :** Les joueurs voient uniquement le classement corrigé (le résultat juste).
- **INTERDICTIONS ABSOLUES :**
  • Le journal d'audit ne peut ni être modifié ni supprimé (pas même par le fondateur).
  • Les pronostics des joueurs sont **VERROUILLÉS à la clôture** — aucune modification possible après la clôture, sans exception.
  • En cas de problème technique prouvé (ex. pronostic non enregistré), l'admin peut **ANNULER** une participation (jamais la modifier) avec trace d'audit, et l'entrée est immédiatement remboursée.

---

## 9TER. SÉCURITÉ MAXIMALE

1. **Authentification :** Mots de passe hashés avec sel (bcrypt/argon2/sha256 cryptographique), jamais en clair.
2. **2FA Obligatoire :** Authentification à deux facteurs requise pour tous les comptes administrateurs.
3. **Protection des Données Joueurs :** Les mots de passe et secrets personnels ne sont jamais affichés dans le tableau de bord.
4. **Sessions Sécurisées :** Déconnexion automatique après inactivité, tokens sécurisés, protection CSRF et Rate Limiting.
5. **Prévention de la Fraude :** Vérification unique de numéro de téléphone (1 compte par numéro haïtien).
