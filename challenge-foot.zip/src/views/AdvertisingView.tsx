import React from 'react';
import { useI18n } from '../i18n';
import { Campaign } from '../types';
import { Logo } from '../components/Logo';
import {
  Megaphone,
  Download,
  UserPlus,
  Trophy,
  ArrowRight,
  ExternalLink,
  Sparkles,
  Calendar,
  MousePointerClick,
  ShieldCheck,
} from 'lucide-react';

interface AdvertisingViewProps {
  campaigns: Campaign[];
  onOpenDownload: () => void;
  onOpenRegister: () => void;
  onNavigateToChallenges: () => void;
  onNavigateToWallet: () => void;
  onCampaignClick: (id: string) => void;
}

export const AdvertisingView: React.FC<AdvertisingViewProps> = ({
  campaigns,
  onOpenDownload,
  onOpenRegister,
  onNavigateToChallenges,
  onNavigateToWallet,
  onCampaignClick,
}) => {
  const { t, language } = useI18n();

  // Filter campaigns placed on page or both, and active
  const activeCampaigns = campaigns.filter(
    (c) => c.isActive && (c.placement === 'page' || c.placement === 'both')
  );

  const handleCta = (campaign: Campaign) => {
    onCampaignClick(campaign.id);

    if (campaign.ctaType === 'download' || campaign.targetUrl === '/download') {
      onOpenDownload();
    } else if (campaign.ctaType === 'register' || campaign.targetUrl === '/register') {
      onOpenRegister();
    } else if (campaign.ctaType === 'challenge' || campaign.targetUrl === '/challenges') {
      onNavigateToChallenges();
    } else if (campaign.targetUrl === '/wallet') {
      onNavigateToWallet();
    } else if (campaign.targetUrl?.startsWith('http')) {
      window.open(campaign.targetUrl, '_blank', 'noopener,noreferrer');
    } else {
      onOpenDownload();
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-10 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-8 h-8 rounded-lg bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-[#38BDF8]">
              <Megaphone className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-[#38BDF8]">
              Espace Publicitaire & Offres
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t('ad.page_title')}
          </h1>
          <p className="text-sm text-slate-300 mt-1 max-w-2xl">
            {t('ad.page_desc')}
          </p>
        </div>

        <button
          onClick={onOpenDownload}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-blue-600/30 active:scale-95 cursor-pointer self-start md:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>{t('ad.btn_download')}</span>
        </button>
      </div>

      {/* Campaigns Listing */}
      {activeCampaigns.length === 0 ? (
        <div className="py-16 text-center rounded-2xl bg-slate-900/40 border border-slate-800 p-8 space-y-4 max-w-lg mx-auto">
          <div className="w-12 h-12 rounded-full bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 mx-auto">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-white">{t('ad.no_ads_title')}</h3>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            {t('ad.no_ads_desc')}
          </p>
          <button
            onClick={onNavigateToChallenges}
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#0B61DF] hover:bg-blue-600 text-white text-xs sm:text-sm font-semibold rounded-xl transition-all shadow-md active:scale-95 cursor-pointer"
          >
            <span>{t('ad.btn_discover_challenges')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {activeCampaigns.map((camp) => {
            const title = camp.title[language] || camp.title.ht || camp.title.fr;
            const desc = camp.description[language] || camp.description.ht || camp.description.fr;
            const customCta = camp.ctaCustomLabel?.[language] || camp.ctaCustomLabel?.ht;

            return (
              <div
                key={camp.id}
                className="rounded-2xl bg-[#0D1C34] border border-slate-800 hover:border-blue-500/40 shadow-xl overflow-hidden flex flex-col transition-all group"
              >
                {/* Campaign Image */}
                <div className="relative aspect-[16/9] w-full overflow-hidden bg-slate-950">
                  {camp.imageUrl ? (
                    <img
                      src={camp.imageUrl}
                      alt={title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-slate-900">
                      <Logo size="lg" showText={false} />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0D1C34] via-transparent to-black/30" />

                  {/* Corner tag */}
                  <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10 flex items-center gap-1.5 text-[10px] font-bold text-[#38BDF8]">
                    <Sparkles className="w-3 h-3 text-[#38BDF8]" />
                    <span>Campagne Officielle</span>
                  </div>
                </div>

                {/* Campaign Content */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold text-white group-hover:text-[#38BDF8] transition-colors leading-snug">
                      {title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                      {desc}
                    </p>
                  </div>

                  {/* Campaign Metadata */}
                  <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      <span>{camp.startDate} au {camp.endDate}</span>
                    </div>
                    <div className="flex items-center gap-1 text-slate-500">
                      <MousePointerClick className="w-3.5 h-3.5" />
                      <span>{camp.clicks} clics</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-1 flex flex-wrap gap-2.5">
                    <button
                      onClick={() => handleCta(camp)}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm transition-all shadow-md shadow-blue-600/30 active:scale-95 cursor-pointer"
                    >
                      {camp.ctaType === 'download' && <Download className="w-4 h-4" />}
                      {camp.ctaType === 'register' && <UserPlus className="w-4 h-4" />}
                      {camp.ctaType === 'challenge' && <Trophy className="w-4 h-4" />}
                      {camp.ctaType === 'external' && <ExternalLink className="w-4 h-4" />}
                      <span>{customCta || t('common.learn_more')}</span>
                    </button>

                    <button
                      onClick={onOpenDownload}
                      className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-600 text-slate-300 hover:text-white text-xs font-semibold transition-all cursor-pointer"
                      title={t('ad.btn_download')}
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">APK</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Trust & Guarantee Box */}
      <div className="rounded-2xl bg-gradient-to-r from-blue-900/20 via-slate-900/40 to-blue-900/20 border border-blue-500/30 p-5 sm:p-6 text-xs text-slate-300 flex flex-col sm:flex-row items-center gap-4">
        <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-[#38BDF8] shrink-0">
          <ShieldCheck className="w-5 h-5" />
        </div>
        <div className="space-y-1 text-center sm:text-left flex-1">
          <p className="font-bold text-white text-sm">
            Engagements de Transparence Challenge Foot
          </p>
          <p className="text-slate-400 leading-relaxed text-[11px] sm:text-xs">
            Toutes les publicités et offres diffusées sur Challenge Foot respectent scrupuleusement les règles du concours de compétence. Aucun faux gain garanti n'est promis. En mode test, toutes les fonctionnalités financières restent strictement sans argent réel.
          </p>
        </div>
      </div>
    </div>
  );
};
