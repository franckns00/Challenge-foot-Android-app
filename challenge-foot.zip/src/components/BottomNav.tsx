import React from 'react';
import { useI18n } from '../i18n';
import { Home, Trophy, Activity, Wallet, Menu } from 'lucide-react';

interface BottomNavProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onToggleMenu: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentView,
  onNavigate,
  onToggleMenu,
}) => {
  const { t } = useI18n();

  const navItems = [
    { id: 'home', label: t('nav.home'), icon: Home },
    { id: 'challenges', label: 'Challenge', icon: Trophy },
    { id: 'challenge-live', label: 'Live 10', icon: Activity, isLive: true },
    { id: 'wallet', label: t('nav.wallet'), icon: Wallet },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#07101F]/95 backdrop-blur-lg border-t border-slate-800/90 pb-safe">
      <div className="grid grid-cols-5 items-center h-16 max-w-md mx-auto px-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors relative cursor-pointer select-none ${
                isActive
                  ? item.isLive
                    ? 'text-red-400'
                    : 'text-[#38BDF8]'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
                {item.isLive && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-red-500 animate-ping" />
                )}
              </div>
              <span className="text-[10px] font-semibold tracking-tight mt-1 truncate max-w-[64px]">
                {item.label}
              </span>
              {isActive && (
                <span
                  className={`absolute bottom-1 w-1 h-1 rounded-full ${
                    item.isLive ? 'bg-red-400' : 'bg-[#38BDF8]'
                  }`}
                />
              )}
            </button>
          );
        })}

        {/* Menu Drawer button */}
        <button
          onClick={onToggleMenu}
          className="flex flex-col items-center justify-center h-full min-h-[44px] text-slate-400 hover:text-slate-200 transition-colors relative cursor-pointer select-none"
        >
          <Menu className="w-5 h-5 stroke-2" />
          <span className="text-[10px] font-semibold tracking-tight mt-1 truncate max-w-[64px]">
            {t('nav.menu')}
          </span>
        </button>
      </div>
    </nav>
  );
};
