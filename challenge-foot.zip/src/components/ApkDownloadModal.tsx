import React, { useState } from 'react';
import { useI18n } from '../i18n';
import { Logo } from './Logo';
import {
  Download,
  Smartphone,
  CheckCircle2,
  AlertTriangle,
  X,
  FileCode2,
  Copy,
  Check,
  ShieldCheck,
  Package,
  ExternalLink,
  Cloud,
  FileArchive,
  Info,
} from 'lucide-react';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({ isOpen, onClose }) => {
  const { t } = useI18n();
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'cloud_phone' | 'project_zip' | 'guide'>('cloud_phone');

  if (!isOpen) return null;

  const handleDownloadZip = () => {
    setDownloadStarted(true);
    const link = document.createElement('a');
    link.href = '/downloads/challenge-foot-android-project.zip';
    link.download = 'challenge-foot-android-project.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const copyGradleCommand = () => {
    const cmd = `cd android\nchmod +x gradlew\n./gradlew assembleRelease`;
    navigator.clipboard.writeText(cmd);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-xl bg-[#07101F] border border-blue-500/40 rounded-3xl shadow-2xl overflow-hidden my-8">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-[#38BDF8]">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white leading-tight">
                Installation Android APK — Challenge Foot
              </h3>
              <p className="text-xs text-slate-400">
                Package ID: <span className="font-mono text-[#38BDF8]">ht.challengefoot.app</span> · Android 7.0 à 14+
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 px-5 pt-3 gap-3 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('cloud_phone')}
            className={`pb-2.5 transition-colors cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'cloud_phone'
                ? 'text-[#38BDF8] border-b-2 border-[#38BDF8]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cloud className="w-3.5 h-3.5" />
            <span>1. Générer l'APK sur Téléphone</span>
          </button>
          <button
            onClick={() => setActiveTab('project_zip')}
            className={`pb-2.5 transition-colors cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'project_zip'
                ? 'text-[#38BDF8] border-b-2 border-[#38BDF8]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileArchive className="w-3.5 h-3.5" />
            <span>2. Télécharger le Projet ZIP</span>
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`pb-2.5 transition-colors cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'guide'
                ? 'text-[#38BDF8] border-b-2 border-[#38BDF8]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Info className="w-3.5 h-3.5" />
            <span>3. Guide d'Installation</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-5">
          {/* TAB 1: PHONE-ONLY CLOUD GENERATOR */}
          {activeTab === 'cloud_phone' && (
            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-900/30 via-[#0D1C34] to-[#07101F] border border-blue-500/40 space-y-2">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Cloud className="w-4 h-4 text-[#38BDF8]" />
                  <span>Méthode Recommandée depuis votre Téléphone Android</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  L'environnement serveur Web actuel prépare tout le code Android mais ne dispose pas du SDK Android lourd pour compiler localement. Vous pouvez générer un véritable fichier <strong>.apk installable</strong> en 2 minutes directement depuis votre téléphone :
                </p>
              </div>

              {/* Method A: PWABuilder Cloud */}
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-500/20 text-[#38BDF8] flex items-center justify-center text-xs">A</span>
                    <span>Génération Immédiate via PWABuilder (Sans Code)</span>
                  </h4>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono font-bold">
                    100% Mobile
                  </span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  1. Ouvrez l'outil gratuit dans votre navigateur Chrome sur votre téléphone :
                </p>
                <div className="flex items-center justify-between p-2 rounded-lg bg-black/40 border border-slate-700 font-mono text-[11px]">
                  <span className="text-slate-300 truncate">https://www.pwabuilder.com</span>
                  <a
                    href="https://www.pwabuilder.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-[#38BDF8] hover:text-white flex items-center gap-1 shrink-0 ml-2 font-sans font-bold"
                  >
                    <span>Ouvrir</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <p className="text-slate-300 text-[11px]">
                  2. Entrez l'URL de votre application Challenge Foot :
                </p>
                <div className="p-2 rounded-lg bg-black/40 border border-slate-700 font-mono text-[11px] text-amber-300 break-all select-all">
                  {window.location.origin}
                </div>
                <p className="text-slate-300 text-[11px]">
                  3. Cliquez sur <strong>« Package for Android »</strong> puis <strong>« Generate APK »</strong>. Le fichier <strong>.apk</strong> se télécharge directement dans votre dossier Téléchargements Android !
                </p>
              </div>

              {/* Method B: GitHub Actions Cloud Build */}
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-500/20 text-[#38BDF8] flex items-center justify-center text-xs">B</span>
                    <span>Compilation Gradle dans le Cloud (GitHub Actions)</span>
                  </h4>
                  <span className="text-[10px] bg-blue-500/20 text-[#38BDF8] px-2 py-0.5 rounded font-mono font-bold">
                    Automatisé
                  </span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  Le fichier <code className="text-blue-300">.github/workflows/build-apk.yml</code> est déjà inclus dans votre projet. Dès que vous importez ce projet sur GitHub, vous pouvez déclencher la compilation en 1 clic depuis votre mobile :
                </p>
                <ol className="list-decimal pl-4 space-y-1 text-slate-400 text-[11px]">
                  <li>Allez dans l'onglet <strong>Actions</strong> de votre dépôt GitHub sur mobile.</li>
                  <li>Cliquez sur <strong>« Build Challenge Foot Android APK »</strong> &gt; <strong>Run workflow</strong>.</li>
                  <li>Téléchargez le fichier <strong>ChallengeFoot-release.apk</strong> généré !</li>
                </ol>
              </div>
            </div>
          )}

          {/* TAB 2: DOWNLOAD PROJECT ZIP */}
          {activeTab === 'project_zip' && (
            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-2xl bg-[#0D1C34] border border-slate-700 flex flex-col sm:flex-row items-center gap-4">
                <Package className="w-12 h-12 text-[#38BDF8] shrink-0" />
                <div className="flex-1 space-y-1 text-center sm:text-left">
                  <h4 className="text-sm font-bold text-white">
                    Archive Source Complète du Projet Android
                  </h4>
                  <p className="text-slate-300 text-[11px]">
                    Fichier : <code className="text-blue-300">challenge-foot-android-project.zip</code> (445 Ko)
                  </p>
                  <p className="text-slate-400 text-[11px]">
                    Contient le dossier natif <code className="text-slate-300">android/</code> complet (Gradle, Gradle Wrapper, AndroidManifest.xml, MainActivity.java, icônes, et tous les assets web compilés).
                  </p>
                </div>
              </div>

              <button
                onClick={handleDownloadZip}
                className="w-full py-3.5 px-6 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-sm flex items-center justify-center gap-2.5 transition-all shadow-lg active:scale-98 cursor-pointer"
              >
                <Download className="w-5 h-5" />
                <span>Télécharger l'Archive ZIP du Projet Android (445 Ko)</span>
              </button>

              {downloadStarted && (
                <p className="text-xs text-emerald-400 flex items-center justify-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Le téléchargement du ZIP a démarré dans votre navigateur !</span>
                </p>
              )}

              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-slate-300">
                  <span className="font-semibold text-white">Commande de compilation locale (si sur PC) :</span>
                  <button
                    onClick={copyGradleCommand}
                    className="flex items-center gap-1 text-[11px] text-[#38BDF8] hover:text-white px-2 py-0.5 rounded bg-slate-800 cursor-pointer"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copié !' : 'Copier'}</span>
                  </button>
                </div>
                <pre className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono text-[11px]">
                  cd android && chmod +x gradlew && ./gradlew assembleRelease
                </pre>
              </div>
            </div>
          )}

          {/* TAB 3: STEP BY STEP INSTALLATION ON ANDROID PHONE */}
          {activeTab === 'guide' && (
            <div className="space-y-4 text-xs text-slate-300">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <h4 className="font-bold text-white text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Étapes pour Installer l'APK sur votre Téléphone Android</span>
                </h4>

                <div className="space-y-3 pt-1">
                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-blue-500/20 text-[#38BDF8] flex items-center justify-center font-bold shrink-0 text-xs">
                      1
                    </span>
                    <div>
                      <strong className="text-white block">Télécharger l'APK</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Une fois l'APK généré via PWABuilder ou GitHub Actions, le fichier <code>ChallengeFoot-release.apk</code> se trouvera dans votre dossier <strong>Téléchargements</strong> (Downloads).
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-blue-500/20 text-[#38BDF8] flex items-center justify-center font-bold shrink-0 text-xs">
                      2
                    </span>
                    <div>
                      <strong className="text-white block">Ouvrir le fichier APK</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Touchez la notification de téléchargement ou ouvrez l'application <strong>Fichiers</strong> (Gestionnaire de fichiers) &gt; Téléchargements, puis touchez <code>ChallengeFoot-release.apk</code>.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-blue-500/20 text-[#38BDF8] flex items-center justify-center font-bold shrink-0 text-xs">
                      3
                    </span>
                    <div>
                      <strong className="text-white block">Autoriser les sources inconnues si demandé</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Si Android affiche le message de sécurité : <em>« Pour votre sécurité, votre téléphone n'est pas autorisé à installer des applications inconnues depuis cette source »</em>, touchez <strong>Paramètres</strong> et activez <strong>« Autoriser cette source »</strong>.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-blue-500/20 text-[#38BDF8] flex items-center justify-center font-bold shrink-0 text-xs">
                      4
                    </span>
                    <div>
                      <strong className="text-white block">Finaliser l'Installation</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Touchez <strong>Installer</strong>. L'application <strong>Challenge Foot</strong> s'installe avec son icône de couronne et ballon sur votre écran d'accueil !
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[11px] flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                <p>
                  <strong>Important :</strong> Toutes les données, le design, le mode test, et le concours de pronostics sont préservés à 100 %.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="font-mono text-[11px] text-slate-400">
            Package: <strong className="text-slate-300">ht.challengefoot.app</strong>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
