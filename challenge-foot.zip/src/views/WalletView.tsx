import React, { useState } from 'react';
import { useI18n } from '../i18n';
import { User, Transaction, PaymentMethod } from '../types';
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
  History,
  Phone,
  ShieldCheck,
  CreditCard,
  RefreshCw,
  X,
} from 'lucide-react';

interface WalletViewProps {
  user: User | null;
  transactions: Transaction[];
  onOpenLogin: () => void;
  onDeposit: (amount: number, method: PaymentMethod) => void;
  onWithdraw: (amount: number, phone: string, method: PaymentMethod) => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  user,
  transactions,
  onOpenLogin,
  onDeposit,
  onWithdraw,
}) => {
  const { t } = useI18n();

  const [activeTab, setActiveTab] = useState<'balance' | 'deposit' | 'withdraw' | 'history'>('balance');

  // Deposit form states
  const [depositAmount, setDepositAmount] = useState('500');
  const [depositMethod, setDepositMethod] = useState<PaymentMethod>('moncash');
  const [depositSuccess, setDepositSuccess] = useState(false);

  // Withdrawal form states
  const [withdrawAmount, setWithdrawAmount] = useState('250');
  const [withdrawPhone, setWithdrawPhone] = useState(user?.phone || '+509 3700 0000');
  const [withdrawMethod, setWithdrawMethod] = useState<PaymentMethod>('moncash');
  const [withdrawSuccess, setWithdrawSuccess] = useState(false);

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-blue-500/10 border border-blue-500/30 text-[#38BDF8] flex items-center justify-center mx-auto">
          <Wallet className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white">Connexion Requise</h2>
        <p className="text-xs text-slate-400">
          Vous devez être connecté avec votre compte vérifié pour accéder à votre portefeuille de test.
        </p>
        <button
          onClick={onOpenLogin}
          className="px-6 py-2.5 rounded-xl bg-[#0B61DF] text-white font-bold text-xs shadow-lg cursor-pointer"
        >
          Se connecter
        </button>
      </div>
    );
  }

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(depositAmount);
    if (amt > 0) {
      onDeposit(amt, depositMethod);
      setDepositSuccess(true);
      setTimeout(() => {
        setDepositSuccess(false);
        setActiveTab('balance');
      }, 1500);
    }
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(withdrawAmount);
    if (amt > 0 && amt <= user.balance) {
      onWithdraw(amt, withdrawPhone, withdrawMethod);
      setWithdrawSuccess(true);
      setTimeout(() => {
        setWithdrawSuccess(false);
        setActiveTab('history');
      }, 1500);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-7 h-7 rounded-lg bg-blue-500/20 text-[#38BDF8] flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-[#38BDF8]">
              Finances Personnelles
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t('wallet.title')}
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {t('wallet.test_currency_note')}
          </p>
        </div>

        {/* Quick Tabs */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1.5 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('balance')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              activeTab === 'balance' ? 'bg-[#0B61DF] text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Aperçu
          </button>
          <button
            onClick={() => setActiveTab('deposit')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              activeTab === 'deposit' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            {t('wallet.deposit_btn')}
          </button>
          <button
            onClick={() => setActiveTab('withdraw')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              activeTab === 'withdraw' ? 'bg-amber-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            {t('wallet.withdraw_btn')}
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              activeTab === 'history' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Historique
          </button>
        </div>
      </div>

      {/* 1. BALANCE OVERVIEW CARD */}
      <div className="relative rounded-3xl bg-gradient-to-br from-[#0B61DF]/20 via-[#07101F] to-[#0D1C34] border border-[#0B61DF]/40 p-6 sm:p-8 shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <span className="text-xs uppercase font-bold tracking-wider text-[#38BDF8]">
              {t('wallet.balance_available')}
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl sm:text-5xl font-black text-white font-mono tabular-nums tracking-tight">
                {user.balance.toLocaleString()}
              </span>
              <span className="text-xl sm:text-2xl font-extrabold text-blue-300 font-sans">
                {t('common.haiti_currency')}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-amber-300 pt-1">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Portefeuille de Démonstration / Mode Test Certifié</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveTab('deposit')}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-emerald-900/30 active:scale-95 cursor-pointer"
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>{t('wallet.deposit_btn')}</span>
            </button>

            <button
              onClick={() => setActiveTab('withdraw')}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-600 text-white font-bold text-xs sm:text-sm transition-all active:scale-95 cursor-pointer"
            >
              <ArrowUpRight className="w-4 h-4 text-amber-400" />
              <span>{t('wallet.withdraw_btn')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. DEPOSIT PANEL */}
      {activeTab === 'deposit' && (
        <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 p-6 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <ArrowDownLeft className="w-5 h-5 text-emerald-400" />
              <span>{t('wallet.deposit_title')}</span>
            </h3>
            <span className="text-xs text-slate-400">Simulation de recharge</span>
          </div>

          {depositSuccess ? (
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>Votre dépôt de test a été crédité avec succès !</span>
            </div>
          ) : (
            <form onSubmit={handleDepositSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  {t('wallet.select_method')}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => setDepositMethod('moncash')}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      depositMethod === 'moncash'
                        ? 'bg-red-500/10 border-red-500/60 text-white'
                        : 'bg-slate-900 border-slate-700 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-sm text-red-400">MonCash</span>
                      <span className="text-[10px] bg-red-500/20 px-2 py-0.5 rounded text-red-300">PeyemAPI</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Paiement mobile Digicel Haïti (5% frais prestataire)
                    </p>
                  </div>

                  <div
                    onClick={() => setDepositMethod('natcash')}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      depositMethod === 'natcash'
                        ? 'bg-blue-500/10 border-blue-500/60 text-white'
                        : 'bg-slate-900 border-slate-700 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-sm text-blue-400">NatCash</span>
                      <span className="text-[10px] bg-blue-500/20 px-2 py-0.5 rounded text-blue-300">Natcom</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Portefeuille mobile Natcom (Service marchand séparé)
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('wallet.deposit_amount')}
                </label>
                <div className="flex items-center gap-2">
                  {[250, 500, 1000, 2500].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setDepositAmount(String(val))}
                      className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold cursor-pointer transition-colors ${
                        depositAmount === String(val)
                          ? 'bg-[#0B61DF] text-white'
                          : 'bg-slate-900 border border-slate-700 text-slate-300'
                      }`}
                    >
                      {val} HTG
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  min="50"
                  max="50000"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="mt-2 w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs sm:text-sm font-mono focus:border-blue-500 focus:outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm transition-all shadow-lg active:scale-98 cursor-pointer"
              >
                {t('wallet.simulate_payment')} ({depositAmount} HTG)
              </button>
            </form>
          )}
        </div>
      )}

      {/* 3. WITHDRAWAL PANEL */}
      {activeTab === 'withdraw' && (
        <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 p-6 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <ArrowUpRight className="w-5 h-5 text-amber-400" />
              <span>{t('wallet.withdraw_title')}</span>
            </h3>
            <span className="text-xs text-slate-400">Vers compte vérifié</span>
          </div>

          {withdrawSuccess ? (
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{t('wallet.withdraw_submitted')}</span>
            </div>
          ) : (
            <form onSubmit={handleWithdrawSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Moyen de retrait :
                </label>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
                    <input
                      type="radio"
                      checked={withdrawMethod === 'moncash'}
                      onChange={() => setWithdrawMethod('moncash')}
                      name="wmethod"
                      className="text-[#0B61DF]"
                    />
                    <span>MonCash (+509)</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
                    <input
                      type="radio"
                      checked={withdrawMethod === 'natcash'}
                      onChange={() => setWithdrawMethod('natcash')}
                      name="wmethod"
                      className="text-[#0B61DF]"
                    />
                    <span>NatCash (+509)</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('wallet.withdraw_phone')}
                </label>
                <input
                  type="text"
                  value={withdrawPhone}
                  onChange={(e) => setWithdrawPhone(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs sm:text-sm font-mono focus:border-blue-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('wallet.withdraw_amount')}
                </label>
                <input
                  type="number"
                  min="100"
                  max={user.balance}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs sm:text-sm font-mono focus:border-blue-500 focus:outline-none"
                  required
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Solde disponible maximum : {user.balance.toLocaleString()} HTG
                </span>
              </div>

              <button
                type="submit"
                disabled={parseFloat(withdrawAmount) > user.balance}
                className="w-full py-3 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-bold text-xs sm:text-sm transition-all shadow-lg active:scale-98 cursor-pointer"
              >
                Confirmer la demande de retrait
              </button>
            </form>
          )}
        </div>
      )}

      {/* 4. TRANSACTION HISTORY TABLE */}
      <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 overflow-hidden shadow-xl space-y-0">
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm sm:text-base font-bold text-white">
              {t('wallet.tx_history')}
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {transactions.length} enregistrements
          </span>
        </div>

        {transactions.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            {t('wallet.tx_empty')}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/70 border-b border-slate-800 text-slate-400 uppercase text-[10px] font-bold">
                <tr>
                  <th className="py-2.5 px-4">{t('common.date')}</th>
                  <th className="py-2.5 px-4">Référence</th>
                  <th className="py-2.5 px-4">Description</th>
                  <th className="py-2.5 px-4 text-center">{t('common.status')}</th>
                  <th className="py-2.5 px-4 text-right">{t('common.amount')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono text-[11px]">
                      {new Date(tx.date).toLocaleDateString()} {new Date(tx.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-[#38BDF8]">
                      {tx.referenceId}
                    </td>
                    <td className="py-3 px-4">{tx.description}</td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          tx.status === 'confirmed' || tx.status === 'approved'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : tx.status === 'processing' || tx.status === 'pending'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            : 'bg-red-500/20 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {tx.status}
                      </span>
                    </td>
                    <td
                      className={`py-3 px-4 text-right font-mono font-bold tabular-nums ${
                        tx.type === 'deposit' || tx.type === 'prize'
                          ? 'text-emerald-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {tx.type === 'deposit' || tx.type === 'prize' ? '+' : '-'}
                      {tx.amount.toLocaleString()} HTG
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
