import { ParticipantRecord, CategoryFinanceReport, ChallengeTier, LiveMatchStat, LeagueStandingItem } from '../types';

const HAITIAN_FIRST_NAMES = [
  'Sony', 'Kervens', 'Wadson', 'Regine', 'Frantz', 'Darlène', 'Vladimir', 'Peterson',
  'Stevenson', 'Wideline', 'Wisler', 'Ricardo', 'Guerline', 'Samuel', 'James', 'Esther',
  'Mackenson', 'Lourdes', 'Yves', 'Woody', 'Jocelyn', 'Mireille', 'Junior', 'Nathalie',
  'Evens', 'Fabienne', 'Fritzner', 'Mirlande', 'Jean-Claude', 'Roseline', 'Marc-Arthur',
  'Judith', 'Patrick', 'Ketly', 'Daniel', 'Sabrina', 'Wilner', 'Christelle', 'Belson',
  'Yolène', 'Emmanuel', 'Chantal', 'Ronald', 'Rose-Merline', 'Carl-Henry', 'Stéphanie',
  'Daphney', 'Alix', 'Sonia', 'Gérald', 'Carline', 'Claude', 'Lovelie', 'Frantzy',
];

const HAITIAN_LAST_NAMES = [
  'Jean-Baptiste', 'Pierre-Louis', 'Dorval', 'Augustin', 'Chery', 'Michel', 'Joseph',
  'Hyppolite', 'Saint-Fleur', 'Célestin', 'Toussaint', 'Manigat', 'Delva', 'François',
  'Noël', 'Alexis', 'Charles', 'Lafortune', 'Dauphin', 'Benoit', 'Guillaume', 'Bastien',
  'Antoine', 'Fils-Aimé', 'Moïse', 'Beauvoir', 'Sanon', 'Léonard', 'Duval', 'Bellegarde',
  'Salnave', 'Castor', 'Desrosiers', 'Jn-Gilles', 'Magloire', 'Phanor', 'Samedi',
];

function generateParticipantList(
  tier: ChallengeTier,
  count: number,
  entryFee: number,
  prefix: string
): { participants: ParticipantRecord[]; report: CategoryFinanceReport } {
  const participants: ParticipantRecord[] = [];

  const totalCollected = count * entryFee;
  const ownerShare = Math.round(totalCollected * 0.4);
  const winnersFund = totalCollected - ownerShare; // exactly 60%

  // Top 5 winner percentages: 40%, 25%, 15%, 12%, 8%
  const winnerPcts = [0.4, 0.25, 0.15, 0.12, 0.08];
  const winnerPrizes = winnerPcts.map((pct) => Math.round(winnersFund * pct));

  // Correct rounding so sum of prizes strictly equals winnersFund
  const prizeSum = winnerPrizes.reduce((a, b) => a + b, 0);
  if (prizeSum !== winnersFund) {
    winnerPrizes[0] += winnersFund - prizeSum;
  }

  for (let i = 0; i < count; i++) {
    const rank = i + 1;
    const isWinner = rank <= 5;
    const prizeWon = isWinner ? winnerPrizes[i] : 0;
    const prizeStatus = isWinner ? (rank <= 2 ? 'approved' : 'pending') : 'pending';
    const status = isWinner ? 'winner' : 'outside_top5';

    // Generates realistic points
    // 10 matches total: exact score = 10 pts, correct outcome = 3 pts, scorer bonus = 5 pts
    const exactPredictions = Math.max(0, 8 - Math.floor(i * 0.08));
    const correctOutcomes = Math.max(0, Math.min(10 - exactPredictions, 3 + Math.floor((count - i) * 0.04)));
    const missedPredictions = Math.max(0, 10 - exactPredictions - correctOutcomes);
    const scorerCount = Math.max(0, Math.min(10, 6 - Math.floor(i * 0.06)));
    const scorerBonus = scorerCount * 5;
    const totalPoints = exactPredictions * 10 + correctOutcomes * 3 + scorerBonus;
    const totalGoalsPredicted = 22 + (i % 12);

    const fName = HAITIAN_FIRST_NAMES[i % HAITIAN_FIRST_NAMES.length];
    const lName = HAITIAN_LAST_NAMES[(i * 3 + Math.floor(i / HAITIAN_FIRST_NAMES.length)) % HAITIAN_LAST_NAMES.length];
    const fullName = `${lName} ${fName}`;

    participants.push({
      id: `part-${tier}-${i + 1}`,
      participantNumber: `#${prefix}-${String(i + 1).padStart(3, '0')}`,
      userId: `u-${tier}-${i + 1}`,
      name: fullName,
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${fullName}`,
      tier,
      rank,
      totalPoints,
      exactPredictions,
      correctOutcomes,
      missedPredictions,
      scorerBonus,
      totalGoalsPredicted,
      status,
      prizeWon,
      prizeStatus,
      paidFee: entryFee,
      submittedAt: `2026-10-${String(14 + (i % 3)).padStart(2, '0')}T${String(10 + (i % 10)).padStart(2, '0')}:${String((i * 7) % 60).padStart(2, '0')}:00Z`,
    });
  }

  // Sort participants by points descending
  participants.sort((a, b) => {
    if (b.totalPoints !== a.totalPoints) return b.totalPoints - a.totalPoints;
    if (b.exactPredictions !== a.exactPredictions) return b.exactPredictions - a.exactPredictions;
    if (b.scorerBonus !== a.scorerBonus) return b.scorerBonus - a.scorerBonus;
    return a.totalGoalsPredicted - b.totalGoalsPredicted;
  });

  // Re-assign ranks 1..N after sort
  participants.forEach((p, idx) => {
    p.rank = idx + 1;
    if (p.rank <= 5) {
      p.status = 'winner';
      p.prizeWon = winnerPrizes[p.rank - 1];
    } else {
      p.status = 'outside_top5';
      p.prizeWon = 0;
    }
  });

  const winners = participants.slice(0, 5).map((p, idx) => ({
    rank: (idx + 1) as 1 | 2 | 3 | 4 | 5,
    participantNumber: p.participantNumber,
    name: p.name,
    points: p.totalPoints,
    exactPredictions: p.exactPredictions,
    prizeAmount: p.prizeWon,
    percentageOfFund: [40, 25, 15, 12, 8][idx],
    prizeStatus: p.prizeStatus,
  }));

  const report: CategoryFinanceReport = {
    tier,
    entryFeePerPerson: entryFee,
    totalConfirmedParticipants: count,
    totalCollectedAmount: totalCollected,
    ownerSharePercentage: 40,
    ownerShareAmount: ownerShare,
    winnersSharePercentage: 60,
    winnersShareAmount: winnersFund,
    winners,
  };

  return { participants, report };
}

// 1. BRONZE: Exactly 100 participants * 100 HTG = 10,000 HTG
export const BRONZE_DATA = generateParticipantList('bronze', 100, 100, 'BR');

// 2. SILVER: Exactly 60 participants * 250 HTG = 15,000 HTG
export const SILVER_DATA = generateParticipantList('silver', 60, 250, 'SL');

// 3. GOLD: Exactly 40 participants * 500 HTG = 20,000 HTG
export const GOLD_DATA = generateParticipantList('gold', 40, 500, 'GD');

export const ALL_PARTICIPANTS_BY_TIER: Record<ChallengeTier, ParticipantRecord[]> = {
  bronze: BRONZE_DATA.participants,
  silver: SILVER_DATA.participants,
  gold: GOLD_DATA.participants,
};

export const ALL_REPORTS_BY_TIER: Record<ChallengeTier, CategoryFinanceReport> = {
  bronze: BRONZE_DATA.report,
  silver: SILVER_DATA.report,
  gold: GOLD_DATA.report,
};

// ----------------- ARCHIVED WEEKS (KONSÈVE ANSYEN KLASMAN YO NAN ACHIV) -----------------
export interface ArchivedRound {
  id: string;
  roundNumber: number;
  label: string;
  endDate: string;
  closingTime: string;
  statusText: string;
  participantsByTier: Record<ChallengeTier, ParticipantRecord[]>;
  reportsByTier: Record<ChallengeTier, CategoryFinanceReport>;
}

const W41_BRONZE = generateParticipantList('bronze', 100, 100, 'BR41');
const W41_SILVER = generateParticipantList('silver', 60, 250, 'SL41');
const W41_GOLD = generateParticipantList('gold', 40, 500, 'GD41');

const W40_BRONZE = generateParticipantList('bronze', 100, 100, 'BR40');
const W40_SILVER = generateParticipantList('silver', 60, 250, 'SL40');
const W40_GOLD = generateParticipantList('gold', 40, 500, 'GD40');

export const ARCHIVED_WEEKS: ArchivedRound[] = [
  {
    id: 'w42',
    roundNumber: 42,
    label: 'Semèn #42 (Semèn Aktyèl)',
    endDate: 'Dimanch 12 Oktòb 2026',
    closingTime: '23:59 GMT-4 (Heure d\'Haïti)',
    statusText: 'Rezilta Verifye & Konfime sou Sèvè a',
    participantsByTier: ALL_PARTICIPANTS_BY_TIER,
    reportsByTier: ALL_REPORTS_BY_TIER,
  },
  {
    id: 'w41',
    roundNumber: 41,
    label: 'Semèn #41 (Achiv - 05 Oktòb 2026)',
    endDate: 'Dimanch 05 Oktòb 2026',
    closingTime: '23:59 GMT-4 (Heure d\'Haïti)',
    statusText: 'Achive · Tout 5 Gayan yo te Peye via MonCash/NatCash',
    participantsByTier: {
      bronze: W41_BRONZE.participants,
      silver: W41_SILVER.participants,
      gold: W41_GOLD.participants,
    },
    reportsByTier: {
      bronze: W41_BRONZE.report,
      silver: W41_SILVER.report,
      gold: W41_GOLD.report,
    },
  },
  {
    id: 'w40',
    roundNumber: 40,
    label: 'Semèn #40 (Achiv - 28 Septanm 2026)',
    endDate: 'Dimanch 28 Septanm 2026',
    closingTime: '23:59 GMT-4 (Heure d\'Haïti)',
    statusText: 'Achive · Peman Fini & Bilan Klotire',
    participantsByTier: {
      bronze: W40_BRONZE.participants,
      silver: W40_SILVER.participants,
      gold: W40_GOLD.participants,
    },
    reportsByTier: {
      bronze: W40_BRONZE.report,
      silver: W40_SILVER.report,
      gold: W40_GOLD.report,
    },
  },
];

// ----------------- BESOCCER STYLE FOOTBALL STATS -----------------

export const LIVE_MATCHES: LiveMatchStat[] = [
  {
    id: 'live-1',
    competition: 'La Liga EA Sports',
    minute: "74'",
    homeTeam: 'Real Madrid',
    homeScore: 2,
    awayTeam: 'FC Barcelona',
    awayScore: 1,
    status: 'LIVE',
    scorers: ['Vinícius Jr 24\'', 'K. Mbappé 58\'', 'R. Lewandowski 39\''],
  },
  {
    id: 'live-2',
    competition: 'Premier League',
    minute: "61'",
    homeTeam: 'Manchester City',
    homeScore: 1,
    awayTeam: 'Arsenal',
    awayScore: 1,
    status: 'LIVE',
    scorers: ['E. Haaland 18\'', 'B. Saka 52\''],
  },
  {
    id: 'live-3',
    competition: 'Serie A',
    minute: 'FT',
    homeTeam: 'Inter Milan',
    homeScore: 3,
    awayTeam: 'Juventus',
    awayScore: 2,
    status: 'FT',
    scorers: ['L. Martínez 12\', 84\'', 'M. Thuram 45\'', 'D. Vlahović 33\', 65\''],
  },
  {
    id: 'live-4',
    competition: 'Bundesliga',
    minute: "19:00",
    homeTeam: 'Bayern Munich',
    homeScore: 0,
    awayTeam: 'Borussia Dortmund',
    awayScore: 0,
    status: 'UPCOMING',
    scorers: [],
  },
];

export const LEAGUE_STANDINGS_LALIGA: LeagueStandingItem[] = [
  { position: 1, team: 'Real Madrid', played: 9, won: 7, drawn: 2, lost: 0, goalsFor: 22, goalsAgainst: 7, points: 23, form: ['W', 'W', 'D', 'W', 'W'] },
  { position: 2, team: 'FC Barcelona', played: 9, won: 7, drawn: 1, lost: 1, goalsFor: 26, goalsAgainst: 9, points: 22, form: ['W', 'W', 'W', 'L', 'W'] },
  { position: 3, team: 'Atlético Madrid', played: 9, won: 5, drawn: 4, lost: 0, goalsFor: 15, goalsAgainst: 5, points: 19, form: ['D', 'W', 'D', 'W', 'W'] },
  { position: 4, team: 'Villarreal', played: 9, won: 5, drawn: 2, lost: 2, goalsFor: 18, goalsAgainst: 15, points: 17, form: ['W', 'L', 'W', 'W', 'D'] },
  { position: 5, team: 'Athletic Club', played: 9, won: 4, drawn: 3, lost: 2, goalsFor: 14, goalsAgainst: 11, points: 15, form: ['L', 'W', 'D', 'W', 'D'] },
  { position: 6, team: 'Mallorca', played: 9, won: 4, drawn: 2, lost: 3, goalsFor: 10, goalsAgainst: 9, points: 14, form: ['W', 'W', 'L', 'W', 'L'] },
];

export const TOP_SCORERS_DATA = [
  { rank: 1, player: 'Robert Lewandowski', team: 'FC Barcelona', goals: 10, assists: 2, matches: 9 },
  { rank: 2, player: 'Erling Haaland', team: 'Manchester City', goals: 10, assists: 0, matches: 8 },
  { rank: 3, player: 'Kylian Mbappé', team: 'Real Madrid', goals: 7, assists: 1, matches: 9 },
  { rank: 4, player: 'Harry Kane', team: 'Bayern Munich', goals: 6, assists: 4, matches: 7 },
  { rank: 5, player: 'Cole Palmer', team: 'Chelsea', goals: 6, assists: 5, matches: 8 },
  { rank: 6, player: 'Vinícius Júnior', team: 'Real Madrid', goals: 5, assists: 4, matches: 9 },
];
