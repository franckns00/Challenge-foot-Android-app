import React, { useState, useEffect } from 'react';
import { useI18n } from '../i18n';
import { Challenge, Match, ChallengeTier, MatchPick, User } from '../types';
import {
  Trophy,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Lock,
  Sparkles,
  Shield,
  Layers,
  Tv,
  Info,
  ChevronDown,
  RefreshCw,
  Check,
  Users,
  Eye,
  EyeOff,
} from 'lucide-react';
import { MatchDetailsModal } from '../components/MatchDetailsModal';
import { MatchPlayersModal } from '../components/MatchPlayersModal';

interface ChallengesViewProps {
  challenge: Challenge;
  user: User | null;
  onOpenLogin: () => void;
  onSubmitPredictions: (tier: ChallengeTier, picks: MatchPick[]) => void;
  onNavigateToLive?: () => void;
}

export const ChallengesView: React.FC<ChallengesViewProps> = ({
  challenge,
  user,
  onOpenLogin,
  onSubmitPredictions,
  onNavigateToLive,
}) => {
  const { t } = useI18n();

  const [selectedTier, setSelectedTier] = useState<ChallengeTier>('bronze');
  const [liveMatches, setLiveMatches] = useState<Match[]>(challenge.matches || []);
  const [missingMatchesNotice, setMissingMatchesNotice] = useState<number>(challenge.missingCount || 0);

  // User's confirmed/saved predictions loaded from server
  const [savedPicks, setSavedPicks] = useState<Record<string, any>>({});
  const [singleConfirmingId, setSingleConfirmingId] = useState<string | null>(null);
  const [singleFeedback, setSingleFeedback] = useState<Record<string, { type: 'success' | 'error'; message: string }>>({});

  // Match picks state: Exactly 3 categories:
  // A. Buteur (goalscorer)
  // B. 1N2 (outcome)
  // C. Score Exact (homeScore, awayScore)
  const [picks, setPicks] = useState<
    Record<
      string,
      {
        homeScore: number | null;
        awayScore: number | null;
        outcome1x2: '1' | 'X' | '2' | null;
        goalscorerName: string;
        goalscorerTeam: string;
      }
    >
  >(() => {
    const init: any = {};
    (challenge.matches || []).forEach((m) => {
      init[m.id] = {
        homeScore: null,
        awayScore: null,
        outcome1x2: null,
        goalscorerName: '',
        goalscorerTeam: '',
      };
    });
    return init;
  });

  const [showSummary, setShowSummary] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Modal State for Match Details & Watch
  const [activeModalFixtureId, setActiveModalFixtureId] = useState<number | string | null>(null);
  const [modalInitialTab, setModalInitialTab] = useState<'summary' | 'watch'>('summary');
  const [activeModalMatchInfo, setActiveModalMatchInfo] = useState<any>(null);

  // Sub-Tab State: 'my_picks' | 'all_participants'
  const [activeSubTab, setActiveSubTab] = useState<'my_picks' | 'all_participants'>('my_picks');

  // Modal State for Voir les Joueurs (Squads & Lineups)
  const [playersModalFixtureId, setPlayersModalFixtureId] = useState<number | string | null>(null);
  const [playersModalMatchInfo, setPlayersModalMatchInfo] = useState<any>(null);

  // Public predictions of all participants
  const [publicData, setPublicData] = useState<any | null>(null);
  const [loadingPublic, setLoadingPublic] = useState(false);
  const [togglingPrivacy, setTogglingPrivacy] = useState(false);

  const loadPublicPredictions = () => {
    setLoadingPublic(true);
    fetch(`/api/predictions/public?challengeId=${challenge.id}&currentUserId=${user?.id || ''}`)
      .then((res) => res.json())
      .then((json) => {
        if (json.success) {
          setPublicData(json);
        }
      })
      .catch(() => {})
      .finally(() => setLoadingPublic(false));
  };

  useEffect(() => {
    loadPublicPredictions();
  }, [challenge.id, user?.id]);

  const handleTogglePrivacyMode = async () => {
    if (!user || user.role !== 'admin') return;
    setTogglingPrivacy(true);
    try {
      const nextVal = !(publicData?.privacyModeActive ?? true);
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hidePredictionsUntilKickoff: nextVal, adminId: user.id }),
      });
      const data = await res.json();
      if (data.success) {
        loadPublicPredictions();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setTogglingPrivacy(false);
    }
  };

  // Sync matches when prop changes
  useEffect(() => {
    if (challenge.matches && challenge.matches.length > 0) {
      setLiveMatches(challenge.matches);
      setMissingMatchesNotice(challenge.missingCount || Math.max(0, 10 - challenge.matches.length));
    }
  }, [challenge]);

  // Load user's saved predictions from server
  const loadUserPredictions = () => {
    if (!user) return;
    fetch(`/api/predictions/my?userId=${user.id}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success && Array.isArray(data.predictions)) {
          const map: Record<string, any> = {};
          const nextPicks = { ...picks };

          // Find predictions for current challenge
          const relevant = data.predictions.filter((p: any) => p.challengeId === challenge.id);
          relevant.forEach((pred: any) => {
            if (Array.isArray(pred.picks)) {
              pred.picks.forEach((pk: any) => {
                map[pk.matchId] = pk;
                if (pk.apiFixtureId) {
                  map[`m-api-${pk.apiFixtureId}`] = pk;
                  map[String(pk.apiFixtureId)] = pk;
                }
                // Pre-fill local picks if not already set
                if (nextPicks[pk.matchId]) {
                  nextPicks[pk.matchId] = {
                    homeScore: pk.homeScore,
                    awayScore: pk.awayScore,
                    outcome1x2: pk.outcome1X2 || pk.outcome1x2,
                    goalscorerName: pk.goalscorerName || '',
                    goalscorerTeam: '',
                  };
                }
              });
            }
          });

          setSavedPicks(map);
          setPicks(nextPicks);
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    loadUserPredictions();
  }, [user, challenge.id]);

  // Periodic real-time synchronization with API Football (every 25 seconds)
  useEffect(() => {
    const syncLiveStatus = () => {
      fetch('/api/football/challenge-live')
        .then((res) => res.json())
        .then((data) => {
          if (data.success && Array.isArray(data.matches) && data.matches.length > 0) {
            setLiveMatches((prev) =>
              prev.map((pm) => {
                const updated = data.matches.find(
                  (dm: any) => dm.id === pm.apiFixtureId || dm.apiFixtureId === pm.apiFixtureId || dm.id === pm.id
                );
                if (updated) {
                  return {
                    ...pm,
                    status: updated.status,
                    statusShort: updated.status,
                    statusLong: updated.statusLong,
                    displayStatus: updated.displayStatus,
                    elapsed: updated.elapsed,
                    homeScore: updated.homeScore ?? pm.homeScore,
                    awayScore: updated.awayScore ?? pm.awayScore,
                  };
                }
                return pm;
              })
            );
          }
        })
        .catch(() => {});
    };

    const interval = setInterval(syncLiveStatus, 25000);
    return () => clearInterval(interval);
  }, []);

  // Strict check: Is this match locked for predictions?
  const isMatchLocked = (match: Match) => {
    // 1. Kickoff time passed (server-synchronized)
    if (match.kickOffTime) {
      const kickoffMs = new Date(match.kickOffTime).getTime();
      if (!isNaN(kickoffMs) && kickoffMs <= Date.now()) return true;
    }
    // 2. Fallback to time string
    if (match.date && match.time && match.time.includes(':')) {
      const combinedMs = new Date(`${match.date}T${match.time}:00Z`).getTime();
      if (!isNaN(combinedMs) && combinedMs <= Date.now()) return true;
    }
    // 3. Status in-play or finished
    const sUpper = (match.statusShort || match.status || '').toUpperCase();
    if (['1H', 'HT', '2H', 'ET', 'LIVE', 'FT', 'AET', 'PEN', 'PST', 'CANC', 'ABD', 'AWD', 'WO'].includes(sUpper)) {
      return true;
    }
    if (match.status === 'live' || match.status === 'finished') return true;
    return false;
  };

  // 1. Update Score Exact (Catégorie C)
  const handleScoreChange = (matchId: string, side: 'home' | 'away', valStr: string) => {
    const match = liveMatches.find((m) => m.id === matchId);
    if (match && isMatchLocked(match)) {
      setSingleFeedback((prev) => ({
        ...prev,
        [matchId]: {
          type: 'error',
          message: 'Pronostics fermés — le match a commencé. Vos pronostics ne peuvent plus être modifiés.',
        },
      }));
      return;
    }

    const cur = picks[matchId] || {
      homeScore: null,
      awayScore: null,
      outcome1x2: null,
      goalscorerName: '',
      goalscorerTeam: '',
    };
    const numVal = valStr === '' ? null : Math.max(0, parseInt(valStr, 10) || 0);
    const nextHome = side === 'home' ? numVal : cur.homeScore;
    const nextAway = side === 'away' ? numVal : cur.awayScore;

    // Automatically align 1N2 if both scores are entered
    let auto1x2: '1' | 'X' | '2' | null = cur.outcome1x2;
    if (nextHome !== null && nextAway !== null) {
      if (nextHome > nextAway) auto1x2 = '1';
      else if (nextAway > nextHome) auto1x2 = '2';
      else auto1x2 = 'X';
    }

    setPicks({
      ...picks,
      [matchId]: {
        ...cur,
        homeScore: nextHome,
        awayScore: nextAway,
        outcome1x2: auto1x2,
      },
    });
    setValidationError(null);
  };

  const handleQuickStep = (matchId: string, side: 'home' | 'away', delta: number) => {
    const match = liveMatches.find((m) => m.id === matchId);
    if (match && isMatchLocked(match)) return;

    const cur = picks[matchId] || {
      homeScore: null,
      awayScore: null,
      outcome1x2: null,
      goalscorerName: '',
      goalscorerTeam: '',
    };
    const curVal = (side === 'home' ? cur.homeScore : cur.awayScore) ?? 0;
    const nextVal = Math.max(0, curVal + delta);
    handleScoreChange(matchId, side, String(nextVal));
  };

  // 2. Update 1N2 (Catégorie B)
  const handleOutcomeChange = (matchId: string, outcome: '1' | 'X' | '2') => {
    const match = liveMatches.find((m) => m.id === matchId);
    if (match && isMatchLocked(match)) return;

    const cur = picks[matchId] || {
      homeScore: null,
      awayScore: null,
      outcome1x2: null,
      goalscorerName: '',
      goalscorerTeam: '',
    };

    setPicks({
      ...picks,
      [matchId]: {
        ...cur,
        outcome1x2: outcome,
      },
    });
    setValidationError(null);
  };

  // 3. Update Buteur (Catégorie A)
  const handleGoalscorerChange = (matchId: string, playerName: string, team: string) => {
    const match = liveMatches.find((m) => m.id === matchId);
    if (match && isMatchLocked(match)) return;

    const cur = picks[matchId] || {
      homeScore: null,
      awayScore: null,
      outcome1x2: null,
      goalscorerName: '',
      goalscorerTeam: '',
    };

    setPicks({
      ...picks,
      [matchId]: {
        ...cur,
        goalscorerName: playerName,
        goalscorerTeam: team,
      },
    });
  };

  // Individual match confirmation (Requirement 2 & 3: Saisir Real Madrid 2-1 Barca puis confirmer)
  const handleConfirmSingleMatch = async (matchId: string) => {
    if (!user) {
      onOpenLogin();
      return;
    }

    const match = liveMatches.find((m) => m.id === matchId);
    if (!match) return;

    if (isMatchLocked(match)) {
      setSingleFeedback((prev) => ({
        ...prev,
        [matchId]: {
          type: 'error',
          message: 'Pronostics fermés — le match a commencé. Modification refusée.',
        },
      }));
      return;
    }

    const p = picks[matchId];
    if (!p || p.homeScore === null || p.awayScore === null) {
      setSingleFeedback((prev) => ({
        ...prev,
        [matchId]: {
          type: 'error',
          message: 'Veuillez renseigner le score exact (ex : 2–1) avant de confirmer.',
        },
      }));
      return;
    }

    setSingleConfirmingId(matchId);
    try {
      const res = await fetch('/api/predictions/match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          challengeId: challenge.id,
          userId: user.id,
          matchId: match.id,
          homeScore: p.homeScore,
          awayScore: p.awayScore,
          outcome1X2: p.outcome1x2,
          goalscorerName: p.goalscorerName,
          tier: selectedTier,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSavedPicks((prev) => ({
          ...prev,
          [match.id]: data.pick,
        }));
        setSingleFeedback((prev) => ({
          ...prev,
          [matchId]: {
            type: 'success',
            message: `Pronostic confirmé avec succès : ${match.homeTeam} ${p.homeScore}–${p.awayScore} ${match.awayTeam}`,
          },
        }));
      } else {
        setSingleFeedback((prev) => ({
          ...prev,
          [matchId]: {
            type: 'error',
            message: data.error || 'Erreur lors de l’enregistrement du pronostic.',
          },
        }));
      }
    } catch (e: any) {
      setSingleFeedback((prev) => ({
        ...prev,
        [matchId]: {
          type: 'error',
          message: 'Erreur réseau lors de la confirmation.',
        },
      }));
    } finally {
      setSingleConfirmingId(null);
    }
  };

  // Check how many matches have scores entered
  const completedCount = liveMatches.filter((m) => {
    const p = picks[m.id];
    return p && p.homeScore !== null && p.awayScore !== null;
  }).length;

  const handleValidateGrid = () => {
    if (!user) {
      onOpenLogin();
      return;
    }

    const missing = liveMatches.filter((m) => {
      const p = picks[m.id];
      return !isMatchLocked(m) && (p.homeScore === null || p.awayScore === null);
    });

    if (missing.length > 0) {
      setValidationError(
        `Veuillez saisir votre score pour les ${missing.length} match(s) restant(s) avant de valider votre grille.`
      );
      return;
    }

    setShowSummary(true);
  };

  const handleConfirmSubmit = () => {
    if (!user) return;

    const formattedPicks: MatchPick[] = liveMatches.map((m) => {
      const p = picks[m.id] || {
        homeScore: 0,
        awayScore: 0,
        outcome1x2: 'X',
        goalscorerName: '',
        goalscorerTeam: '',
      };
      const h = p.homeScore ?? 0;
      const a = p.awayScore ?? 0;

      let outcome: '1' | 'X' | '2' = p.outcome1x2 || 'X';
      if (!p.outcome1x2) {
        if (h > a) outcome = '1';
        else if (a > h) outcome = '2';
        else outcome = 'X';
      }

      return {
        matchId: m.id,
        homeScore: h,
        awayScore: a,
        outcome1x2: outcome,
        goalscorerId: p.goalscorerName ? `p-sel-${m.id}` : '',
        goalscorerName: p.goalscorerName || 'Non pronostiqué',
        goalscorerTeam: p.goalscorerTeam || m.homeTeam,
        kickoffTime: m.kickOffTime,
      };
    });

    onSubmitPredictions(selectedTier, formattedPicks);
    setShowSummary(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-5 sm:py-7 space-y-5 animate-fadeIn">
      {/* ----------------- 1. HEADER BANNER ----------------- */}
      <div className="rounded-3xl bg-gradient-to-r from-[#071326] via-[#0B254E] to-[#071326] border border-blue-500/30 p-5 sm:p-6 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-7 h-7 rounded-xl bg-blue-500/20 text-[#38BDF8] flex items-center justify-center font-bold">
                <Trophy className="w-4 h-4" />
              </span>
              <span className="text-xs font-black uppercase tracking-wider text-[#38BDF8]">
                {challenge.title} · Grille Officielle du Jour
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Pronostics des 10 Matchs du Challenge
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              Sélection officielle issue des grandes compétitions réelles. Pronostiquez le score exact avant le coup d'envoi. Fermeture automatique dès le début du match.
            </p>
          </div>

          {/* Tier Switcher (Bronze / Silver / Gold) */}
          <div className="flex items-center gap-1 bg-[#060D19] p-1 rounded-2xl border border-slate-800 text-xs self-start sm:self-auto">
            {(['bronze', 'silver', 'gold'] as ChallengeTier[]).map((tier) => {
              const fee = tier === 'bronze' ? '100' : tier === 'silver' ? '250' : '500';
              const isSel = selectedTier === tier;
              return (
                <button
                  key={tier}
                  onClick={() => setSelectedTier(tier)}
                  className={`px-3 py-1.5 rounded-xl font-black transition cursor-pointer capitalize ${
                    isSel
                      ? tier === 'bronze'
                        ? 'bg-amber-700 text-white shadow'
                        : tier === 'silver'
                        ? 'bg-slate-300 text-slate-900 shadow'
                        : 'bg-amber-400 text-slate-950 shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tier} ({fee} G)
                </button>
              );
            })}
          </div>
        </div>

        {/* Notice if less than 10 matches are available today */}
        {missingMatchesNotice > 0 && (
          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
            <Info className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Information officielle :</strong> {liveMatches.length} match(s) réel(s) éligible(s) aujourd'hui. Aucun faux match n'est inventé ({missingMatchesNotice} match(s) manquant(s) selon le calendrier officiel).
            </span>
          </div>
        )}

        {/* 3 Categories Rules & Points Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-slate-800/80 text-xs">
          <div className="p-2.5 rounded-xl bg-[#060D19]/60 border border-slate-800/80 flex items-center gap-2">
            <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-black flex items-center justify-center text-[10px] shrink-0">
              C
            </span>
            <div className="min-w-0">
              <strong className="text-white text-[11px] block">Score Exact (+10 pts)</strong>
              <span className="text-[10px] text-slate-400">Score exact saisi avant le coup d'envoi</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#060D19]/60 border border-slate-800/80 flex items-center gap-2">
            <span className="w-6 h-6 rounded-lg bg-[#38BDF8]/20 text-[#38BDF8] font-black flex items-center justify-center text-[10px] shrink-0">
              B
            </span>
            <div className="min-w-0">
              <strong className="text-white text-[11px] block">1N2 (+3 pts)</strong>
              <span className="text-[10px] text-slate-400">Victoire 1, Nul X, Victoire 2</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#060D19]/60 border border-slate-800/80 flex items-center gap-2">
            <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 font-black flex items-center justify-center text-[10px] shrink-0">
              A
            </span>
            <div className="min-w-0">
              <strong className="text-white text-[11px] block">Buteur (+5 pts)</strong>
              <span className="text-[10px] text-slate-400">Joueur qui marque pendant le match</span>
            </div>
          </div>
        </div>

        {/* Challenge Live Navigation shortcut */}
        {onNavigateToLive && (
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-slate-300 text-[11px]">
              Suivez les 10 matchs en temps réel avec scores et visionnage officiel :
            </span>
            <button
              onClick={onNavigateToLive}
              className="px-3 py-1 rounded-xl bg-red-600/90 hover:bg-red-600 text-white font-black text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
              <span>Ouvrir Challenge Live</span>
            </button>
          </div>
        )}
      </div>

      {/* ----------------- SUB-TABS: MES PRONOSTICS vs PRONOSTICS DES PARTICIPANTS ----------------- */}
      <div className="grid grid-cols-2 p-1.5 rounded-2xl bg-[#060D19] border border-slate-800 gap-1.5">
        <button
          type="button"
          onClick={() => setActiveSubTab('my_picks')}
          className={`py-2.5 px-4 rounded-xl font-black text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
            activeSubTab === 'my_picks'
              ? 'bg-[#0B61DF] text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>Mes Pronostics ({liveMatches.length} Matchs)</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setActiveSubTab('all_participants');
            loadPublicPredictions();
          }}
          className={`py-2.5 px-4 rounded-xl font-black text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
            activeSubTab === 'all_participants'
              ? 'bg-[#0B61DF] text-white shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4 text-blue-300" />
          <span>Pronostics des Participants</span>
        </button>
      </div>

      {activeSubTab === 'my_picks' && (
        <>
          {/* ----------------- 2. PROGRESS BAR & VALIDATION STATUS ----------------- */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-[#091528] border border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400 shrink-0" />
              <span className="text-slate-300">
                Pronostics préparés : <strong className="text-white font-mono">{completedCount}</strong> sur <strong>{liveMatches.length}</strong> matchs
              </span>
            </div>

        <button
          onClick={handleValidateGrid}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs transition cursor-pointer shadow-md flex items-center justify-center gap-1.5"
        >
          <span>Valider toute la Grille ({selectedTier.toUpperCase()})</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {validationError && (
        <div className="p-3.5 rounded-2xl bg-red-950/40 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{validationError}</span>
        </div>
      )}

      {/* ----------------- 3. THE 10 MATCHES CARDS ----------------- */}
      <div className="space-y-4">
        {liveMatches.map((match, idx) => {
          const locked = isMatchLocked(match);
          const p = picks[match.id] || {
            homeScore: null,
            awayScore: null,
            outcome1x2: null,
            goalscorerName: '',
            goalscorerTeam: '',
          };

          const saved = savedPicks[match.id] || (match.apiFixtureId && savedPicks[String(match.apiFixtureId)]);
          const feedback = singleFeedback[match.id];

          const isFinished =
            match.status === 'finished' ||
            ['FT', 'AET', 'PEN'].includes((match.statusShort || '').toUpperCase());

          const isLive =
            match.status === 'live' ||
            ['1H', 'HT', '2H', 'ET', 'LIVE'].includes((match.statusShort || '').toUpperCase());

          const allPlayers = [
            ...(match.homePlayers || []).map((pl) => ({ ...pl, teamName: match.homeTeam })),
            ...(match.awayPlayers || []).map((pl) => ({ ...pl, teamName: match.awayTeam })),
          ];

          return (
            <div
              key={match.id}
              className={`rounded-2xl border transition overflow-hidden shadow-sm ${
                locked
                  ? 'bg-[#060D19]/90 border-slate-800/80'
                  : 'bg-[#091528] border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Header: Match #, Competition, Time & Status */}
              <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2 bg-[#060D19] border-b border-slate-800 text-[11px]">
                <div className="flex items-center gap-2 truncate">
                  <span className="font-mono font-black text-amber-400 text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/30">
                    Match #{match.matchNumber || idx + 1}
                  </span>
                  {match.homeLogo && (
                    <img src={match.homeLogo} alt="" className="w-3.5 h-3.5 object-contain rounded-xs" />
                  )}
                  <span className="font-bold text-slate-300 truncate uppercase text-[10px]">
                    {match.competition}
                  </span>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {/* Status Badges */}
                  {isFinished ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-black text-slate-300 px-2 py-0.5 rounded bg-slate-800 border border-slate-700">
                      TERMINÉ · Résultat officiel : {match.homeScore ?? 0} - {match.awayScore ?? 0}
                    </span>
                  ) : isLive ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-black text-red-400 px-2 py-0.5 rounded bg-red-500/10 border border-red-500/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-ping" />
                      EN DIRECT · {match.elapsed ? `${match.elapsed}'` : 'Score live'} : {match.homeScore ?? 0} - {match.awayScore ?? 0}
                    </span>
                  ) : locked ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-black text-amber-400 px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30">
                      <Lock className="w-3 h-3" />
                      COUP D'ENVOI DÉPASSÉ
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                      <Clock className="w-3 h-3 text-emerald-400" />
                      PROGRAMMÉ · Coup d'envoi à {(match as any).time || (match.kickOffTime ? new Date(match.kickOffTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '20:00')}
                    </span>
                  )}

                  {/* Bouton VOIR LES JOUEURS */}
                  <button
                    onClick={() => {
                      setPlayersModalFixtureId((match as any).apiFixtureId || match.id);
                      setPlayersModalMatchInfo(match);
                    }}
                    className="p-1 rounded bg-blue-950/60 hover:bg-blue-900/80 text-blue-300 text-[10px] font-bold flex items-center gap-1 border border-blue-800/60 cursor-pointer"
                    title="Voir les joueurs des deux équipes (Effectifs & Compositions)"
                  >
                    <Users className="w-3 h-3 text-blue-400" />
                    <span>Voir les joueurs</span>
                  </button>

                  {/* Bouton REGARDER */}
                  <button
                    onClick={() => {
                      setActiveModalFixtureId((match as any).apiFixtureId || match.id);
                      setActiveModalMatchInfo(match);
                      setModalInitialTab('watch');
                    }}
                    className="p-1 rounded bg-red-950/40 hover:bg-red-900/60 text-red-300 text-[10px] font-bold flex items-center gap-1 border border-red-900/50 cursor-pointer"
                    title="Regarder le match (Diffuseurs Officiels)"
                  >
                    <Tv className="w-3 h-3 text-red-400" />
                    <span className="hidden sm:inline">Regarder</span>
                  </button>

                  {/* Bouton DÉTAILS */}
                  <button
                    onClick={() => {
                      setActiveModalFixtureId((match as any).apiFixtureId || match.id);
                      setActiveModalMatchInfo(match);
                      setModalInitialTab('summary');
                    }}
                    className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                    title="Détails du match"
                  >
                    <Info className="w-3 h-3 text-blue-400" />
                    <span className="hidden sm:inline">Détails</span>
                  </button>
                </div>
              </div>

              {/* Requirement 6: Le message « Pronostics fermés — le match a commencé » dès le début du match */}
              {locked && (
                <div className="px-3.5 py-2 bg-amber-950/40 border-b border-amber-500/30 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 text-amber-300 font-bold">
                    <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Pronostics fermés — le match a commencé</span>
                  </div>
                  {saved ? (
                    <div className="flex items-center gap-2 text-emerald-300 text-[11px] font-mono">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>
                        Pronostic officiel enregistré : <strong>{match.homeTeam} {saved.homeScore}–{saved.awayScore} {match.awayTeam}</strong> (1N2 : {saved.outcome1X2})
                      </span>
                    </div>
                  ) : (
                    <span className="text-slate-400 text-[11px]">
                      Aucun pronostic enregistré avant le coup d'envoi.
                    </span>
                  )}
                </div>
              )}

              {/* Match Score Predictor Arena */}
              <div className="p-3 sm:p-4 space-y-3">
                {/* Balanced Teams Display & Score Inputs */}
                <div className="grid grid-cols-12 items-center gap-2">
                  {/* Home Team (4 cols) */}
                  <div className="col-span-4 flex items-center gap-2 min-w-0">
                    <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-slate-900 border border-slate-800 p-1 flex items-center justify-center shrink-0">
                      {match.homeLogo ? (
                        <img src={match.homeLogo} alt="" className="w-full h-full object-contain" />
                      ) : (
                        <Shield className="w-4 h-4 text-blue-400" />
                      )}
                    </div>
                    <span className="text-xs sm:text-sm font-black text-white truncate">
                      {match.homeTeam}
                    </span>
                  </div>

                  {/* Center: Score Inputs (Catégorie C) (4 cols) */}
                  <div className="col-span-4 flex items-center justify-center gap-2">
                    {/* Home Score Stepper */}
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        disabled={locked}
                        onClick={() => handleQuickStep(match.id, 'home', -1)}
                        className="w-6 h-6 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-mono font-bold flex items-center justify-center disabled:opacity-30 cursor-pointer"
                      >
                        -
                      </button>
                      <input
                        type="number"
                        min="0"
                        max="20"
                        disabled={locked}
                        value={p.homeScore !== null ? p.homeScore : ''}
                        onChange={(e) => handleScoreChange(match.id, 'home', e.target.value)}
                        placeholder="0"
                        className="w-10 h-10 rounded-xl bg-[#060D19] border border-slate-700 text-center font-mono font-black text-base text-white focus:outline-none focus:border-blue-500 disabled:opacity-50"
                      />
                      <button
                        type="button"
                        disabled={locked}
                        onClick={() => handleQuickStep(match.id, 'home', 1)}
                        className="w-6 h-6 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-mono font-bold flex items-center justify-center disabled:opacity-30 cursor-pointer"
                      >
                        +
                      </button>
                    </div>

                    <span className="text-slate-500 font-bold">:</span>

                    {/* Away Score Stepper */}
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        disabled={locked}
                        onClick={() => handleQuickStep(match.id, 'away', -1)}
                        className="w-6 h-6 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-mono font-bold flex items-center justify-center disabled:opacity-30 cursor-pointer"
                      >
                        -
                      </button>
                      <input
                        type="number"
                        min="0"
                        max="20"
                        disabled={locked}
                        value={p.awayScore !== null ? p.awayScore : ''}
                        onChange={(e) => handleScoreChange(match.id, 'away', e.target.value)}
                        placeholder="0"
                        className="w-10 h-10 rounded-xl bg-[#060D19] border border-slate-700 text-center font-mono font-black text-base text-white focus:outline-none focus:border-blue-500 disabled:opacity-50"
                      />
                      <button
                        type="button"
                        disabled={locked}
                        onClick={() => handleQuickStep(match.id, 'away', 1)}
                        className="w-6 h-6 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-mono font-bold flex items-center justify-center disabled:opacity-30 cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  {/* Away Team (4 cols) */}
                  <div className="col-span-4 flex items-center justify-end gap-2 min-w-0 text-right">
                    <span className="text-xs sm:text-sm font-black text-white truncate text-right">
                      {match.awayTeam}
                    </span>
                    <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-slate-900 border border-slate-800 p-1 flex items-center justify-center shrink-0">
                      {match.awayLogo ? (
                        <img src={match.awayLogo} alt="" className="w-full h-full object-contain" />
                      ) : (
                        <Shield className="w-4 h-4 text-blue-400" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Sub-Panel: Catégorie B (1N2) & Catégorie A (Buteur) + Bouton Confirmer ce match */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-2 border-t border-slate-800/80 text-xs">
                  {/* Catégorie B: 1N2 Selector (4 cols) */}
                  <div className="sm:col-span-4 flex items-center gap-1.5">
                    <span className="text-[10px] font-black uppercase text-[#38BDF8] shrink-0">
                      1N2 :
                    </span>
                    <div className="grid grid-cols-3 gap-1 flex-1">
                      {(['1', 'X', '2'] as const).map((outcome) => {
                        const isChosen = p.outcome1x2 === outcome;
                        const label = outcome === '1' ? '1' : outcome === 'X' ? 'N' : '2';
                        return (
                          <button
                            key={outcome}
                            type="button"
                            disabled={locked}
                            onClick={() => handleOutcomeChange(match.id, outcome)}
                            className={`py-1 rounded-lg font-black text-[10px] transition cursor-pointer border ${
                              isChosen
                                ? 'bg-[#0B61DF] text-white border-blue-400 shadow'
                                : 'bg-[#060D19] text-slate-400 border-slate-800 hover:text-white'
                            }`}
                          >
                            {label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Catégorie A: Buteur Selector (5 cols) */}
                  <div className="sm:col-span-5 flex items-center gap-1.5">
                    <span className="text-[10px] font-black uppercase text-amber-400 shrink-0">
                      Buteur :
                    </span>
                    <div className="relative flex-1">
                      <select
                        disabled={locked}
                        value={p.goalscorerName}
                        onChange={(e) => {
                          const chosen = allPlayers.find((x) => x.name === e.target.value);
                          handleGoalscorerChange(match.id, e.target.value, chosen?.teamName || match.homeTeam);
                        }}
                        className="w-full py-1 px-2.5 rounded-lg bg-[#060D19] border border-slate-800 text-[11px] text-white focus:outline-none focus:border-blue-500 disabled:opacity-50 appearance-none truncate"
                      >
                        <option value="">Sélectionner un buteur...</option>
                        {allPlayers.map((pl, pIdx) => (
                          <option key={pIdx} value={pl.name}>
                            {pl.name} ({pl.teamName})
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-2 pointer-events-none" />
                    </div>
                  </div>

                  {/* Requirement 2: Bouton Pronostiquer / Confirmer ce match (3 cols) */}
                  <div className="sm:col-span-3 flex items-center justify-end">
                    {!locked ? (
                      <button
                        type="button"
                        onClick={() => handleConfirmSingleMatch(match.id)}
                        disabled={singleConfirmingId === match.id}
                        className={`w-full py-1.5 px-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center justify-center gap-1.5 ${
                          saved
                            ? 'bg-emerald-600/80 hover:bg-emerald-600 text-white'
                            : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md'
                        }`}
                      >
                        {singleConfirmingId === match.id ? (
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        ) : saved ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-200" />
                            <span>Mettre à jour</span>
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                            <span>Pronostiquer</span>
                          </>
                        )}
                      </button>
                    ) : (
                      <div className="text-[11px] text-slate-500 flex items-center gap-1 font-mono justify-end">
                        <Lock className="w-3 h-3 text-slate-500" />
                        <span>Verrouillé</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Single match feedback feedback banner */}
                {feedback && (
                  <div
                    className={`p-2 rounded-xl text-xs flex items-center gap-2 ${
                      feedback.type === 'success'
                        ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-500/30'
                        : 'bg-red-950/40 text-red-300 border border-red-500/30'
                    }`}
                  >
                    {feedback.type === 'success' ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                    )}
                    <span>{feedback.message}</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
        </>
      )}

      {/* ----------------- PRONOSTICS DES PARTICIPANTS (PUBLIC VIEW) ----------------- */}
      {activeSubTab === 'all_participants' && (
        <div className="space-y-4 animate-fadeIn">
          {/* Privacy & Fairness Information Banner */}
          <div className="p-4 rounded-2xl bg-[#091528] border border-blue-500/30 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">
                    Pronostics Officiels des Participants
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Consultez les scores exacts prédits par les joueurs pour chacun des 10 matchs sélectionnés du jour
                  </p>
                </div>
              </div>

              {/* Admin Mode Confidentialité Toggle (Requirement 2) */}
              {user?.role === 'admin' && (
                <div className="flex items-center gap-2 p-1.5 px-3 rounded-xl bg-[#060D19] border border-slate-700 text-xs shrink-0">
                  <span className="text-[11px] text-slate-300 font-bold">Confidentialité Admin :</span>
                  <button
                    type="button"
                    onClick={handleTogglePrivacyMode}
                    disabled={togglingPrivacy}
                    className={`px-2.5 py-1 rounded-lg font-black text-[10px] transition cursor-pointer flex items-center gap-1.5 ${
                      publicData?.privacyModeActive
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    }`}
                  >
                    {publicData?.privacyModeActive ? (
                      <>
                        <EyeOff className="w-3 h-3 text-amber-400" />
                        <span>Masqué jusqu'au coup d'envoi</span>
                      </>
                    ) : (
                      <>
                        <Eye className="w-3 h-3 text-emerald-400" />
                        <span>Visible en temps réel</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Privacy rule notice */}
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Lock className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                {publicData?.privacyModeActive ? (
                  <span>
                    <strong>Mode Confidentialité Actif :</strong> Pour éviter la copie de prédictions, les scores des autres participants sont masqués jusqu'au coup d'envoi officiel. Dès le début du match, ils deviennent visibles par tous en lecture seule.
                  </span>
                ) : (
                  <span>
                    <strong>Mode Public Actif :</strong> Tous les pronostics enregistrés sont consultables en direct par l'ensemble des participants.
                  </span>
                )}
              </span>
            </div>
          </div>

          {/* Matches & Participant Predictions List */}
          {loadingPublic ? (
            <div className="py-16 text-center space-y-3">
              <RefreshCw className="w-8 h-8 text-blue-400 animate-spin mx-auto" />
              <p className="text-xs text-slate-400 font-medium">
                Chargement des pronostics certifiés des participants...
              </p>
            </div>
          ) : (publicData?.matches || []).length === 0 ? (
            <div className="py-12 text-center p-4 rounded-2xl bg-[#091528] border border-slate-800 text-slate-400 space-y-2">
              <Users className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-white">Aucun match disponible pour cette journée</p>
            </div>
          ) : (
            <div className="space-y-4">
              {(publicData?.matches || []).map((m: any, mIdx: number) => {
                const matchIsClosed = m.isClosed;
                const predsList = m.predictions || [];

                return (
                  <div
                    key={m.matchId || mIdx}
                    className="rounded-2xl bg-[#091528] border border-slate-800 overflow-hidden shadow-sm"
                  >
                    {/* Header: Team names, logos, competition, date/time & Voir les joueurs */}
                    <div className="p-3.5 sm:p-4 bg-[#060D19] border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="font-mono font-black text-amber-400 text-xs px-2 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/30">
                          Match #{m.matchNumber || mIdx + 1}
                        </span>

                        <div className="flex items-center gap-2 min-w-0">
                          {/* Home Team */}
                          <div className="flex items-center gap-1.5">
                            {m.homeLogo ? (
                              <img src={m.homeLogo} alt="" className="w-5 h-5 object-contain" />
                            ) : (
                              <Shield className="w-4 h-4 text-blue-400" />
                            )}
                            <strong className="text-white text-xs sm:text-sm font-black truncate max-w-[120px] sm:max-w-none">
                              {m.homeTeam}
                            </strong>
                          </div>

                          <span className="text-slate-500 font-black text-xs">vs</span>

                          {/* Away Team */}
                          <div className="flex items-center gap-1.5">
                            {m.awayLogo ? (
                              <img src={m.awayLogo} alt="" className="w-5 h-5 object-contain" />
                            ) : (
                              <Shield className="w-4 h-4 text-emerald-400" />
                            )}
                            <strong className="text-white text-xs sm:text-sm font-black truncate max-w-[120px] sm:max-w-none">
                              {m.awayTeam}
                            </strong>
                          </div>
                        </div>
                      </div>

                      {/* Right: Competition, Kickoff & Actions */}
                      <div className="flex items-center gap-2 shrink-0">
                        <div className="text-right hidden sm:block">
                          <span className="text-[10px] font-bold text-slate-400 block uppercase">
                            {m.competition}
                          </span>
                          <span className="text-[11px] font-mono text-emerald-400">
                            {m.time ? `${m.time}` : '20:00'} · {m.date || 'Aujourd\'hui'}
                          </span>
                        </div>

                        {/* Status Badge */}
                        {matchIsClosed ? (
                          <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[10px] font-black uppercase flex items-center gap-1">
                            <Lock className="w-3 h-3 text-amber-400" />
                            <span>Fermé</span>
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 text-[10px] font-black uppercase flex items-center gap-1">
                            <Clock className="w-3 h-3 text-emerald-400" />
                            <span>Ouvert</span>
                          </span>
                        )}

                        {/* Bouton Voir les joueurs */}
                        <button
                          type="button"
                          onClick={() => {
                            setPlayersModalFixtureId(m.apiFixtureId || m.matchId);
                            setPlayersModalMatchInfo(m);
                          }}
                          className="px-2.5 py-1 rounded-xl bg-blue-950/60 hover:bg-blue-900/80 text-blue-300 text-[11px] font-bold flex items-center gap-1.5 border border-blue-800/60 cursor-pointer"
                        >
                          <Users className="w-3.5 h-3.5 text-blue-400" />
                          <span>Voir les joueurs</span>
                        </button>
                      </div>
                    </div>

                    {/* Participants Predictions Table */}
                    <div className="p-3 sm:p-4">
                      {predsList.length === 0 ? (
                        <div className="py-6 text-center text-xs text-slate-500 italic">
                          Aucun pronostic enregistré par les participants sur ce match pour l'instant.
                        </div>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-xs">
                            <thead>
                              <tr className="border-b border-slate-800/80 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                                <th className="pb-2">Participant</th>
                                <th className="pb-2">Catégorie</th>
                                <th className="pb-2 text-center">Score Exact Prédit</th>
                                <th className="pb-2 text-center">Choix 1N2</th>
                                <th className="pb-2 text-right">Horodatage</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800/50">
                              {predsList.map((pred: any, pIdx: number) => {
                                const isSelf = pred.isOwner;

                                return (
                                  <tr
                                    key={pred.predictionId || pIdx}
                                    className={`hover:bg-slate-800/20 transition ${
                                      isSelf ? 'bg-blue-950/20' : ''
                                    }`}
                                  >
                                    <td className="py-2.5 font-bold text-white flex items-center gap-2">
                                      <span className="font-mono text-slate-400 text-[11px]">
                                        {pred.participantNumber || `#${pIdx + 1}`}
                                      </span>
                                      <span className="truncate">
                                        {pred.participantName}
                                      </span>
                                      {isSelf && (
                                        <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                                          Vous
                                        </span>
                                      )}
                                    </td>

                                    <td className="py-2.5">
                                      <span className="font-black text-[10px] uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                                        {pred.tier || 'bronze'}
                                      </span>
                                    </td>

                                    <td className="py-2.5 text-center">
                                      {pred.isMasked ? (
                                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400 text-[11px] font-mono">
                                          <Lock className="w-3 h-3 text-amber-400" />
                                          <span>Masqué (Confidentialité)</span>
                                        </span>
                                      ) : (
                                        <span className="inline-block px-2.5 py-0.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-mono font-black text-xs">
                                          {pred.exactScore || `${pred.homeScore}–${pred.awayScore}`}
                                        </span>
                                      )}
                                    </td>

                                    <td className="py-2.5 text-center">
                                      {pred.isMasked ? (
                                        <span className="text-slate-600">-</span>
                                      ) : (
                                        <span className="font-black text-xs px-2 py-0.5 rounded bg-blue-500/10 text-blue-300">
                                          {pred.outcome1X2 || 'X'}
                                        </span>
                                      )}
                                    </td>

                                    <td className="py-2.5 text-right text-[11px] font-mono text-slate-400">
                                      {pred.submittedAt
                                        ? new Date(pred.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                                        : '-'}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ----------------- 4. SUMMARY MODAL CONFIRMATION ----------------- */}
      {showSummary && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#091528] border border-slate-700 rounded-3xl w-full max-w-lg p-5 sm:p-6 space-y-4 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" />
                Validation de ma Grille Officielle
              </h3>
              <span className="text-xs font-black uppercase px-2 py-0.5 rounded bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
                {selectedTier.toUpperCase()}
              </span>
            </div>

            <p className="text-xs text-slate-300">
              Vous vous apprêtez à enregistrer vos pronostics pour les 10 matchs officiels du Challenge Foot. Les pronostics sont automatiquement verrouillés au coup d'envoi de chaque match.
            </p>

            <div className="p-3.5 rounded-2xl bg-[#060D19] border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Catégorie choisie :</span>
                <strong className="text-white capitalize">{selectedTier}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Frais d'entrée :</span>
                <strong className="text-emerald-400 font-mono">
                  {selectedTier === 'bronze' ? '100' : selectedTier === 'silver' ? '250' : '500'} HTG
                </strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Matchs pronostiqués :</span>
                <strong className="text-white font-mono">{completedCount} / {liveMatches.length}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Verrouillage officiel :</span>
                <strong className="text-amber-400">Automatique au coup d'envoi côté serveur</strong>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setShowSummary(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                Modifier
              </button>
              <button
                onClick={handleConfirmSubmit}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs transition cursor-pointer shadow-md"
              >
                Confirmer & Enregistrer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- 5. DETAILED MATCH MODAL ----------------- */}
      {activeModalFixtureId && (
        <MatchDetailsModal
          fixtureId={activeModalFixtureId}
          initialMatchInfo={activeModalMatchInfo}
          initialTab={modalInitialTab}
          onClose={() => setActiveModalFixtureId(null)}
          onNavigateToChallenge={() => setActiveModalFixtureId(null)}
        />
      )}

      {/* ----------------- 6. VOIR LES JOUEURS MODAL (SQUADS & LINEUPS) ----------------- */}
      {playersModalFixtureId && (
        <MatchPlayersModal
          fixtureId={playersModalFixtureId}
          matchInfo={playersModalMatchInfo}
          onClose={() => {
            setPlayersModalFixtureId(null);
            setPlayersModalMatchInfo(null);
          }}
        />
      )}
    </div>
  );
};
