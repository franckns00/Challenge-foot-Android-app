import React, { useState, useEffect } from 'react';
import {
  X,
  Play,
  Shield,
  Clock,
  Calendar,
  MapPin,
  User,
  Users,
  BarChart3,
  ListOrdered,
  Sparkles,
  Tv,
  ExternalLink,
  AlertCircle,
  CheckCircle2,
  Lock,
  ChevronRight,
  Flame,
  RotateCcw,
  Maximize2,
  Settings,
  Pause,
  RefreshCw,
  Volume2,
} from 'lucide-react';

interface MatchDetailsModalProps {
  fixtureId: number | string;
  initialMatchInfo?: any;
  onClose: () => void;
  onNavigateToChallenge?: () => void;
  initialTab?: 'summary' | 'lineups' | 'stats' | 'events' | 'predictions' | 'watch';
}

export const MatchDetailsModal: React.FC<MatchDetailsModalProps> = ({
  fixtureId,
  initialMatchInfo,
  onClose,
  onNavigateToChallenge,
  initialTab = 'summary',
}) => {
  const [activeTab, setActiveTab] = useState<'summary' | 'lineups' | 'stats' | 'events' | 'predictions' | 'watch'>(initialTab);
  const [data, setData] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Dedicated Video Streaming States
  const [streamInfo, setStreamInfo] = useState<any | null>(null);
  const [streamLoading, setStreamLoading] = useState<boolean>(false);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isResumed, setIsResumed] = useState<boolean>(false);
  const [playbackTime, setPlaybackTime] = useState<number>(0);
  const [showProviderModal, setShowProviderModal] = useState<boolean>(false);
  const [customStreamUrl, setCustomStreamUrl] = useState<string>('');
  const [customEmbedCode, setCustomEmbedCode] = useState<string>('');
  const [customProviderName, setCustomProviderName] = useState<string>('');
  const [adminStreamMessage, setAdminStreamMessage] = useState<string | null>(null);

  // Fetch verified stream information for this exact locked match
  const fetchStreamInfo = (targetId: string | number) => {
    const idToFetch = typeof targetId === 'string' && targetId.startsWith('m-api-')
      ? targetId.replace('m-api-', '')
      : targetId;

    setStreamLoading(true);
    fetch(`/api/football/fixture/${idToFetch}/stream`)
      .then((r) => r.json())
      .then((json) => {
        if (json.success) {
          setStreamInfo(json);
        }
      })
      .catch((e) => console.error('Failed to fetch stream details:', e))
      .finally(() => setStreamLoading(false));
  };

  useEffect(() => {
    if (activeTab === 'watch') {
      fetchStreamInfo(fixtureId);
    }
  }, [activeTab, fixtureId]);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);

    // Numeric fixture ID check
    const idToFetch = typeof fixtureId === 'string' && fixtureId.startsWith('m-api-')
      ? fixtureId.replace('m-api-', '')
      : fixtureId;

    fetch(`/api/football/fixture/${idToFetch}`)
      .then((r) => r.json())
      .then((json) => {
        if (!isMounted) return;
        if (json.success && json.data) {
          setData(json.data);
        } else {
          // If detailed API fails or match is upcoming with minimal API-Sports data
          setData(null);
          setError(json.message || 'Données détaillées en attente de publication par API-Football.');
        }
      })
      .catch((e) => {
        if (!isMounted) return;
        setError('Impossible de joindre le serveur pour charger les détails du match.');
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [fixtureId]);

  const summary = data?.summary || {
    id: fixtureId,
    league: { name: initialMatchInfo?.competition || 'Compétition Officielle', logo: initialMatchInfo?.leagueLogo },
    teams: {
      home: { name: initialMatchInfo?.homeTeam || 'Équipe Domicile', logo: initialMatchInfo?.homeLogo },
      away: { name: initialMatchInfo?.awayTeam || 'Équipe Extérieur', logo: initialMatchInfo?.awayLogo },
    },
    goals: { home: initialMatchInfo?.homeScore ?? null, away: initialMatchInfo?.awayScore ?? null },
    status: initialMatchInfo?.status || 'NS',
    statusLong: initialMatchInfo?.statusLong || 'À Venir',
    elapsed: initialMatchInfo?.elapsed,
    date: initialMatchInfo?.kickoffTime,
    venue: initialMatchInfo?.venue || 'Stade Officiel',
    referee: 'Officiel désigné',
  };

  const isLive = ['1H', '2H', 'ET', 'LIVE'].includes(summary.status);
  const isHT = summary.status === 'HT';
  const isFinished = ['FT', 'AET', 'PEN'].includes(summary.status);

  const displayStatus = isLive
    ? 'EN DIRECT'
    : isHT
    ? 'MI-TEMPS'
    : isFinished
    ? 'TERMINÉ'
    : 'À VENIR';

  const lineups = data?.lineups;
  const stats = data?.statistics;
  const events = data?.events || [];
  const broadcasting = data?.broadcasting;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#091528] border border-slate-700/80 rounded-3xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        
        {/* TOP BAR / HEADER */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#060D19] border-b border-slate-800">
          <div className="flex items-center gap-2 truncate">
            {summary.league?.logo ? (
              <img src={summary.league.logo} alt="" className="w-5 h-5 object-contain rounded bg-slate-900" />
            ) : (
              <span className="text-amber-400">🏆</span>
            )}
            <span className="text-xs font-black uppercase text-slate-300 truncate">
              {summary.league?.name} {summary.league?.round ? `· ${summary.league.round}` : ''}
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
              Challenge Foot #10
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* HERO SCOREBOARD */}
        <div className="p-4 sm:p-6 bg-gradient-to-b from-[#0B2144] via-[#091528] to-[#070F1E] border-b border-slate-800">
          <div className="grid grid-cols-12 items-center gap-2">
            
            {/* Home Team */}
            <div className="col-span-5 flex flex-col items-center text-center">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-900/90 border border-slate-700/80 p-2 flex items-center justify-center shadow-md mb-2">
                {summary.teams?.home?.logo ? (
                  <img src={summary.teams.home.logo} alt={summary.teams.home.name} className="w-full h-full object-contain" />
                ) : (
                  <Shield className="w-8 h-8 text-blue-400" />
                )}
              </div>
              <h2 className="text-xs sm:text-sm font-black text-white line-clamp-2">
                {summary.teams?.home?.name}
              </h2>
              {lineups?.home?.formation && (
                <span className="text-[10px] font-mono text-slate-400 mt-0.5">
                  Formation : {lineups.home.formation}
                </span>
              )}
            </div>

            {/* Score & Status Center */}
            <div className="col-span-2 flex flex-col items-center justify-center text-center">
              {/* Status Badge */}
              <div className="mb-1">
                {isLive ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-red-600/30 text-red-400 border border-red-500/50 animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 inline-block" />
                    LIVE {summary.elapsed ? `${summary.elapsed}'` : ''}
                  </span>
                ) : isHT ? (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    MI-TEMPS
                  </span>
                ) : isFinished ? (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-slate-800 text-slate-300 border border-slate-700">
                    TERMINÉ (FT)
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
                    À VENIR
                  </span>
                )}
              </div>

              {/* Numbers */}
              <div className="text-2xl sm:text-4xl font-mono font-black text-white tracking-wider">
                {summary.goals?.home !== null && summary.goals?.home !== undefined ? summary.goals.home : '-'}
                <span className="mx-1 text-slate-500">:</span>
                {summary.goals?.away !== null && summary.goals?.away !== undefined ? summary.goals.away : '-'}
              </div>

              {/* Kickoff / Date info */}
              <span className="text-[10px] text-slate-400 font-mono mt-1">
                {summary.date ? new Date(summary.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Coup d’envoi'}
              </span>
            </div>

            {/* Away Team */}
            <div className="col-span-5 flex flex-col items-center text-center">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-900/90 border border-slate-700/80 p-2 flex items-center justify-center shadow-md mb-2">
                {summary.teams?.away?.logo ? (
                  <img src={summary.teams.away.logo} alt={summary.teams.away.name} className="w-full h-full object-contain" />
                ) : (
                  <Shield className="w-8 h-8 text-blue-400" />
                )}
              </div>
              <h2 className="text-xs sm:text-sm font-black text-white line-clamp-2">
                {summary.teams?.away?.name}
              </h2>
              {lineups?.away?.formation && (
                <span className="text-[10px] font-mono text-slate-400 mt-0.5">
                  Formation : {lineups.away.formation}
                </span>
              )}
            </div>
          </div>

          {/* Goalscorers Subline (Under Home & Away) */}
          {(lineups?.home?.scorers?.length > 0 || lineups?.away?.scorers?.length > 0) && (
            <div className="grid grid-cols-2 gap-4 mt-3 pt-3 border-t border-slate-800 text-[11px]">
              <div className="text-left space-y-0.5">
                {lineups.home.scorers.map((g: any, i: number) => (
                  <p key={i} className="text-slate-300 flex items-center gap-1">
                    <span>⚽</span>
                    <strong>{g.player}</strong>
                    <span className="text-slate-400 font-mono">({g.minute}')</span>
                  </p>
                ))}
              </div>
              <div className="text-right space-y-0.5">
                {lineups.away.scorers.map((g: any, i: number) => (
                  <p key={i} className="text-slate-300 flex items-center justify-end gap-1">
                    <span className="text-slate-400 font-mono">({g.minute}')</span>
                    <strong>{g.player}</strong>
                    <span>⚽</span>
                  </p>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 6 NAVIGATION TABS (Style BeSoccer) */}
        <div className="flex items-center gap-1 px-3 py-2 bg-[#060D19] border-b border-slate-800 overflow-x-auto scrollbar-none text-xs select-none">
          {[
            { id: 'summary', label: 'Résumé', icon: Clock },
            { id: 'lineups', label: 'Composition', icon: Users },
            { id: 'stats', label: 'Statistiques', icon: BarChart3 },
            { id: 'events', label: 'Événements', icon: ListOrdered },
            { id: 'predictions', label: 'Pronostics', icon: Sparkles },
            { id: 'watch', label: 'Regarder le match', icon: Tv, highlight: true },
          ].map((tab) => {
            const Icon = tab.icon;
            const isTabActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer shrink-0 border ${
                  isTabActive
                    ? tab.highlight
                      ? 'bg-red-600 text-white border-red-500 shadow'
                      : 'bg-[#0B61DF] text-white border-blue-400 shadow'
                    : tab.highlight
                    ? 'bg-red-950/30 text-red-300 border-red-900/50 hover:bg-red-900/30'
                    : 'bg-[#091528] text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB CONTENTS (SCROLLABLE) */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4">
          
          {/* TAB 1: RÉSUMÉ */}
          {activeTab === 'summary' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-2xl bg-[#071120] border border-slate-800 space-y-2">
                  <h3 className="font-black text-slate-300 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-blue-400" />
                    Informations Générales
                  </h3>
                  <p className="flex justify-between py-1 border-b border-slate-800/80">
                    <span className="text-slate-400">Date du match :</span>
                    <strong className="text-white">{summary.date ? new Date(summary.date).toLocaleDateString() : 'Aujourd’hui'}</strong>
                  </p>
                  <p className="flex justify-between py-1 border-b border-slate-800/80">
                    <span className="text-slate-400">Heure de début :</span>
                    <strong className="text-white font-mono">{summary.date ? new Date(summary.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '20:00'}</strong>
                  </p>
                  <p className="flex justify-between py-1 border-b border-slate-800/80">
                    <span className="text-slate-400">Statut officiel :</span>
                    <strong className={isLive ? 'text-red-400 font-black' : 'text-slate-200'}>{summary.statusLong || displayStatus}</strong>
                  </p>
                  <p className="flex justify-between py-1">
                    <span className="text-slate-400">Compétition :</span>
                    <strong className="text-white">{summary.league?.name}</strong>
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-[#071120] border border-slate-800 space-y-2">
                  <h3 className="font-black text-slate-300 uppercase tracking-wider text-[10px] flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                    Lieu & Corps Arbitral
                  </h3>
                  <p className="flex justify-between py-1 border-b border-slate-800/80">
                    <span className="text-slate-400">Stade :</span>
                    <strong className="text-white truncate max-w-[180px]">{summary.venue || 'Stade Officiel'}</strong>
                  </p>
                  <p className="flex justify-between py-1 border-b border-slate-800/80">
                    <span className="text-slate-400">Arbitre principal :</span>
                    <strong className="text-white">{summary.referee || 'Officiel désigné'}</strong>
                  </p>
                  <p className="flex justify-between py-1">
                    <span className="text-slate-400">Score Mi-temps :</span>
                    <strong className="text-white font-mono">
                      {summary.score?.halftime?.home !== null && summary.score?.halftime?.home !== undefined
                        ? `${summary.score.halftime.home} - ${summary.score.halftime.away}`
                        : 'En attente'}
                    </strong>
                  </p>
                </div>
              </div>

              {/* Challenge Foot Integration Notice */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0B254E] to-[#071120] border border-blue-500/30 flex items-center justify-between gap-4">
                <div>
                  <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    Match Officiel du Challenge du Jour
                  </h4>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    Ce match fait partie intégrante de la sélection des 10 matchs officiels. Pronostiquez le buteur, le résultat (1N2) et le score exact.
                  </p>
                </div>
                {onNavigateToChallenge && (
                  <button
                    onClick={() => {
                      onClose();
                      onNavigateToChallenge();
                    }}
                    className="px-3.5 py-2 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-black text-xs shrink-0 cursor-pointer shadow"
                  >
                    Pronostiquer
                  </button>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: COMPOSITION (LINEUPS) */}
          {activeTab === 'lineups' && (
            <div className="space-y-4">
              {lineups && (lineups.home || lineups.away) ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Home Lineup */}
                  <div className="p-3.5 rounded-2xl bg-[#071120] border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        {summary.teams?.home?.logo && <img src={summary.teams.home.logo} alt="" className="w-5 h-5 object-contain" />}
                        <h4 className="font-black text-white text-xs">{summary.teams?.home?.name}</h4>
                      </div>
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-blue-300">
                        {lineups.home?.formation || '4-3-3'}
                      </span>
                    </div>

                    {lineups.home?.coach?.name && (
                      <p className="text-[11px] text-slate-400">
                        Entraîneur : <strong className="text-slate-200">{lineups.home.coach.name}</strong>
                      </p>
                    )}

                    {/* Titulaires */}
                    <div>
                      <h5 className="text-[10px] font-black uppercase text-slate-400 mb-1.5 tracking-wider">
                        Titulaires (XI de départ)
                      </h5>
                      <div className="space-y-1">
                        {lineups.home?.startXI?.map((p: any, idx: number) => (
                          <div key={idx} className="flex items-center justify-between py-1 px-2 rounded-lg bg-[#091528] text-xs">
                            <div className="flex items-center gap-2">
                              <span className="w-5 text-center font-mono font-bold text-slate-400 text-[11px]">
                                {p.number || '-'}
                              </span>
                              {p.photo && (
                                <img src={p.photo} alt="" className="w-5 h-5 rounded-full object-cover bg-slate-800" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
                              )}
                              <span className="font-semibold text-slate-200">{p.name}</span>
                            </div>
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                              {p.pos || 'J'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Remplaçants */}
                    {lineups.home?.substitutes?.length > 0 && (
                      <div>
                        <h5 className="text-[10px] font-black uppercase text-slate-400 mb-1.5 tracking-wider">
                          Remplaçants
                        </h5>
                        <div className="space-y-1">
                          {lineups.home.substitutes.slice(0, 7).map((p: any, idx: number) => (
                            <div key={idx} className="flex items-center justify-between py-0.5 px-2 text-[11px] text-slate-400">
                              <span>#{p.number} {p.name}</span>
                              <span className="text-[9px]">{p.pos}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Away Lineup */}
                  <div className="p-3.5 rounded-2xl bg-[#071120] border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        {summary.teams?.away?.logo && <img src={summary.teams.away.logo} alt="" className="w-5 h-5 object-contain" />}
                        <h4 className="font-black text-white text-xs">{summary.teams?.away?.name}</h4>
                      </div>
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-blue-300">
                        {lineups.away?.formation || '4-3-3'}
                      </span>
                    </div>

                    {lineups.away?.coach?.name && (
                      <p className="text-[11px] text-slate-400">
                        Entraîneur : <strong className="text-slate-200">{lineups.away.coach.name}</strong>
                      </p>
                    )}

                    {/* Titulaires */}
                    <div>
                      <h5 className="text-[10px] font-black uppercase text-slate-400 mb-1.5 tracking-wider">
                        Titulaires (XI de départ)
                      </h5>
                      <div className="space-y-1">
                        {lineups.away?.startXI?.map((p: any, idx: number) => (
                          <div key={idx} className="flex items-center justify-between py-1 px-2 rounded-lg bg-[#091528] text-xs">
                            <div className="flex items-center gap-2">
                              <span className="w-5 text-center font-mono font-bold text-slate-400 text-[11px]">
                                {p.number || '-'}
                              </span>
                              {p.photo && (
                                <img src={p.photo} alt="" className="w-5 h-5 rounded-full object-cover bg-slate-800" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
                              )}
                              <span className="font-semibold text-slate-200">{p.name}</span>
                            </div>
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                              {p.pos || 'J'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Remplaçants */}
                    {lineups.away?.substitutes?.length > 0 && (
                      <div>
                        <h5 className="text-[10px] font-black uppercase text-slate-400 mb-1.5 tracking-wider">
                          Remplaçants
                        </h5>
                        <div className="space-y-1">
                          {lineups.away.substitutes.slice(0, 7).map((p: any, idx: number) => (
                            <div key={idx} className="flex items-center justify-between py-0.5 px-2 text-[11px] text-slate-400">
                              <span>#{p.number} {p.name}</span>
                              <span className="text-[9px]">{p.pos}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-10 px-4 rounded-2xl bg-[#071120] border border-slate-800 space-y-2">
                  <Users className="w-8 h-8 text-slate-600 mx-auto" />
                  <p className="text-sm font-bold text-white">Compositions officielles en attente</p>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Conformément aux protocoles officiels des compétitions de football, les compositions des équipes et les remplaçants sont publiés par l'API-Football environ 45 à 60 minutes avant le coup d'envoi.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: STATISTIQUES */}
          {activeTab === 'stats' && (
            <div className="space-y-3">
              {stats?.items && stats.items.length > 0 ? (
                <div className="p-4 rounded-2xl bg-[#071120] border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between text-xs font-black pb-2 border-b border-slate-800">
                    <span className="text-blue-400 truncate max-w-[140px]">{stats.homeTeam || summary.teams?.home?.name}</span>
                    <span className="text-slate-400 uppercase tracking-wider text-[10px]">Statistiques Officielles</span>
                    <span className="text-emerald-400 truncate max-w-[140px] text-right">{stats.awayTeam || summary.teams?.away?.name}</span>
                  </div>

                  <div className="space-y-3">
                    {stats.items.map((st: any, idx: number) => {
                      const hVal = st.homeValue !== null && st.homeValue !== undefined ? st.homeValue : '-';
                      const aVal = st.awayValue !== null && st.awayValue !== undefined ? st.awayValue : '-';

                      // Numeric calculation for comparative progress bar
                      let hNum = typeof hVal === 'number' ? hVal : parseInt(String(hVal).replace('%', ''), 10) || 0;
                      let aNum = typeof aVal === 'number' ? aVal : parseInt(String(aVal).replace('%', ''), 10) || 0;
                      const total = hNum + aNum || 1;
                      const hPct = Math.min(100, Math.max(0, Math.round((hNum / total) * 100)));

                      return (
                        <div key={idx} className="space-y-1 text-xs">
                          <div className="flex justify-between items-center text-[11px]">
                            <strong className="font-mono text-white text-xs">{hVal}</strong>
                            <span className="text-slate-400 font-medium">{st.type}</span>
                            <strong className="font-mono text-white text-xs">{aVal}</strong>
                          </div>
                          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden flex">
                            <div className="bg-[#0B61DF] h-full transition-all duration-500" style={{ width: `${hPct}%` }} />
                            <div className="bg-emerald-500 h-full transition-all duration-500" style={{ width: `${100 - hPct}%` }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="text-center py-10 px-4 rounded-2xl bg-[#071120] border border-slate-800 space-y-2">
                  <BarChart3 className="w-8 h-8 text-slate-600 mx-auto" />
                  <p className="text-sm font-bold text-white">Statistiques non disponibles pour ce match</p>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Les statistiques détaillées (possession, tirs, corners, passes) sont enregistrées en direct pendant le déroulement du match par l'API officielle.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ÉVÉNEMENTS */}
          {activeTab === 'events' && (
            <div className="space-y-3">
              {events && events.length > 0 ? (
                <div className="p-4 rounded-2xl bg-[#071120] border border-slate-800 space-y-2">
                  <h4 className="text-xs font-black text-slate-300 uppercase tracking-wider mb-2">
                    Chronologie des Événements du Match
                  </h4>
                  <div className="space-y-2">
                    {events.map((ev: any, idx: number) => {
                      const isHome = ev.teamId === summary.teams?.home?.id || ev.team === summary.teams?.home?.name;
                      const icon = ev.type === 'Goal' ? '⚽' : ev.type === 'Card' ? (ev.detail?.includes('Red') ? '🟥' : '🟨') : '🔄';

                      return (
                        <div
                          key={idx}
                          className={`flex items-center gap-3 p-2.5 rounded-xl border text-xs ${
                            isHome
                              ? 'bg-blue-950/20 border-blue-900/40 text-blue-200'
                              : 'bg-emerald-950/20 border-emerald-900/40 text-emerald-200 flex-row-reverse'
                          }`}
                        >
                          <span className="font-mono font-black text-[11px] px-2 py-0.5 rounded bg-slate-900 text-slate-300 shrink-0">
                            {ev.time}'{ev.extraTime ? `+${ev.extraTime}` : ''}
                          </span>
                          <span className="text-sm">{icon}</span>
                          <div className={`flex flex-col min-w-0 ${isHome ? 'text-left' : 'text-right'}`}>
                            <span className="font-bold text-white truncate">
                              {ev.player || 'Joueur'}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {ev.detail || ev.type} {ev.assist ? `· Passe : ${ev.assist}` : ''}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="text-center py-10 px-4 rounded-2xl bg-[#071120] border border-slate-800 space-y-2">
                  <ListOrdered className="w-8 h-8 text-slate-600 mx-auto" />
                  <p className="text-sm font-bold text-white">Aucun événement enregistré</p>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Les buts, cartons et remplacements s'afficheront en temps réel au fur et à mesure du match.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: PRONOSTICS DU CHALLENGE */}
          {activeTab === 'predictions' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#071120] border border-slate-800 space-y-3">
                <h4 className="text-xs font-black text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  Les 3 Catégories de Pronostics sur ce Match
                </h4>
                <p className="text-xs text-slate-300">
                  Dans le Challenge Foot, chaque match propose exactement 3 types de pronostics. Aucun pronostic n'est automatisé par l'IA : vous choisissez vous-même vos prédictions.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                  <div className="p-3 rounded-xl bg-[#091528] border border-slate-800 space-y-1">
                    <span className="text-[10px] font-black uppercase text-amber-400">Catégorie A</span>
                    <h5 className="text-xs font-bold text-white">Buteur (+5 pts)</h5>
                    <p className="text-[11px] text-slate-400">
                      Pronostiquez quel joueur inscrira au moins un but dans ce match.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-[#091528] border border-slate-800 space-y-1">
                    <span className="text-[10px] font-black uppercase text-[#38BDF8]">Catégorie B</span>
                    <h5 className="text-xs font-bold text-white">1N2 (+3 pts)</h5>
                    <p className="text-[11px] text-slate-400">
                      Victoire Domicile (1), Match Nul (N), ou Victoire Extérieur (2).
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-[#091528] border border-slate-800 space-y-1">
                    <span className="text-[10px] font-black uppercase text-emerald-400">Catégorie C</span>
                    <h5 className="text-xs font-bold text-white">Score Exact (+10 pts)</h5>
                    <p className="text-[11px] text-slate-400">
                      Trouvez le résultat exact du temps réglementaire (ex: 2-1).
                    </p>
                  </div>
                </div>

                {/* Lock rule warning */}
                <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
                  <Lock className="w-4 h-4 shrink-0 text-amber-400" />
                  <span>
                    <strong>Verrouillage strict :</strong> Les choix sont verrouillés automatiquement au coup d'envoi officiel. Après le coup d'envoi, aucune modification n'est permise.
                  </span>
                </div>

                {onNavigateToChallenge && (
                  <button
                    onClick={() => {
                      onClose();
                      onNavigateToChallenge();
                    }}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#0B61DF] to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-black text-xs transition cursor-pointer shadow-md flex items-center justify-center gap-1.5"
                  >
                    <span>Ouvrir la Grille du Challenge pour Saisir mes Pronostics</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: REGARDER LE MATCH - LECTEUR DÉDIÉ SANS DÉRIVE */}
          {activeTab === 'watch' && (
            <div className="space-y-4">
              {/* 1. PERMANENT LOCKED MATCH HEADER (ABOVE THE PLAYER) */}
              <div className="p-3.5 sm:p-4 rounded-2xl bg-[#060D19] border border-blue-500/30 shadow-md space-y-2">
                <div className="flex items-center justify-between text-[11px] border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-1.5 text-blue-400 font-mono font-black">
                    <Lock className="w-3.5 h-3.5 text-blue-400" />
                    <span>MATCH VÉROUILLÉ #{summary.id}</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-300 font-sans font-bold">{summary.league?.name}</span>
                  </div>

                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-black text-[9px] uppercase tracking-wider flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Flux Unique Dédié (Anti-Dérive)</span>
                  </span>
                </div>

                {/* Teams & Score Display directly above video player */}
                <div className="grid grid-cols-12 items-center gap-2 pt-1">
                  {/* Home */}
                  <div className="col-span-5 flex items-center gap-2 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 p-1 flex items-center justify-center shrink-0">
                      {summary.teams?.home?.logo ? (
                        <img src={summary.teams.home.logo} alt="" className="w-full h-full object-contain" />
                      ) : (
                        <Shield className="w-4 h-4 text-blue-400" />
                      )}
                    </div>
                    <span className="text-xs sm:text-sm font-black text-white truncate">
                      {summary.teams?.home?.name}
                    </span>
                  </div>

                  {/* Score & Live Minute */}
                  <div className="col-span-2 flex flex-col items-center justify-center text-center">
                    <div className="text-base sm:text-xl font-mono font-black text-white tracking-wider">
                      {summary.goals?.home !== null && summary.goals?.home !== undefined ? summary.goals.home : '-'}
                      <span className="mx-1 text-slate-500">:</span>
                      {summary.goals?.away !== null && summary.goals?.away !== undefined ? summary.goals.away : '-'}
                    </div>
                    <span className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded ${
                      isLive ? 'text-red-400 bg-red-600/20 animate-pulse' : isHT ? 'text-amber-400 bg-amber-500/20' : isFinished ? 'text-slate-400' : 'text-[#38BDF8]'
                    }`}>
                      {displayStatus} {isLive && summary.elapsed ? `(${summary.elapsed}')` : ''}
                    </span>
                  </div>

                  {/* Away */}
                  <div className="col-span-5 flex items-center justify-end gap-2 min-w-0 text-right">
                    <span className="text-xs sm:text-sm font-black text-white truncate text-right">
                      {summary.teams?.away?.name}
                    </span>
                    <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 p-1 flex items-center justify-center shrink-0">
                      {summary.teams?.away?.logo ? (
                        <img src={summary.teams.away.logo} alt="" className="w-full h-full object-contain" />
                      ) : (
                        <Shield className="w-4 h-4 text-blue-400" />
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. DEDICATED VIDEO PLAYER CONTAINER (16:9 VIEWPORT) */}
              <div className="relative aspect-video w-full rounded-2xl bg-black border border-slate-800 overflow-hidden shadow-2xl flex flex-col justify-center items-center select-none group">
                
                {/* CASE A: LE MATCH N'A PAS ENCORE COMMENCÉ */}
                {!isLive && !isHT && !isFinished ? (
                  <div className="p-6 text-center space-y-3 max-w-md animate-fadeIn">
                    <div className="w-14 h-14 rounded-2xl bg-blue-950/60 border border-blue-500/40 text-blue-400 flex items-center justify-center mx-auto shadow-lg">
                      <Clock className="w-7 h-7" />
                    </div>
                    <div>
                      <h3 className="text-base sm:text-lg font-black text-white tracking-tight">
                        Le match n'a pas encore commencé
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        Coup d'envoi officiel prévu à {summary.date ? new Date(summary.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '20:00'}.
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 text-[11px] text-slate-300">
                      <span>Le signal vidéo en direct et le lecteur s'activeront dès le coup d'envoi officiel.</span>
                    </div>

                    {onNavigateToChallenge && (
                      <button
                        onClick={() => {
                          onClose();
                          onNavigateToChallenge();
                        }}
                        className="px-4 py-2 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs transition cursor-pointer shadow-md inline-flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                        <span>Saisir mes pronostics sur ce match</span>
                      </button>
                    )}
                  </div>
                ) : isFinished ? (
                  /* CASE B: LE MATCH EST TERMINÉ */
                  <div className="p-6 text-center space-y-3 max-w-md animate-fadeIn">
                    <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-700 text-slate-300 flex items-center justify-center mx-auto shadow-lg">
                      <CheckCircle2 className="w-7 h-7 text-emerald-400" />
                    </div>
                    <div>
                      <h3 className="text-base sm:text-lg font-black text-white tracking-tight">
                        Le match est terminé
                      </h3>
                      <p className="text-xs text-slate-400 mt-1 font-mono">
                        Score final certifié : {summary.goals?.home ?? 0} - {summary.goals?.away ?? 0}
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 text-[11px] text-slate-400">
                      <span>Ce match est conservé dans l'historique officiel du Challenge Foot du jour. Les points des pronostics ont été validés selon le résultat officiel.</span>
                    </div>

                    <button
                      onClick={() => setActiveTab('summary')}
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <ListOrdered className="w-3.5 h-3.5 text-blue-400" />
                      <span>Consulter le Résumé & Statistiques</span>
                    </button>
                  </div>
                ) : streamInfo?.hasAuthorizedStream && (streamInfo.streamUrl || streamInfo.embedHtml) ? (
                  /* CASE C-1: DIRECT EN COURS AVEC FLUX VIDÉO AUTORISÉ CONFIGURÉ */
                  <div className="w-full h-full relative bg-black flex items-center justify-center">
                    {streamInfo.embedHtml ? (
                      <div
                        className="w-full h-full flex items-center justify-center"
                        dangerouslySetInnerHTML={{ __html: streamInfo.embedHtml }}
                      />
                    ) : (
                      <video
                        src={streamInfo.streamUrl}
                        controls
                        autoPlay
                        className="w-full h-full object-contain"
                        onPlay={() => setIsPlaying(true)}
                        onPause={() => setIsPlaying(false)}
                        onTimeUpdate={(e) => setPlaybackTime(Math.floor((e.target as HTMLVideoElement).currentTime))}
                      />
                    )}

                    {/* Resume Playback floating button if interrupted */}
                    {isResumed && (
                      <div className="absolute top-3 left-3 px-3 py-1.5 rounded-xl bg-blue-600/90 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg backdrop-blur">
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Lecture reprise ({playbackTime}s)</span>
                      </div>
                    )}
                  </div>
                ) : (
                  /* CASE C-2: DIRECT EN COURS MAIS AUCUN FLUX VIDÉO LÉGAL INTÉGRÉ */
                  <div className="p-6 text-center space-y-3 max-w-md animate-fadeIn">
                    <div className="w-14 h-14 rounded-2xl bg-red-950/60 border border-red-500/40 text-red-400 flex items-center justify-center mx-auto shadow-lg">
                      <Tv className="w-7 h-7" />
                    </div>
                    <div>
                      <h3 className="text-base sm:text-lg font-black text-white tracking-tight">
                        La diffusion vidéo de ce match n'est pas disponible
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        Le match est actuellement {displayStatus} {summary.elapsed ? `(${summary.elapsed}')` : ''}.
                      </p>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-900/95 border border-slate-800 text-[11px] text-slate-300 text-left space-y-1.5">
                      <p className="font-bold text-white flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>Règles de diffusion officielle & Droits sportifs</span>
                      </p>
                      <p className="text-slate-400 leading-relaxed">
                        L'API-Football transmet en direct les scores, la minute, les compositions et les statistiques, mais ne détient pas les droits vidéo. Conformément aux lois sur le droit d'auteur sportif, aucun flux piraté ni lien non autorisé n'est diffusé dans l'application.
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                      <button
                        onClick={() => fetchStreamInfo(fixtureId)}
                        disabled={streamLoading}
                        className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${streamLoading ? 'animate-spin text-blue-400' : ''}`} />
                        <span>Tester la disponibilité d'un flux</span>
                      </button>

                      <button
                        onClick={() => setShowProviderModal(!showProviderModal)}
                        className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-400 hover:text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <Settings className="w-3.5 h-3.5" />
                        <span>Configuration Fournisseur</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Bottom Overlay Controls Bar (Active when video is present) */}
                {streamInfo?.hasAuthorizedStream && (
                  <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/90 to-transparent flex items-center justify-between text-xs text-white">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 transition cursor-pointer"
                      >
                        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => setIsResumed(true)}
                        className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 font-bold text-[11px] flex items-center gap-1 transition cursor-pointer"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Reprendre la lecture</span>
                      </button>
                    </div>

                    <span className="text-[10px] text-slate-300 font-mono">
                      Flux Officiel Certifié · #{summary.id}
                    </span>
                  </div>
                )}
              </div>

              {/* 3. OPTIONAL PROVIDER CONFIGURATION DRAWER (FOR ADMINS / PARTNERS) */}
              {showProviderModal && (
                <div className="p-4 rounded-2xl bg-[#071120] border border-blue-500/30 space-y-3 animate-fadeIn">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                      <Settings className="w-4 h-4 text-blue-400" />
                      <span>Intégration d'un Fournisseur Vidéo Officiel (#ID : {summary.id})</span>
                    </h4>
                    <button
                      onClick={() => setShowProviderModal(false)}
                      className="text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
                    >
                      Fermer
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Pour diffuser la vidéo directement dans l'application, vous devez raccorder un fournisseur officiel de streaming sportif détenteur des droits (ex: Sportradar OTT, Genius Sports, flux HLS agréé ou code d'intégration du diffuseur partenaire).
                  </p>

                  <div className="space-y-2 text-xs">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">
                        Nom du Fournisseur / Diffuseur
                      </label>
                      <input
                        type="text"
                        value={customProviderName}
                        onChange={(e) => setCustomProviderName(e.target.value)}
                        placeholder="Ex: Diffuseur Partenaire Officiel, UEFA Media, FIFA+"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">
                        URL du flux vidéo sécurisé (HLS .m3u8 ou MP4)
                      </label>
                      <input
                        type="url"
                        value={customStreamUrl}
                        onChange={(e) => setCustomStreamUrl(e.target.value)}
                        placeholder="https://official-stream.provider.com/live/match-feed.m3u8"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">
                        OU Code d'intégration iframe autorisé (Embed)
                      </label>
                      <input
                        type="text"
                        value={customEmbedCode}
                        onChange={(e) => setCustomEmbedCode(e.target.value)}
                        placeholder='<iframe src="https://player.provider.com/embed/..." />'
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-xs font-mono"
                      />
                    </div>

                    {adminStreamMessage && (
                      <p className="text-emerald-400 text-xs font-bold pt-1">{adminStreamMessage}</p>
                    )}

                    <button
                      onClick={async () => {
                        const idToFetch = typeof fixtureId === 'string' && fixtureId.startsWith('m-api-')
                          ? fixtureId.replace('m-api-', '')
                          : fixtureId;
                        try {
                          const res = await fetch('/api/admin/streaming-provider', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                              fixtureId: idToFetch,
                              streamUrl: customStreamUrl.trim() || null,
                              embedHtml: customEmbedCode.trim() || null,
                              providerName: customProviderName.trim() || 'Diffuseur Partenaire',
                              active: true,
                            }),
                          });
                          const json = await res.json();
                          if (json.success) {
                            setAdminStreamMessage('Fournisseur configuré avec succès ! Rechargement du lecteur...');
                            fetchStreamInfo(fixtureId);
                            setTimeout(() => {
                              setShowProviderModal(false);
                              setAdminStreamMessage(null);
                            }, 1500);
                          }
                        } catch (e) {
                          setAdminStreamMessage('Erreur lors de la sauvegarde du flux.');
                        }
                      }}
                      className="w-full py-2 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs transition cursor-pointer shadow-md"
                    >
                      Enregistrer et Activer le Flux pour ce Match
                    </button>
                  </div>
                </div>
              )}

              {/* 4. VERIFIED OFFICIAL BROADCASTERS LIST (ACCORDING TO USER PROMPT) */}
              <div className="p-4 rounded-2xl bg-[#091528] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Tv className="w-3.5 h-3.5 text-red-400" />
                    <span>Diffuseurs Officiels Accrédités pour cette Compétition</span>
                  </h4>
                  <span className="text-[10px] text-slate-400">Diffusion Légale Garantie</span>
                </div>

                <p className="text-[11px] text-slate-400">
                  Si vous disposez d'un abonnement officiel chez les détenteurs de droits, vous pouvez ouvrir la diffusion officielle dans votre navigateur ou application :
                </p>

                <div className="space-y-2">
                  {(streamInfo?.officialBroadcasters || broadcasting?.providers || []).map((provider: any, idx: number) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-[#060D19] border border-slate-800/90 hover:border-slate-700 transition flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-8 h-8 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center font-bold text-xs shrink-0">
                          <Play className="w-4 h-4 fill-current" />
                        </span>
                        <div className="truncate">
                          <h5 className="font-bold text-white text-xs truncate">{provider.name}</h5>
                          <span className="text-[10px] text-slate-400">{provider.region} · {provider.type}</span>
                        </div>
                      </div>

                      <a
                        href={provider.officialUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 transition"
                      >
                        <span>Ouvrir sur le site officiel</span>
                        <ExternalLink className="w-3 h-3 text-slate-400" />
                      </a>
                    </div>
                  ))}
                </div>
              </div>

              {/* 5. LIVE SYNC NOTIFICATION */}
              <div className="p-3 rounded-xl bg-blue-950/20 border border-blue-500/30 text-blue-300 text-xs flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Flame className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>Suivez le score minute par minute et les événements réels sur l'onglet Résumé.</span>
                </span>
                <button
                  onClick={() => setActiveTab('summary')}
                  className="font-black text-white hover:underline shrink-0"
                >
                  Voir le direct
                </button>
              </div>
            </div>
          )}

        </div>

        {/* BOTTOM ACTION BAR */}
        <div className="px-4 py-3 bg-[#060D19] border-t border-slate-800 flex items-center justify-between gap-3 text-xs">
          <span className="text-slate-400 font-mono text-[11px] truncate">
            ID Officiel : #{summary.id} · Source API-Football
          </span>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setActiveTab('watch')}
              className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black flex items-center gap-1.5 transition cursor-pointer"
            >
              <Tv className="w-3.5 h-3.5" />
              <span>Regarder le Match</span>
            </button>
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition cursor-pointer"
            >
              Fermer
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
