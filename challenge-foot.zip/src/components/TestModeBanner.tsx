import React from 'react';
import { useI18n } from '../i18n';
import { AlertTriangle, ShieldCheck } from 'lucide-react';

export const TestModeBanner: React.FC = () => {
  const { t } = useI18n();

  return (
    <div className="bg-gradient-to-r from-amber-500/20 via-amber-600/25 to-amber-500/20 border-b border-amber-500/40 text-amber-200 px-3 py-1.5 text-xs font-semibold select-none">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
          <span className="tracking-wide uppercase text-amber-300 font-bold">
            {t('common.test_mode_badge')}
          </span>
          <span className="hidden sm:inline text-amber-200/80 font-normal">
            — {t('common.test_mode_notice')}
          </span>
        </div>
        <div className="flex items-center gap-1.5 shrink-0 text-[11px] text-amber-300/90 font-medium">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden md:inline">100% Skill Contest · Haitian Law 1947</span>
        </div>
      </div>
    </div>
  );
};
