import React, { useState, useEffect, useMemo } from 'react';
import { useI18n } from '../i18n';
import { BeSoccerMatchRow } from '../components/BeSoccerMatchRow';
import {
  Activity,
  Trophy,
  Flame,
  Clock,
  Sparkles,
  RefreshCw,
  Radio,
  CheckCircle2,
  Search,
  Filter,
  AlertCircle,
  Award,
  ChevronRight,
  ArrowRight,
  Shield,
} from 'lucide-react';

interface LeagueItem {
  id: number;
  name: string;
  country: string;
  flag?: string | null;
  logo: string;
  type: string;
}

type BeSoccerFilter = 'all' | 'live' | 'upcoming' | 'finished' | 'challenge' | 'standings' | 'scorers';

export const FootballStatsView: React.FC<{
  onNavigateToChallenge?: () => void;
  onNavigateToLive?: () => void;
}> = ({ onNavigateToChallenge, onNavigateToLive }) => {
  const { t } = useI18n();

  // Active Category Filter: Defaults to official league standings & scorers
  const [activeCategory, setActiveCategory] = useState<BeSoccerFilter>('standings');

  // Matches State
  const [allMatches, setAllMatches] = useState<any[]>([]);
  const [loadingMatches, setLoadingMatches] = useState(false);
  const [lastLiveUpdated, setLastLiveUpdated] = useState<Date | null>(null);
  const [liveDataSource, setLiveDataSource] = useState<'api-sports' | 'cache' | 'offline'>('api-sports');
  const [liveErrorNotice, setLiveErrorNotice] = useState<string | null>(null);
  const [refreshCountdown, setRefreshCountdown] = useState(60);

  // 10 Challenge Matches State
  const [challenge10, setChallenge10] = useState<any[]>([]);
  const [loadingChallenge10, setLoadingChallenge10] = useState(false);

  // Leagues, Standings & Top Scorers State
  const [majorLeagues, setMajorLeagues] = useState<LeagueItem[]>([]);
  const [selectedLeagueId, setSelectedLeagueId] = useState<number>(39);
  const [selectedSeason, setSelectedSeason] = useState<number>(2024);
  const [leagueSearchInput, setLeagueSearchInput] = useState('');
  const [searchResults, setSearchResults] = useState<LeagueItem[]>([]);
  const [searchingLeague, setSearchingLeague] = useState(false);

  const [standingsData, setStandingsData] = useState<any | null>(null);
  const [loadingStandings, setLoadingStandings] = useState(false);
  const [standingsError, setStandingsError] = useState<string | null>(null);

  const [topScorers, setTopScorers] = useState<any[]>([]);
  const [loadingScorers, setLoadingScorers] = useState(false);
  const [scorersError, setScorersError] = useState<string | null>(null);

  // Fetch Major Leagues
  useEffect(() => {
    fetch('/api/football/leagues')
      .then((r) => r.json())
      .then((json) => {
        if (json.success && Array.isArray(json.data)) {
          setMajorLeagues(json.data);
        }
      })
      .catch(() => {});
  }, []);

  // Fetch Challenge 10 Matches
  const fetchChallenge10 = async () => {
    setLoadingChallenge10(true);
    try {
      const res = await fetch('/api/football/auto-10');
      const json = await res.json();
      if (json.success && json.autoSelectedMatches?.matches) {
        setChallenge10(json.autoSelectedMatches.matches);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingChallenge10(false);
    }
  };

  // Fetch Real Matches (combines live + today)
  const fetchMatchesData = async () => {
    setLoadingMatches(true);
    setLiveErrorNotice(null);
    try {
      // 1. Fetch live matches
      const liveRes = await fetch('/api/football/live');
      const liveJson = await liveRes.json();
      let liveList: any[] = [];
      if (liveJson.success && Array.isArray(liveJson.data)) {
        liveList = liveJson.data;
      }

      // 2. Fetch today's full fixtures
      const todayRes = await fetch('/api/football/today');
      const todayJson = await todayRes.json();
      let todayList: any[] = [];
      if (todayJson.success && Array.isArray(todayJson.data)) {
        todayList = todayJson.data;
      }

      // Merge avoiding duplicate IDs, with live fixtures taking priority
      const combinedMap = new Map<number, any>();
      liveList.forEach((m) => {
        if (m.fixture?.id) combinedMap.set(m.fixture.id, m);
      });
      todayList.forEach((m) => {
        if (m.fixture?.id && !combinedMap.has(m.fixture.id)) {
          combinedMap.set(m.fixture.id, m);
        }
      });

      const list = Array.from(combinedMap.values());
      setAllMatches(list);
      setLiveDataSource(liveJson.source === 'stale_cache' ? 'cache' : 'api-sports');
      setLastLiveUpdated(new Date());

      if (list.length === 0) {
        setLiveErrorNotice('Aucun match programmé pour le moment via API-Sports.');
      }
    } catch (err: any) {
      setLiveDataSource('offline');
      setLiveErrorNotice('Serveur en cours de synchronisation avec API-Football.');
    } finally {
      setLoadingMatches(false);
      setRefreshCountdown(60);
    }
  };

  // Timer: auto-refresh every 60s
  useEffect(() => {
    fetchMatchesData();
    fetchChallenge10();
    const timer = setInterval(() => {
      setRefreshCountdown((c) => {
        if (c <= 1) {
          fetchMatchesData();
          return 60;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Fetch Standings
  const fetchStandings = async (leagueId: number, season: number) => {
    setLoadingStandings(true);
    setStandingsError(null);
    try {
      const res = await fetch(`/api/football/standings?league=${leagueId}&season=${season}`);
      const json = await res.json();
      if (json.success && json.data) {
        setStandingsData(json.data);
      } else {
        setStandingsData(null);
        setStandingsError(json.message || 'Classement officiel non disponible pour cette saison.');
      }
    } catch {
      setStandingsError('Erreur de chargement du classement.');
    } finally {
      setLoadingStandings(false);
    }
  };

  // Fetch Top Scorers
  const fetchTopScorers = async (leagueId: number, season: number) => {
    setLoadingScorers(true);
    setScorersError(null);
    try {
      const res = await fetch(`/api/football/topscorers?league=${leagueId}&season=${season}`);
      const json = await res.json();
      if (json.success && Array.isArray(json.data)) {
        setTopScorers(json.data);
      } else {
        setTopScorers([]);
        setScorersError(json.message || 'Aucun classement des buteurs disponible.');
      }
    } catch {
      setScorersError('Erreur de chargement des meilleurs buteurs.');
    } finally {
      setLoadingScorers(false);
    }
  };

  useEffect(() => {
    if (activeCategory === 'standings') {
      fetchStandings(selectedLeagueId, selectedSeason);
    } else if (activeCategory === 'scorers') {
      fetchTopScorers(selectedLeagueId, selectedSeason);
    }
  }, [activeCategory, selectedLeagueId, selectedSeason]);

  // Search additional leagues
  const handleLeagueSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leagueSearchInput.trim()) return;
    setSearchingLeague(true);
    try {
      const res = await fetch(`/api/football/leagues?search=${encodeURIComponent(leagueSearchInput.trim())}`);
      const json = await res.json();
      if (json.success && Array.isArray(json.data)) {
        setSearchResults(json.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSearchingLeague(false);
    }
  };

  // Filtered Matches based on BeSoccer categories
  const filteredMatches = useMemo(() => {
    if (activeCategory === 'challenge') {
      return challenge10.map((m, idx) => ({
        fixture: {
          id: m.id,
          date: m.kickoffTime,
          status: { short: m.status || 'NS' },
          venue: { name: m.venue },
        },
        league: {
          id: m.leagueId,
          name: m.competition,
          logo: m.leagueLogo,
          country: m.country,
        },
        teams: {
          home: { name: m.homeTeam, logo: m.homeLogo },
          away: { name: m.awayTeam, logo: m.awayLogo },
        },
        goals: { home: null, away: null },
        events: [],
        isChallenge: true,
        matchNumber: idx + 1,
      }));
    }

    if (activeCategory === 'live') {
      return allMatches.filter((m) =>
        ['1H', '2H', 'HT', 'ET', 'LIVE'].includes(m.fixture?.status?.short || '')
      );
    }

    if (activeCategory === 'upcoming') {
      return allMatches.filter((m) =>
        ['NS', 'TBD'].includes(m.fixture?.status?.short || '')
      );
    }

    if (activeCategory === 'finished') {
      return allMatches.filter((m) =>
        ['FT', 'AET', 'PEN'].includes(m.fixture?.status?.short || '')
      );
    }

    return allMatches;
  }, [activeCategory, allMatches, challenge10]);

  // Group Matches by Competition Header (Iconic BeSoccer Layout)
  const groupedMatches = useMemo(() => {
    const groups: Record<string, { league: any; matches: any[] }> = {};
    filteredMatches.forEach((m) => {
      const leagueName = m.league?.name || 'Autres Compétitions';
      if (!groups[leagueName]) {
        groups[leagueName] = { league: m.league, matches: [] };
      }
      groups[leagueName].matches.push(m);
    });
    return groups;
  }, [filteredMatches]);

  const liveCount = allMatches.filter((m) =>
    ['1H', '2H', 'HT', 'ET', 'LIVE'].includes(m.fixture?.status?.short || '')
  ).length;

  return (
    <div className="max-w-5xl mx-auto px-2 sm:px-4 py-4 sm:py-6 space-y-4">
      {/* ----------------- BESOCCER TOP HEADER ----------------- */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-6 h-6 rounded-lg bg-[#0B61DF] text-white flex items-center justify-center font-bold text-xs shadow-sm">
              <Activity className="w-3.5 h-3.5" />
            </span>
            <span className="text-[11px] font-black uppercase tracking-wider text-[#38BDF8]">
              Challenge Foot Live Center (Style BeSoccer)
            </span>
            {liveDataSource === 'api-sports' && (
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                API-Football Officiel
              </span>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            Matchs en Direct & Résultats
          </h1>
        </div>

        {/* Refresh & Timer Info */}
        <div className="flex items-center gap-2 text-xs self-start sm:self-auto">
          {lastLiveUpdated && (
            <span className="text-slate-400 font-mono text-[11px] hidden sm:inline">
              Mis à jour : {lastLiveUpdated.toLocaleTimeString()}
            </span>
          )}
          <button
            onClick={fetchMatchesData}
            disabled={loadingMatches}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border border-slate-700 active:scale-95"
            title="Rafraîchir les scores"
          >
            <RefreshCw className={`w-3 h-3 ${loadingMatches ? 'animate-spin text-blue-400' : ''}`} />
            <span className="font-mono text-[11px]">{refreshCountdown}s</span>
          </button>
        </div>
      </div>

      {/* ----------------- BESOCCER CATEGORIES PILLS BAR (MOBILE-OPTIMIZED) ----------------- */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs select-none">
        <button
          onClick={() => setActiveCategory('all')}
          className={`px-3 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
            activeCategory === 'all'
              ? 'bg-[#0B61DF] text-white border-blue-400 shadow-md'
              : 'bg-[#091528] text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          Tous ({allMatches.length})
        </button>

        <button
          onClick={() => {
            if (onNavigateToLive) onNavigateToLive();
            else setActiveCategory('live');
          }}
          className={`px-3 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 border ${
            activeCategory === 'live'
              ? 'bg-red-600 text-white border-red-400 shadow-md'
              : 'bg-[#091528] text-red-400 border-red-500/30 hover:bg-red-500/10'
          }`}
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500" />
          </span>
          <span>Challenge Live (10 Matchs)</span>
        </button>

        <button
          onClick={() => setActiveCategory('standings')}
          className={`px-3 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
            activeCategory === 'standings'
              ? 'bg-[#0B61DF] text-white border-blue-400 shadow-md'
              : 'bg-[#091528] text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          Classements Championnats
        </button>

        <button
          onClick={() => setActiveCategory('scorers')}
          className={`px-3 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
            activeCategory === 'scorers'
              ? 'bg-[#0B61DF] text-white border-blue-400 shadow-md'
              : 'bg-[#091528] text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          Top Buteurs
        </button>
      </div>

      {liveErrorNotice && (
        <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-500/30 text-blue-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-blue-400 shrink-0" />
          <span>{liveErrorNotice}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. MATCHS LIST (GROUPED BY COMPETITION, BESOCCER ALIGNMENT)              */}
      {/* ========================================================================= */}
      {['all', 'live', 'upcoming', 'finished', 'challenge'].includes(activeCategory) && (
        <div className="space-y-4">
          {/* Challenge Banner Header (when Challenge Tab is Active) */}
          {activeCategory === 'challenge' && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0B254E] via-[#0D1C34] to-[#0B254E] border border-amber-500/30 space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-1.5 text-amber-400 text-xs font-black uppercase">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Sélection Officielle Challenge Foot (10 Matchs du Jour)</span>
                  </div>
                  <h2 className="text-base font-black text-white mt-0.5">
                    Tous les participants concourent sur exactement ces 10 mêmes rencontres
                  </h2>
                </div>

                {onNavigateToChallenge && (
                  <button
                    onClick={onNavigateToChallenge}
                    className="px-4 py-2 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-black text-xs transition cursor-pointer self-start sm:self-auto shadow-md"
                  >
                    Pronostiquer Maintenant
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-300">
                Matchs sélectionnés automatiquement depuis les grandes compétitions réelles via API-Football. Verrouillage automatique au coup d'envoi.
              </p>
            </div>
          )}

          {/* Grouped Match Rows */}
          {Object.keys(groupedMatches).length > 0 ? (
            Object.entries(groupedMatches).map(([leagueName, group]) => (
              <div
                key={leagueName}
                className="rounded-2xl bg-[#071120] border border-slate-800/80 overflow-hidden shadow-sm"
              >
                {/* Competition Sticky Header Bar */}
                <div className="flex items-center justify-between px-3.5 py-2 bg-[#091528] border-b border-slate-800 text-xs">
                  <div className="flex items-center gap-2 truncate">
                    {group.league?.logo && (
                      <img
                        src={group.league.logo}
                        alt={leagueName}
                        className="w-4 h-4 object-contain rounded-full bg-slate-900 shrink-0"
                        loading="lazy"
                      />
                    )}
                    {group.league?.flag && (
                      <img
                        src={group.league.flag}
                        alt=""
                        className="w-3.5 h-2.5 object-cover rounded-xs shrink-0"
                      />
                    )}
                    <span className="font-black text-white uppercase tracking-tight truncate text-[11px]">
                      {leagueName} {group.league?.country ? `· ${group.league.country}` : ''}
                    </span>
                  </div>

                  <span className="text-[10px] font-mono text-slate-400 font-bold">
                    {group.matches.length} match{group.matches.length > 1 ? 's' : ''}
                  </span>
                </div>

                {/* Match Cards List */}
                <div className="p-2 space-y-2">
                  {group.matches.map((item, idx) => {
                    const f = item.fixture || {};
                    const league = item.league || {};
                    const teams = item.teams || {};
                    const goals = item.goals || {};
                    const statusShort = f.status?.short || item.status || 'NS';

                    return (
                      <BeSoccerMatchRow
                        key={f.id || idx}
                        id={f.id || idx}
                        homeTeam={teams.home?.name || item.homeTeam || 'Équipe 1'}
                        homeLogo={teams.home?.logo || item.homeLogo}
                        homeScore={goals.home}
                        awayTeam={teams.away?.name || item.awayTeam || 'Équipe 2'}
                        awayLogo={teams.away?.logo || item.awayLogo}
                        awayScore={goals.away}
                        competition={league.name || item.competition || 'Ligue Officielle'}
                        competitionLogo={league.logo || item.leagueLogo}
                        country={league.country}
                        status={statusShort}
                        elapsed={f.status?.elapsed}
                        kickoffTime={f.date || item.kickoffTime}
                        venue={f.venue?.name || item.venue}
                        isChallengeMatch={item.isChallenge}
                        matchNumber={item.matchNumber}
                        events={item.events}
                      />
                    );
                  })}
                </div>
              </div>
            ))
          ) : !loadingMatches ? (
            <div className="text-center py-16 p-6 rounded-2xl bg-[#091528] border border-slate-800 space-y-2">
              <Clock className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-white">Aucun match trouvé pour cette catégorie</p>
              <p className="text-xs text-slate-400">
                Sélectionnez « Tous » pour visualiser l'ensemble des rencontres programmées aujourd'hui.
              </p>
            </div>
          ) : (
            <div className="text-center py-12 p-6 rounded-2xl bg-[#091528] border border-slate-800">
              <RefreshCw className="w-8 h-8 text-blue-400 mx-auto animate-spin mb-2" />
              <p className="text-xs text-slate-300">Synchronisation des matchs avec API-Sports...</p>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. SECTION CLASSEMENTS OFFICIELS                                          */}
      {/* ========================================================================= */}
      {activeCategory === 'standings' && (
        <div className="space-y-4">
          {/* League Selector Carousel */}
          <div className="p-3.5 rounded-2xl bg-[#091528] border border-slate-800 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs font-black uppercase text-slate-300">
                Choisir une grande compétition :
              </span>
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-slate-400">Saison :</span>
                {[2024, 2025, 2026].map((s) => (
                  <button
                    key={s}
                    onClick={() => setSelectedSeason(s)}
                    className={`px-2 py-0.5 rounded-lg font-bold text-xs cursor-pointer ${
                      selectedSeason === s ? 'bg-[#0B61DF] text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {majorLeagues.map((lg) => (
                <button
                  key={lg.id}
                  onClick={() => setSelectedLeagueId(lg.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 flex items-center gap-1.5 cursor-pointer border ${
                    selectedLeagueId === lg.id
                      ? 'bg-blue-600 text-white border-blue-400'
                      : 'bg-[#060D19] text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {lg.logo && <img src={lg.logo} alt="" className="w-3.5 h-3.5 object-contain" />}
                  <span>{lg.name}</span>
                </button>
              ))}
            </div>
          </div>

          {standingsError && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs">
              {standingsError}
            </div>
          )}

          {/* Standings Table with clean BeSoccer layout */}
          {standingsData?.standings && standingsData.standings.length > 0 ? (
            standingsData.standings.map((group: any[], gIdx: number) => (
              <div key={gIdx} className="rounded-2xl bg-[#091528] border border-slate-800 overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#060D19] border-b border-slate-800 text-slate-400 uppercase text-[10px] font-bold">
                      <tr>
                        <th className="py-2.5 px-3">#</th>
                        <th className="py-2.5 px-3">Équipe</th>
                        <th className="py-2.5 px-2 text-center">J</th>
                        <th className="py-2.5 px-2 text-center">G</th>
                        <th className="py-2.5 px-2 text-center">N</th>
                        <th className="py-2.5 px-2 text-center">P</th>
                        <th className="py-2.5 px-2 text-center">Diff</th>
                        <th className="py-2.5 px-3 text-center font-black text-white">Pts</th>
                        <th className="py-2.5 px-3 text-right hidden sm:table-cell">Forme</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-300">
                      {group.map((r: any) => {
                        const formChars = (r.form || '').split('').slice(-5);
                        return (
                          <tr key={r.rank} className="hover:bg-slate-800/30">
                            <td className="py-2.5 px-3 font-mono font-bold">
                              <span
                                className={`w-5 h-5 rounded flex items-center justify-center text-[10px] ${
                                  r.rank <= 4
                                    ? 'bg-blue-500/20 text-[#38BDF8] font-black'
                                    : r.rank >= group.length - 2
                                    ? 'bg-red-500/20 text-red-400'
                                    : 'text-slate-400'
                                }`}
                              >
                                {r.rank}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 font-bold text-white">
                              <div className="flex items-center gap-2">
                                {r.team?.logo && (
                                  <img src={r.team.logo} alt="" className="w-4 h-4 object-contain shrink-0" />
                                )}
                                <span className="truncate max-w-[150px] sm:max-w-none">{r.team?.name}</span>
                              </div>
                            </td>
                            <td className="py-2.5 px-2 text-center font-mono">{r.played}</td>
                            <td className="py-2.5 px-2 text-center font-mono text-emerald-400">{r.win}</td>
                            <td className="py-2.5 px-2 text-center font-mono text-slate-400">{r.draw}</td>
                            <td className="py-2.5 px-2 text-center font-mono text-red-400">{r.lose}</td>
                            <td className="py-2.5 px-2 text-center font-mono font-bold">
                              {r.goalsDiff > 0 ? `+${r.goalsDiff}` : r.goalsDiff}
                            </td>
                            <td className="py-2.5 px-3 text-center font-mono font-black text-white bg-slate-900/60">
                              {r.points}
                            </td>
                            <td className="py-2.5 px-3 text-right hidden sm:table-cell">
                              <div className="flex items-center justify-end gap-1">
                                {formChars.map((f: string, fIdx: number) => (
                                  <span
                                    key={fIdx}
                                    className={`w-3.5 h-3.5 rounded text-[8px] font-black flex items-center justify-center ${
                                      f === 'W'
                                        ? 'bg-emerald-600 text-white'
                                        : f === 'D'
                                        ? 'bg-amber-600 text-white'
                                        : 'bg-red-600 text-white'
                                    }`}
                                  >
                                    {f}
                                  </span>
                                ))}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            ))
          ) : !loadingStandings ? (
            <div className="text-center py-12 p-6 rounded-2xl bg-[#091528] border border-slate-800">
              <Trophy className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-xs text-slate-400">Classement en attente ou non disponible pour cette ligue.</p>
            </div>
          ) : (
            <div className="text-center py-12 p-6 rounded-2xl bg-[#091528] border border-slate-800">
              <RefreshCw className="w-6 h-6 text-blue-400 mx-auto animate-spin mb-2" />
              <p className="text-xs text-slate-300">Chargement du classement...</p>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. SECTION TOP BUTEURS                                                    */}
      {/* ========================================================================= */}
      {activeCategory === 'scorers' && (
        <div className="space-y-4">
          <div className="p-3.5 rounded-2xl bg-[#091528] border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-black uppercase text-slate-300">Compétition :</span>
              <span className="text-slate-400 font-mono">Saison {selectedSeason}</span>
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {majorLeagues.map((lg) => (
                <button
                  key={lg.id}
                  onClick={() => setSelectedLeagueId(lg.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 flex items-center gap-1.5 cursor-pointer border ${
                    selectedLeagueId === lg.id
                      ? 'bg-blue-600 text-white border-blue-400'
                      : 'bg-[#060D19] text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {lg.logo && <img src={lg.logo} alt="" className="w-3.5 h-3.5 object-contain" />}
                  <span>{lg.name}</span>
                </button>
              ))}
            </div>
          </div>

          {topScorers.length > 0 ? (
            <div className="rounded-2xl bg-[#091528] border border-slate-800 overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#060D19] border-b border-slate-800 text-slate-400 uppercase text-[10px] font-bold">
                    <tr>
                      <th className="py-2.5 px-3">#</th>
                      <th className="py-2.5 px-3">Buteur</th>
                      <th className="py-2.5 px-3">Club</th>
                      <th className="py-2.5 px-3 text-center font-black text-emerald-400">Buts</th>
                      <th className="py-2.5 px-3 text-center">Passes</th>
                      <th className="py-2.5 px-3 text-right">Matchs</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300">
                    {topScorers.map((s) => (
                      <tr key={s.rank} className="hover:bg-slate-800/30">
                        <td className="py-2 px-3 font-mono font-black text-[#38BDF8]">#{s.rank}</td>
                        <td className="py-2 px-3 font-bold text-white">
                          <div className="flex items-center gap-2">
                            {s.player?.photo && (
                              <img src={s.player.photo} alt="" className="w-6 h-6 rounded-full object-cover shrink-0" />
                            )}
                            <span className="truncate max-w-[130px] sm:max-w-none">{s.player?.name}</span>
                          </div>
                        </td>
                        <td className="py-2 px-3 text-slate-300">
                          <div className="flex items-center gap-1.5">
                            {s.team?.logo && <img src={s.team.logo} alt="" className="w-4 h-4 object-contain shrink-0" />}
                            <span className="truncate max-w-[110px] sm:max-w-none">{s.team?.name}</span>
                          </div>
                        </td>
                        <td className="py-2 px-3 text-center font-mono font-black text-emerald-400 text-sm">
                          {s.goals}
                        </td>
                        <td className="py-2 px-3 text-center font-mono">{s.assists}</td>
                        <td className="py-2 px-3 text-right font-mono text-slate-400">{s.appearances}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : !loadingScorers ? (
            <div className="text-center py-12 p-6 rounded-2xl bg-[#091528] border border-slate-800">
              <Award className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-xs text-slate-400">Statistiques des buteurs non disponibles pour cette ligue.</p>
            </div>
          ) : (
            <div className="text-center py-12 p-6 rounded-2xl bg-[#091528] border border-slate-800">
              <RefreshCw className="w-6 h-6 text-blue-400 mx-auto animate-spin mb-2" />
              <p className="text-xs text-slate-300">Chargement des buteurs...</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
