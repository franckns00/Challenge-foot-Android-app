export type Language = 'ht' | 'fr' | 'en';

export interface LanguageOption {
  code: Language;
  label: string;
  flag: string;
  nativeName: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'ht', label: 'Kreyòl ayisyen', flag: '🇭🇹', nativeName: 'Kreyòl Ayisyen' },
  { code: 'fr', label: 'Français', flag: '🇫🇷', nativeName: 'Français' },
  { code: 'en', label: 'English', flag: '🇺🇸', nativeName: 'English' },
];
