import React, { useState } from 'react';
import { useI18n } from '../i18n';
import { Campaign } from '../types';
import { Logo } from './Logo';
import { Download, UserPlus, ArrowRight, Sparkles, X, ChevronRight } from 'lucide-react';

interface AdBannerProps {
  campaigns: Campaign[];
  onOpenDownload: () => void;
  onOpenRegister: () => void;
  onNavigateToChallenges: () => void;
  onCampaignClick?: (campaignId: string) => void;
  isClubSubscriber?: boolean;
}

export const AdBanner: React.FC<AdBannerProps> = ({
  campaigns,
  onOpenDownload,
  onOpenRegister,
  onNavigateToChallenges,
  onCampaignClick,
  isClubSubscriber = false,
}) => {
  const { t, language } = useI18n();
  const [dismissed, setDismissed] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Filter campaigns placed on home or both, and active
  const homeCampaigns = campaigns.filter(
    (c) => c.isActive && (c.placement === 'home' || c.placement === 'both')
  );

  // Advantage 5: Ad-Free Experience for Club Subscribers
  if (isClubSubscriber || dismissed) {
    return null;
  }

  // If NO campaigns are configured or active: do NOT show an ugly empty container.
  // Instead, show a clean message and a button to discover football challenges!
  if (homeCampaigns.length === 0) {
    return (
      <div className="w-full bg-[#07101F] border border-slate-800 rounded-2xl p-5 mb-6 text-center shadow-lg">
        <div className="flex flex-col items-center justify-center max-w-lg mx-auto py-2">
          <div className="w-10 h-10 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 mb-3">
            <Sparkles className="w-5 h-5" />
          </div>
          <h4 className="text-base font-bold text-white mb-1">
            {t('ad.no_ads_title')}
          </h4>
          <p className="text-xs text-slate-400 mb-4 leading-relaxed">
            {t('ad.no_ads_desc')}
          </p>
          <button
            onClick={onNavigateToChallenges}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#0B61DF] hover:bg-blue-600 text-white text-xs font-semibold rounded-xl transition-all shadow-md shadow-blue-500/20 active:scale-95 cursor-pointer"
          >
            <span>{t('ad.btn_discover_challenges')}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  const campaign = homeCampaigns[currentIndex] || homeCampaigns[0];

  const title = campaign.title[language] || campaign.title.ht || campaign.title.fr;
  const description = campaign.description[language] || campaign.description.ht || campaign.description.fr;

  const handleActionClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onCampaignClick) {
      onCampaignClick(campaign.id);
    }

    if (campaign.ctaType === 'download' || campaign.targetUrl === '/download') {
      onOpenDownload();
    } else if (campaign.ctaType === 'register' || campaign.targetUrl === '/register') {
      onOpenRegister();
    } else if (campaign.ctaType === 'challenge' || campaign.targetUrl === '/challenges') {
      onNavigateToChallenges();
    } else if (campaign.targetUrl?.startsWith('http')) {
      window.open(campaign.targetUrl, '_blank', 'noopener,noreferrer');
    } else {
      onOpenDownload();
    }
  };

  return (
    <div className="relative overflow-hidden w-full rounded-2xl bg-gradient-to-br from-[#0B61DF]/20 via-[#07101F] to-[#0D1C34] border border-[#0B61DF]/40 shadow-xl shadow-blue-950/30 mb-8 transition-all">
      {/* Background radial glow */}
      <div className="absolute -top-24 -right-24 w-72 h-72 bg-[#0B61DF]/30 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />

      {/* Dismiss button */}
      <button
        onClick={() => setDismissed(true)}
        className="absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-slate-900/60 hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
        title={t('common.close')}
      >
        <X className="w-4 h-4" />
      </button>

      <div className="relative z-10 p-4 sm:p-6 lg:p-7 flex flex-col md:flex-row items-center gap-6">
        {/* Left / Visual Image Slot */}
        <div className="w-full md:w-5/12 shrink-0">
          <div className="relative rounded-xl overflow-hidden aspect-video md:aspect-[4/3] border border-blue-500/30 shadow-inner group">
            {campaign.imageUrl ? (
              <img
                src={campaign.imageUrl}
                alt={title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-tr from-[#07101F] via-[#0B61DF]/40 to-[#07101F] flex items-center justify-center">
                <Logo size="lg" showText={false} />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
            
            {/* Logo Badge Overlay on the Image */}
            <div className="absolute top-2.5 left-2.5 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10 flex items-center gap-1.5">
              <Logo size="sm" showText={false} />
              <span className="text-[10px] font-bold tracking-wider uppercase text-blue-300">
                Official App
              </span>
            </div>

            {/* Multiple Campaigns Pager if > 1 */}
            {homeCampaigns.length > 1 && (
              <div className="absolute bottom-2.5 right-2.5 flex items-center gap-1 bg-black/70 px-2 py-0.5 rounded-full border border-white/10">
                {homeCampaigns.map((_, i) => (
                  <button
                    key={i}
                    onClick={(e) => {
                      e.stopPropagation();
                      setCurrentIndex(i);
                    }}
                    className={`w-2 h-2 rounded-full transition-all ${
                      i === currentIndex ? 'bg-[#38BDF8] w-4' : 'bg-white/40 hover:bg-white/70'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right / Content & Action Slot */}
        <div className="w-full md:w-7/12 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#38BDF8] bg-[#0B61DF]/20 border border-[#0B61DF]/40 px-2.5 py-0.5 rounded-md">
                {t('ad.badge')}
              </span>
              <span className="text-[11px] text-slate-400 font-medium">
                Android v1.2.0
              </span>
            </div>

            <h3 className="text-lg sm:text-xl md:text-2xl font-extrabold text-white tracking-tight leading-snug mb-2 font-sans">
              {title}
            </h3>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-5 line-clamp-3">
              {description}
            </p>
          </div>

          {/* Interactive Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-1">
            {/* Télécharger l'application button */}
            <button
              onClick={onOpenDownload}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 sm:px-5 py-2.5 bg-[#0B61DF] hover:bg-blue-600 text-white text-xs sm:text-sm font-bold rounded-xl transition-all shadow-lg shadow-blue-600/30 hover:shadow-blue-600/50 active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <Download className="w-4 h-4 text-white" />
              <span>{t('ad.btn_download')}</span>
            </button>

            {/* S'inscrire button */}
            <button
              onClick={onOpenRegister}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 sm:px-5 py-2.5 bg-slate-900/90 hover:bg-slate-800 text-slate-100 hover:text-white text-xs sm:text-sm font-semibold rounded-xl border border-slate-700/80 hover:border-slate-600 transition-all active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <UserPlus className="w-4 h-4 text-[#38BDF8]" />
              <span>{t('ad.btn_register')}</span>
            </button>

            {/* If campaign has custom target or action */}
            {campaign.targetUrl && campaign.targetUrl !== '/download' && campaign.targetUrl !== '/register' && (
              <button
                onClick={handleActionClick}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                <span>{t('common.learn_more')}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
