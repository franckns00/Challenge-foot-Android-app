import React, { useState, useEffect } from 'react';
import { useI18n } from '../i18n';
import { Challenge, Campaign } from '../types';
import { Logo } from '../components/Logo';
import { AdBanner } from '../components/AdBanner';
import {
  Trophy,
  Calendar,
  Clock,
  Users,
  Award,
  ChevronRight,
  Shield,
  HelpCircle,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  DollarSign,
  Download,
  Crown,
} from 'lucide-react';

interface HomeViewProps {
  challenge: Challenge;
  campaigns: Campaign[];
  onNavigate: (view: string) => void;
  onOpenDownload: () => void;
  onOpenRegister: () => void;
  onCampaignClick: (id: string) => void;
  isClubSubscriber?: boolean;
}

export const HomeView: React.FC<HomeViewProps> = ({
  challenge,
  campaigns,
  onNavigate,
  onOpenDownload,
  onOpenRegister,
  onCampaignClick,
  isClubSubscriber = false,
}) => {
  const { t } = useI18n();

  // Simple countdown to challenge deadline
  const [timeLeft, setTimeLeft] = useState({ hours: 48, minutes: 15, seconds: 30 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-12">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#0D1C34] via-[#07101F] to-[#07101F] border border-blue-500/20 p-6 sm:p-10 lg:p-14 text-center">
        {/* Glow circles */}
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#0B61DF]/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-[#38BDF8] text-xs font-bold tracking-wider uppercase mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Konkou Pwonostik 100% Konpetans</span>
          </div>

          <div className="flex justify-center mb-2">
            <Logo size="xl" showText={false} />
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight uppercase italic leading-none font-sans">
            Challenge <span className="text-[#38BDF8]">FOOT</span>
          </h1>

          <p className="text-lg sm:text-2xl font-bold text-blue-200 tracking-tight">
            « {t('app.tagline')} »
          </p>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl mx-auto">
            {t('home.hero_desc')}
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('challenges')}
              className="px-6 sm:px-8 py-3.5 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-extrabold text-xs sm:text-sm transition-all shadow-xl shadow-blue-600/40 hover:shadow-blue-600/60 active:scale-95 cursor-pointer flex items-center gap-2"
            >
              <span>{t('home.cta_explore')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenDownload}
              className="px-5 sm:px-6 py-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/80 font-bold text-xs sm:text-sm transition-all active:scale-95 cursor-pointer flex items-center gap-2"
            >
              <Download className="w-4 h-4 text-[#38BDF8]" />
              <span>{t('home.cta_download')}</span>
            </button>

            <button
              onClick={onOpenRegister}
              className="px-5 sm:px-6 py-3.5 rounded-xl bg-transparent hover:bg-slate-800/40 text-slate-300 hover:text-white text-xs sm:text-sm font-semibold transition-all cursor-pointer"
            >
              {t('home.cta_register')}
            </button>
          </div>
        </div>
      </section>

      {/* 2. AD BANNER (HOME ADVERTISING REQUIREMENT - AD-FREE FOR CLUB SUBSCRIBERS) */}
      <section>
        <AdBanner
          campaigns={campaigns}
          onOpenDownload={onOpenDownload}
          onOpenRegister={onOpenRegister}
          onNavigateToChallenges={() => onNavigate('challenges')}
          onCampaignClick={onCampaignClick}
          isClubSubscriber={isClubSubscriber}
        />
      </section>

      {/* 2.B CLUB CHALLENGE FOOT VIP SHOWCASE */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#091A38] via-[#071328] to-[#091A38] border border-amber-500/30 p-6 sm:p-7 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-black uppercase tracking-wider">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>CLUB CHALLENGE FOOT · VIP ($0.99 / 130 HTG / MOIS)</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Votre boîte à outils pour mieux pronostiquer
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Fiches analyses détaillées des 10 matchs du jour, statistiques VIP de forme et confrontations H2H, tendances buteurs, alertes WhatsApp 2h avant clôture et expérience 100% sans publicité.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={() => onNavigate('club')}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs flex items-center gap-2 transition shadow-lg shadow-amber-500/20 cursor-pointer"
            >
              <Crown className="w-4 h-4 text-slate-950" />
              <span>Découvrir le Club (130 HTG)</span>
            </button>
          </div>
        </div>
      </section>

      {/* 2.B CHALLENGE LIVE & 10 MATCHS DU JOUR SHOWCASE */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#071326] via-[#0B254E] to-[#071326] border border-blue-500/30 p-6 sm:p-7 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/40 text-red-400 text-xs font-black uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span>CHALLENGE LIVE · 10 MATCHS EXCLUSIFS</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Scores en Direct des 10 Matchs Officiels du Challenge
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Suivez les 10 affiches du jour en direct certifié (buteurs, cartons, score à la mi-temps, minutes réelles), consultez les diffuseurs officiels pour regarder chaque rencontre légalement, et accédez aux classements des grands championnats.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={() => onNavigate('challenge-live')}
              className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs sm:text-sm flex items-center gap-2 transition shadow-lg shadow-red-500/30 cursor-pointer active:scale-95"
            >
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
              <span>Ouvrir Challenge Live</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('stats')}
              className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 transition border border-slate-700 cursor-pointer"
            >
              <span>Classements & Buteurs</span>
            </button>
          </div>
        </div>
      </section>

      {/* 3. PROCHAIN CHALLENGE & 10 MATCHS */}
      <section className="rounded-3xl bg-[#0D1C34]/60 border border-slate-800 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
          <div>
            <span className="text-[11px] font-bold text-[#38BDF8] uppercase tracking-wider">
              {challenge.title}
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {t('home.next_challenge')}
            </h2>
          </div>

          {/* Countdown & Pool stats */}
          <div className="flex flex-wrap items-center gap-4 text-xs">
            <div className="flex items-center gap-2 bg-slate-900 px-3.5 py-2 rounded-xl border border-slate-800">
              <Clock className="w-4 h-4 text-amber-400" />
              <span className="text-slate-400">{t('home.closing_in')}</span>
              <span className="font-mono font-bold text-white tabular-nums">
                {String(timeLeft.hours).padStart(2, '0')}h {String(timeLeft.minutes).padStart(2, '0')}m {String(timeLeft.seconds).padStart(2, '0')}s
              </span>
            </div>

            <div className="flex items-center gap-2 bg-slate-900 px-3.5 py-2 rounded-xl border border-slate-800">
              <Users className="w-4 h-4 text-blue-400" />
              <span className="font-mono font-bold text-white tabular-nums">{challenge.participantsCount}</span>
              <span className="text-slate-400">{t('home.participants_count')}</span>
            </div>
          </div>
        </div>

        {/* 10 Matches Preview Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {challenge.matches.map((match) => (
            <div
              key={match.id}
              onClick={() => onNavigate('challenges')}
              className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/40 transition-all cursor-pointer group flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-lg bg-blue-500/10 text-[#38BDF8] text-[11px] font-bold flex items-center justify-center shrink-0">
                  #{match.matchNumber}
                </span>
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-[#38BDF8] transition-colors">
                    <span>{match.homeTeam}</span>
                    <span className="text-slate-500 font-normal">vs</span>
                    <span>{match.awayTeam}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {match.competition} · {new Date(match.kickOffTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] px-2 py-1 rounded-md bg-slate-800 text-slate-300 group-hover:bg-[#0B61DF] group-hover:text-white transition-colors font-medium">
                  Pronostiquer
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center pt-2">
          <button
            onClick={() => onNavigate('challenges')}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm transition-all shadow-md active:scale-95 cursor-pointer"
          >
            <span>Remplir ma grille des 10 pronostics</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* 4. LES TROIS NIVEAUX (BRONZE, SILVER, GOLD) */}
      <section className="space-y-6">
        <div className="text-center space-y-1">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t('home.tiers_title')}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Chaque niveau possède son propre classement, son propre pool de prix et ses participants.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* BRONZE */}
          <div className="rounded-2xl bg-[#0D1C34] border border-amber-700/40 p-6 flex flex-col justify-between space-y-5 relative overflow-hidden">
            <div className="space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">
                Débutant / Amateur
              </span>
              <h3 className="text-xl font-black text-white">
                {t('home.tier_bronze')}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {t('home.tier_bronze_desc')}
              </p>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800 text-xs text-slate-300">
              <div className="flex justify-between">
                <span>Part des Prix :</span>
                <span className="font-bold text-white">60%</span>
              </div>
              <div className="flex justify-between">
                <span>Opérateur :</span>
                <span className="font-bold text-white">40%</span>
              </div>
            </div>

            <button
              onClick={() => onNavigate('challenges')}
              className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-colors cursor-pointer"
            >
              Choisir BRONZE
            </button>
          </div>

          {/* SILVER */}
          <div className="rounded-2xl bg-[#0D1C34] border border-slate-400/40 p-6 flex flex-col justify-between space-y-5 relative overflow-hidden">
            <div className="space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-300">
                Passionné Avancé
              </span>
              <h3 className="text-xl font-black text-white">
                {t('home.tier_silver')}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {t('home.tier_silver_desc')}
              </p>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800 text-xs text-slate-300">
              <div className="flex justify-between">
                <span>Part des Prix :</span>
                <span className="font-bold text-white">60%</span>
              </div>
              <div className="flex justify-between">
                <span>Opérateur :</span>
                <span className="font-bold text-white">40%</span>
              </div>
            </div>

            <button
              onClick={() => onNavigate('challenges')}
              className="w-full py-2.5 rounded-xl bg-slate-600 hover:bg-slate-500 text-white font-bold text-xs transition-colors cursor-pointer"
            >
              Choisir SILVER
            </button>
          </div>

          {/* GOLD */}
          <div className="rounded-2xl bg-[#0D1C34] border border-yellow-500/50 p-6 flex flex-col justify-between space-y-5 relative overflow-hidden shadow-lg shadow-yellow-500/10">
            <div className="absolute top-3 right-3 text-[10px] font-bold uppercase tracking-wider text-yellow-300 bg-yellow-500/20 px-2 py-0.5 rounded border border-yellow-500/30">
              VIP + Jackpot
            </div>

            <div className="space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-yellow-400">
                Élite Expert
              </span>
              <h3 className="text-xl font-black text-white">
                {t('home.tier_gold')}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {t('home.tier_gold_desc')}
              </p>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800 text-xs text-slate-300">
              <div className="flex justify-between">
                <span>Part des Prix :</span>
                <span className="font-bold text-white">60%</span>
              </div>
              <div className="flex justify-between text-yellow-400 font-semibold">
                <span>Jackpot Progressif :</span>
                <span>5%</span>
              </div>
              <div className="flex justify-between">
                <span>Opérateur :</span>
                <span className="font-bold text-white">35%</span>
              </div>
            </div>

            <button
              onClick={() => onNavigate('challenges')}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-black font-extrabold text-xs transition-colors cursor-pointer shadow-md"
            >
              Choisir GOLD
            </button>
          </div>
        </div>
      </section>

      {/* 5. COMMENT ÇA MARCHE ? */}
      <section className="rounded-3xl bg-[#07101F] border border-slate-800 p-6 sm:p-10 space-y-8">
        <div className="text-center space-y-1">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t('home.how_it_works')}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Trois étapes simples pour participer et tester votre vision du jeu.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <span className="w-8 h-8 rounded-xl bg-blue-500/20 text-[#38BDF8] font-bold text-sm flex items-center justify-center">
              1
            </span>
            <h3 className="text-base font-bold text-white">{t('home.step1_title')}</h3>
            <p className="text-xs text-slate-300 leading-relaxed">{t('home.step1_desc')}</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <span className="w-8 h-8 rounded-xl bg-blue-500/20 text-[#38BDF8] font-bold text-sm flex items-center justify-center">
              2
            </span>
            <h3 className="text-base font-bold text-white">{t('home.step2_title')}</h3>
            <p className="text-xs text-slate-300 leading-relaxed">{t('home.step2_desc')}</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <span className="w-8 h-8 rounded-xl bg-blue-500/20 text-[#38BDF8] font-bold text-sm flex items-center justify-center">
              3
            </span>
            <h3 className="text-base font-bold text-white">{t('home.step3_title')}</h3>
            <p className="text-xs text-slate-300 leading-relaxed">{t('home.step3_desc')}</p>
          </div>
        </div>
      </section>

      {/* 6. SYSTÈME DE POINTS AUTOMATIQUE */}
      <section className="rounded-3xl bg-[#0D1C34] border border-blue-500/30 p-6 sm:p-8 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            {t('home.scoring_title')}
          </h2>
          <span className="text-xs text-blue-300 font-medium">
            Calcul serveur rigoureux & automatisé
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 text-center space-y-1">
            <span className="text-2xl font-black text-emerald-400 font-mono">10 pts</span>
            <p className="text-xs font-bold text-white">{t('home.score_exact')}</p>
            <p className="text-[11px] text-slate-400">Score au coup de sifflet final</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 text-center space-y-1">
            <span className="text-2xl font-black text-[#38BDF8] font-mono">3 pts</span>
            <p className="text-xs font-bold text-white">{t('home.score_1x2')}</p>
            <p className="text-[11px] text-slate-400">Si le score exact n'est pas trouvé</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 text-center space-y-1">
            <span className="text-2xl font-black text-amber-400 font-mono">+5 pts</span>
            <p className="text-xs font-bold text-white">{t('home.score_scorer')}</p>
            <p className="text-[11px] text-slate-400">Cumulable avec le score ou 1X2</p>
          </div>
        </div>

        <p className="text-xs text-slate-400 text-center pt-2">
          {t('home.score_note')}
        </p>
      </section>

      {/* 7. TRANSPARENCE & FOOTER */}
      <footer className="pt-8 border-t border-slate-800/80 space-y-6 text-xs text-slate-400">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <Logo size="sm" />
          <div className="flex flex-wrap items-center gap-4 text-xs font-medium">
            <button onClick={() => onNavigate('rules')} className="hover:text-white transition-colors cursor-pointer">
              {t('menu.rules')}
            </button>
            <button onClick={() => onNavigate('advertising')} className="hover:text-white transition-colors cursor-pointer">
              {t('menu.advertising')}
            </button>
            <button onClick={() => onNavigate('partnership')} className="hover:text-white transition-colors cursor-pointer">
              {t('menu.partnership')}
            </button>
            <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors cursor-pointer">
              {t('menu.about')}
            </button>
            <button onClick={onOpenDownload} className="text-[#38BDF8] hover:underline cursor-pointer">
              {t('menu.download_app')}
            </button>
          </div>
        </div>

        <div className="text-center text-[11px] text-slate-500 leading-relaxed">
          Challenge Foot est une plateforme de concours de compétences sportives (Skill Contest).
          Conformité stricte à la loi haïtienne du 11 septembre 1947 et à l'article 313 du Code pénal.
          Tous droits réservés © 2026 Challenge Foot.
        </div>
      </footer>
    </div>
  );
};
