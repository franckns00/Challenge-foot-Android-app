import React, { useState, useEffect } from 'react';
import {
  X,
  Users,
  Shield,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

interface PlayerItem {
  id?: number | string;
  name: string;
  number?: number | string | null;
  position: string;
  photo?: string | null;
  age?: number | null;
}

interface TeamData {
  name: string;
  logo: string;
  formation?: string;
  coach?: string;
  startXI?: PlayerItem[];
  substitutes?: PlayerItem[];
  players?: PlayerItem[];
}

interface MatchPlayersData {
  isOfficialLineup: boolean;
  notice: string;
  home: TeamData;
  away: TeamData;
}

interface MatchPlayersModalProps {
  fixtureId: string | number;
  matchInfo?: {
    competition?: string;
    homeTeam?: string;
    awayTeam?: string;
    homeLogo?: string;
    awayLogo?: string;
    kickOffTime?: string;
    time?: string;
    date?: string;
  };
  onClose: () => void;
}

export const MatchPlayersModal: React.FC<MatchPlayersModalProps> = ({
  fixtureId,
  matchInfo,
  onClose,
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<MatchPlayersData | null>(null);
  const [activeTeamTab, setActiveTeamTab] = useState<'home' | 'away'>('home');

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);

    fetch(`/api/football/match-players/${fixtureId}`)
      .then((res) => {
        if (!res.ok) throw new Error(`Erreur HTTP ${res.status}`);
        return res.json();
      })
      .then((json) => {
        if (!isMounted) return;
        if (json.success && json.data) {
          setData(json.data);
        } else {
          setError(json.error || 'Effectifs indisponibles pour ce match.');
        }
      })
      .catch((err) => {
        if (!isMounted) return;
        setError(err.message || 'Impossible de charger les effectifs.');
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [fixtureId]);

  const activeTeam = activeTeamTab === 'home' ? data?.home : data?.away;
  const isHome = activeTeamTab === 'home';

  // Helper to deduplicate and group roster by position
  const groupPlayers = (list: PlayerItem[] = []) => {
    const groups: { [key: string]: PlayerItem[] } = {
      Gardien: [],
      Défenseur: [],
      Milieu: [],
      Attaquant: [],
      Joueur: [],
    };
    const seenIds = new Set<string | number>();
    list.forEach((p) => {
      if (p.id) {
        if (seenIds.has(p.id)) return;
        seenIds.add(p.id);
      }
      const pos = p.position || 'Joueur';
      if (groups[pos]) groups[pos].push(p);
      else groups['Joueur'].push(p);
    });
    return groups;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#071326] border border-blue-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-[#060D19] flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-black text-white truncate flex items-center gap-2">
                <span>Effectifs & Joueurs du Match</span>
              </h3>
              <p className="text-[11px] text-slate-400 truncate">
                {matchInfo?.competition || 'Compétition Officielle'} · {matchInfo?.homeTeam} vs {matchInfo?.awayTeam}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center cursor-pointer transition shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Notice Bar: Lineup official vs Squads known */}
        {data && (
          <div
            className={`px-4 py-2.5 border-b flex items-center gap-2 text-xs ${
              data.isOfficialLineup
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                : 'bg-amber-950/40 border-amber-500/30 text-amber-300'
            }`}
          >
            {data.isOfficialLineup ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <span className="text-[11px] font-medium leading-relaxed">
              <strong>{data.isOfficialLineup ? 'Composition Officielle' : 'Effectifs du Club'} :</strong>{' '}
              {data.notice}
            </span>
          </div>
        )}

        {/* Teams Tabs Header */}
        {data && (
          <div className="grid grid-cols-2 p-2 bg-[#060D19]/60 border-b border-slate-800 gap-2">
            <button
              onClick={() => setActiveTeamTab('home')}
              className={`p-2.5 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition cursor-pointer border ${
                activeTeamTab === 'home'
                  ? 'bg-blue-600/20 border-blue-500/60 text-white shadow-sm'
                  : 'bg-[#060D19] border-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              {data.home.logo ? (
                <img src={data.home.logo} alt="" className="w-5 h-5 object-contain" />
              ) : (
                <Shield className="w-4 h-4 text-blue-400" />
              )}
              <span className="truncate">{data.home.name} (Domicile)</span>
            </button>

            <button
              onClick={() => setActiveTeamTab('away')}
              className={`p-2.5 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition cursor-pointer border ${
                activeTeamTab === 'away'
                  ? 'bg-emerald-600/20 border-emerald-500/60 text-white shadow-sm'
                  : 'bg-[#060D19] border-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              {data.away.logo ? (
                <img src={data.away.logo} alt="" className="w-5 h-5 object-contain" />
              ) : (
                <Shield className="w-4 h-4 text-emerald-400" />
              )}
              <span className="truncate">{data.away.name} (Extérieur)</span>
            </button>
          </div>
        )}

        {/* Body / Players List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {loading ? (
            <div className="py-16 text-center space-y-3">
              <RefreshCw className="w-8 h-8 text-blue-400 animate-spin mx-auto" />
              <p className="text-xs text-slate-400 font-medium">
                Récupération des effectifs officiels auprès d'API-Football...
              </p>
            </div>
          ) : error ? (
            <div className="py-12 text-center p-4 rounded-2xl bg-red-950/20 border border-red-500/30 text-red-300 space-y-2">
              <AlertCircle className="w-8 h-8 text-red-400 mx-auto" />
              <p className="text-sm font-bold">Impossible de charger les effectifs</p>
              <p className="text-xs text-slate-400">{error}</p>
            </div>
          ) : activeTeam ? (
            <div className="space-y-4">
              {/* Team Profile Summary */}
              <div className="p-3.5 rounded-2xl bg-[#091528] border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 p-1 flex items-center justify-center shrink-0">
                    {activeTeam.logo ? (
                      <img src={activeTeam.logo} alt="" className="w-full h-full object-contain" />
                    ) : (
                      <Shield className="w-5 h-5 text-blue-400" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white">{activeTeam.name}</h4>
                    <p className="text-[11px] text-slate-400">
                      {isHome ? 'Club recevant' : 'Club visiteur'}{' '}
                      {activeTeam.formation ? `· Dispositif : ${activeTeam.formation}` : ''}
                      {activeTeam.coach ? ` · Entraîneur : ${activeTeam.coach}` : ''}
                    </p>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 text-[10px] font-mono font-bold">
                  {data?.isOfficialLineup
                    ? `${(activeTeam.startXI?.length || 0) + (activeTeam.substitutes?.length || 0)} joueurs inscrits`
                    : `${activeTeam.players?.length || 0} joueurs disponibles`}
                </span>
              </div>

              {/* Scenario 1: Official Lineup Published */}
              {data?.isOfficialLineup ? (
                <div className="space-y-4">
                  {/* Titulaires */}
                  <div className="space-y-2">
                    <h5 className="text-[11px] font-black uppercase text-blue-400 tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>XI Titulaires ({activeTeam.startXI?.length || 11})</span>
                    </h5>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {activeTeam.startXI?.map((p, idx) => (
                        <div
                          key={`xi-${p.id ?? idx}-${idx}`}
                          className="p-2.5 rounded-xl bg-[#091528] border border-slate-800 flex items-center justify-between gap-2"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <span className="w-6 h-6 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 font-mono font-bold text-xs flex items-center justify-center shrink-0">
                              {p.number ?? '-'}
                            </span>
                            {p.photo && (
                              <img
                                src={p.photo}
                                alt=""
                                className="w-7 h-7 rounded-full object-cover bg-slate-900 border border-slate-800 shrink-0"
                                onError={(e) => {
                                  (e.target as HTMLElement).style.display = 'none';
                                }}
                              />
                            )}
                            <span className="font-bold text-xs text-white truncate">{p.name}</span>
                          </div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-300 border border-blue-500/20 shrink-0">
                            {p.position}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Remplaçants */}
                  {activeTeam.substitutes && activeTeam.substitutes.length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-slate-800">
                      <h5 className="text-[11px] font-black uppercase text-slate-400 tracking-wider">
                        Remplaçants Inscrits sur la Feuille de Match ({activeTeam.substitutes.length})
                      </h5>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {activeTeam.substitutes.map((p, idx) => (
                          <div
                            key={`sub-${p.id ?? idx}-${idx}`}
                            className="p-2.5 rounded-xl bg-[#060D19] border border-slate-800/80 flex items-center justify-between gap-2"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <span className="w-6 h-6 rounded-lg bg-slate-900 text-slate-400 font-mono font-bold text-xs flex items-center justify-center shrink-0">
                                {p.number ?? '-'}
                              </span>
                              <span className="font-semibold text-xs text-slate-300 truncate">{p.name}</span>
                            </div>
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 shrink-0">
                              {p.position}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* Scenario 2: Squad List Known (grouped by position) */
                <div className="space-y-4">
                  {Object.entries(groupPlayers(activeTeam.players || [])).map(([posGroup, list]) => {
                    if (list.length === 0) return null;
                    return (
                      <div key={posGroup} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <h5 className="text-[11px] font-black uppercase text-slate-300 tracking-wider">
                            {posGroup === 'Gardien'
                              ? 'Gardiens de but'
                              : posGroup === 'Défenseur'
                              ? 'Défenseurs'
                              : posGroup === 'Milieu'
                              ? 'Milieux de terrain'
                              : posGroup === 'Attaquant'
                              ? 'Attaquants'
                              : 'Joueurs'}
                          </h5>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {list.length} joueur(s)
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {list.map((p, idx) => (
                            <div
                              key={`squad-${posGroup}-${p.id ?? idx}-${idx}`}
                              className="p-2.5 rounded-xl bg-[#091528] border border-slate-800/90 flex items-center justify-between gap-2 hover:border-slate-700 transition"
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                <span className="w-6 h-6 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 font-mono font-black text-xs flex items-center justify-center shrink-0">
                                  {p.number ?? '-'}
                                </span>
                                {p.photo && (
                                  <img
                                    src={p.photo}
                                    alt=""
                                    className="w-7 h-7 rounded-full object-cover bg-slate-900 border border-slate-800 shrink-0"
                                    onError={(e) => {
                                      (e.target as HTMLElement).style.display = 'none';
                                    }}
                                  />
                                )}
                                <div className="min-w-0">
                                  <span className="font-bold text-xs text-white block truncate">
                                    {p.name}
                                  </span>
                                  {p.age && (
                                    <span className="text-[10px] text-slate-500">
                                      {p.age} ans
                                    </span>
                                  )}
                                </div>
                              </div>
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 shrink-0">
                                {p.position}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : null}
        </div>

        {/* Footer */}
        <div className="p-3.5 sm:p-4 border-t border-slate-800 bg-[#060D19] flex items-center justify-between text-xs">
          <span className="text-[11px] text-slate-400">
            Données officielles vérifiées via l'API Football
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer transition"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
