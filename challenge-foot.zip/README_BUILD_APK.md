# 📱 Guide de Compilation Android APK — Challenge Foot

Ce projet contient le code source complet et la configuration native Android pour générer l'application **Challenge Foot** (`ht.challengefoot.app`) au format **APK installable sur téléphone Android**.

---

## ⚡ Option 1 : Compilation Gratuite dans le Cloud depuis votre Téléphone (Sans Ordinateur)

Vous pouvez compiler l'APK directement depuis votre smartphone en 2 minutes grâce à **GitHub Actions** :

1. **Créer un dépôt GitHub :**
   - Rendez-vous sur [github.com](https://github.com) depuis votre navigateur mobile.
   - Créez un nouveau dépôt privé ou public nommé `challenge-foot`.
   - Uploadez ou poussez ce projet (ou importez l'archive ZIP).

2. **Lancer la compilation automatique :**
   - Ouvrez l'onglet **Actions** de votre dépôt GitHub.
   - Cliquez sur **« Build Challenge Foot Android APK »**.
   - Cliquez sur **« Run workflow »**.
   - GitHub configure automatiquement Java 17, le SDK Android 34, et exécute `./gradlew assembleRelease` et `./gradlew assembleDebug`.

3. **Télécharger et installer l'APK :**
   - Une fois la compilation terminée (environ 2 à 3 minutes), téléchargez l'artéfact `ChallengeFoot-release.apk`.
   - Ouvrez le fichier téléchargé sur votre téléphone Android.
   - Si Android affiche *« Pour votre sécurité, votre téléphone n'est pas autorisé à installer des applications inconnues depuis cette source »* :
     - Touchez **Paramètres**.
     - Activez **Autoriser cette source** (Chrome ou Gestionnaire de fichiers).
     - Touchez **Installer**.
   - L'application **Challenge Foot** est installée avec son icône officielle et son nom !

---

## ⚡ Option 2 : Compilation Ultra-Rapide via PWABuilder (Depuis Smartphone)

1. Ouvrez [https://www.pwabuilder.com](https://www.pwabuilder.com) sur votre téléphone.
2. Saisissez l'URL de votre application Challenge Foot :
   `https://ais-pre-6yof3logkohoeevfj7xb35-117275090053.us-east1.run.app`
3. Cliquez sur **Start** puis sur **Package for Stores** > **Android**.
4. Cliquez sur **Generate APK**.
5. Téléchargez directement le fichier `.apk` signé sur votre smartphone et installez-le.

---

## 💻 Option 3 : Compilation Locale sur Ordinateur (Android Studio ou Terminal)

### Avec Android Studio :
1. Ouvrez **Android Studio**.
2. Cliquez sur **Open an Existing Project** et sélectionnez le dossier `android/`.
3. Attendez la synchronisation Gradle.
4. Allez dans le menu **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
5. L'APK généré se trouvera dans `android/app/build/outputs/apk/debug/app-debug.apk`.

### Avec le Terminal :
```bash
# Se placer dans le dossier android
cd android

# Donner les droits d'exécution
chmod +x gradlew

# Compiler en mode Debug (immédiatement installable)
./gradlew assembleDebug

# Ou compiler en mode Release (signé)
./gradlew assembleRelease
```
Les fichiers APK générés se trouvent dans :
- Release : `android/app/build/outputs/apk/release/app-release.apk`
- Debug : `android/app/build/outputs/apk/debug/app-debug.apk`

---

## ⚙️ Configuration du Projet Android

- **Nom de l'application :** Challenge Foot
- **Identifiant Unique (Package ID) :** `ht.challengefoot.app`
- **SDK Compatible :** Android 7.0 (API 24) jusqu'à Android 14+ (API 34)
- **Permissions :** `INTERNET`, `ACCESS_NETWORK_STATE`
- **Moteur :** Capacitor 6 avec WebView Android moderne et accélération matérielle
