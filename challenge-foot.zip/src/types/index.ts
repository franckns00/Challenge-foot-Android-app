export type UserRole = 'player' | 'admin';

export interface User {
  id: string;
  fullName: string;
  phone: string; // +509...
  email: string;
  isPhoneVerified: boolean;
  role: UserRole;
  balance: number; // in HTG
  createdAt: string;
  lastLogin: string;
  gpsConsent?: boolean;
  gpsConsentDate?: string;
  clubSubscription?: {
    status: 'actif' | 'expiré' | 'annulé';
    startDate: string;
    endDate: string;
    whatsappAlertsEnabled: boolean;
  };
}

export type AdPlacement = 'home' | 'page' | 'both';
export type AdCtaType = 'download' | 'register' | 'challenge' | 'external';

export interface MultilingualText {
  ht: string;
  fr: string;
  en: string;
}

export interface Campaign {
  id: string;
  title: MultilingualText;
  description: MultilingualText;
  imageUrl: string;
  targetUrl: string;
  ctaType: AdCtaType;
  ctaCustomLabel?: Partial<MultilingualText>;
  placement: AdPlacement;
  startDate: string;
  endDate: string;
  isActive: boolean;
  clicks: number;
}

export type PlayerPosition = 'FWD' | 'MID' | 'DEF' | 'GK';

export interface Player {
  id: string;
  name: string;
  team: string;
  position: PlayerPosition;
  isStarter: boolean;
  photoUrl?: string;
}

export type MatchStatus = 'scheduled' | 'live' | 'finished';

export interface Match {
  id: string;
  matchNumber: number;
  competition: string;
  homeTeam: string;
  homeLogo: string;
  awayTeam: string;
  awayLogo: string;
  kickOffTime: string;
  venue?: string;
  status: MatchStatus;
  statusShort?: string;
  statusLong?: string;
  displayStatus?: string;
  elapsed?: number | null;
  date?: string;
  time?: string;
  apiFixtureId?: number;
  homeScore?: number | null;
  awayScore?: number | null;
  actualGoalscorerId?: string | null;
  actualGoalscorerName?: string | null;
  homePlayers: Player[];
  awayPlayers: Player[];
}

export type ChallengeTier = 'bronze' | 'silver' | 'gold';

export interface Challenge {
  id: string;
  title: string;
  roundNumber: number;
  deadline: string;
  matches: Match[];
  participantsCount: number;
  estPrizePool: number;
  status: 'open' | 'closed' | 'settled';
  missingCount?: number;
}

export interface MatchPick {
  matchId: string;
  homeScore: number;
  awayScore: number;
  outcome1x2: '1' | 'X' | '2';
  goalscorerId: string;
  goalscorerName: string;
  goalscorerTeam: string;
  kickoffTime?: string;
  recordedAt?: string;
}

export interface PredictionSubmission {
  id: string;
  challengeId: string;
  userId: string;
  userName: string;
  tier: ChallengeTier;
  submittedAt: string;
  picks: MatchPick[];
  totalPoints?: number;
  exactScoresCount?: number;
  correctOutcomesCount?: number;
  correctScorersCount?: number;
}

export type TransactionType = 'deposit' | 'withdrawal' | 'entry_fee' | 'prize';
export type TransactionStatus = 'pending' | 'processing' | 'approved' | 'confirmed' | 'rejected';
export type PaymentMethod = 'moncash' | 'natcash' | 'system';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number; // HTG
  currency: 'HTG';
  method: PaymentMethod;
  status: TransactionStatus;
  date: string;
  referenceId: string;
  description: string;
  rejectionReason?: string;
}

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  userName: string;
  tier: ChallengeTier;
  totalPoints: number;
  exactScores: number;
  outcomes: number;
  scorers: number;
  totalGoalsPredicted: number;
  submittedAt: string;
  prizeWon?: number;
}

export interface ParticipantRecord {
  id: string;
  participantNumber: string; // e.g. BR-001, BR-100
  userId: string;
  name: string;
  avatarUrl?: string;
  tier: ChallengeTier;
  totalPoints: number;
  rank: number;
  exactPredictions: number; // 10 pts
  correctOutcomes: number; // 3 pts
  missedPredictions: number; // 0 pts
  scorerBonus: number; // +5 pts each
  totalGoalsPredicted: number;
  status: 'winner' | 'participant' | 'outside_top5';
  prizeWon: number;
  prizeStatus: 'pending' | 'approved' | 'paid';
  paidFee: number;
  submittedAt: string;
}

export interface WinnerEntry {
  rank: 1 | 2 | 3 | 4 | 5;
  participantNumber: string;
  name: string;
  points: number;
  exactPredictions: number;
  prizeAmount: number;
  percentageOfFund: number; // 40%, 25%, 15%, 12%, 8%
  prizeStatus: 'pending' | 'approved' | 'paid';
}

export interface CategoryFinanceReport {
  tier: ChallengeTier;
  entryFeePerPerson: number;
  totalConfirmedParticipants: number;
  totalCollectedAmount: number;
  ownerSharePercentage: 40;
  ownerShareAmount: number;
  winnersSharePercentage: 60;
  winnersShareAmount: number;
  winners: WinnerEntry[];
}

export interface ChallengeArchive {
  id: string;
  roundNumber: number;
  title: string;
  startDate: string;
  endDate: string;
  status: 'open' | 'settled';
  reports: Record<ChallengeTier, CategoryFinanceReport>;
}

export interface LiveMatchStat {
  id: string;
  competition: string;
  minute: string;
  homeTeam: string;
  homeScore: number;
  awayTeam: string;
  awayScore: number;
  status: 'LIVE' | 'HT' | 'FT' | 'UPCOMING';
  scorers: string[];
}

export interface LeagueStandingItem {
  position: number;
  team: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  points: number;
  form: string[];
}

export interface PartnershipLead {
  id: string;
  name: string;
  email: string;
  phone?: string;
  type: string;
  message: string;
  createdAt: string;
}

// ----------------- CLUB CHALLENGE FOOT & SQUADS & PUBLIC PREDICTIONS -----------------

export type ClubSubscriptionStatus = 'actif' | 'expiré' | 'annulé';

export interface ClubSubscription {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  status: ClubSubscriptionStatus;
  startDate: string;
  endDate: string;
  monthlyPriceHtg: number;
  paymentMethod: 'wallet' | 'moncash' | 'natcash' | 'admin_manual';
  activatedByAdminId?: string;
  activationReason?: string;
  whatsappAlertsEnabled: boolean;
  createdAt: string;
}

export interface ClubConfig {
  monthlyPriceHtg: number;
  freeTrialDays: number;
  freeTrialEnabled: boolean;
  priorityPaymentMethod: 'wallet' | 'moncash' | 'natcash';
  monthlyLeaderboardPrizes: {
    first: number;
    second: number;
    third: number;
    fundingSource: string;
  };
  whatsappProvider: string;
}

export interface ClubAnalysisCard {
  matchId: string;
  matchNumber: number;
  competition: string;
  homeTeam: string;
  awayTeam: string;
  homeLogo?: string;
  awayLogo?: string;
  kickoffTime?: string;
  time?: string;
  tacticalKey: string;
  homeForm: string[]; // e.g. ['W', 'W', 'D', 'W', 'L']
  awayForm: string[];
  homeStrengths: string[];
  awayStrengths: string[];
  headToHeadSummary: string;
  probableScore: string;
  recommended1X2: '1' | 'X' | '2';
  confidenceStars: number; // 1 to 5
  keyScorers: Array<{ name: string; team: string; probability: number }>;
}

export interface SquadPlayer {
  id: number | string;
  name: string;
  number?: number | null;
  position: string;
  photo?: string;
  isStarter?: boolean;
  isSub?: boolean;
}

export interface MatchSquadsData {
  fixtureId: number | string;
  hasOfficialLineups: boolean;
  message?: string;
  competition?: string;
  matchDate?: string;
  homeTeam: {
    id?: number;
    name: string;
    logo: string;
    formation?: string;
    coach?: string;
    startingXI: SquadPlayer[];
    substitutes: SquadPlayer[];
    squad: SquadPlayer[];
  };
  awayTeam: {
    id?: number;
    name: string;
    logo: string;
    formation?: string;
    coach?: string;
    startingXI: SquadPlayer[];
    substitutes: SquadPlayer[];
    squad: SquadPlayer[];
  };
}

export interface PublicParticipantPrediction {
  participantId: string;
  participantName: string;
  participantNumber: string;
  tier: ChallengeTier;
  submittedAt: string;
  recordedAt: string;
  isOwn: boolean;
  isMasked: boolean;
  homeScore: number | null;
  awayScore: number | null;
  outcome1x2: '1' | 'X' | '2' | null;
  scoreDisplay: string;
  goalscorerName?: string;
  pointsEarned: number;
  isExact: boolean;
  isOutcome: boolean;
}

export interface PublicMatchGridItem {
  matchId: string;
  matchNumber: number;
  apiFixtureId?: number;
  competition: string;
  homeTeam: string;
  homeLogo: string;
  homeTeamId?: number;
  awayTeam: string;
  awayLogo: string;
  awayTeamId?: number;
  kickOffTime: string;
  date: string;
  time: string;
  status: string;
  statusShort: string;
  statusLong: string;
  displayStatus: string;
  elapsed?: number | null;
  homeScore?: number | null;
  awayScore?: number | null;
  isLocked: boolean;
  lockReason?: string;
  totalPredictionsCount: number;
  participantsPredictions: PublicParticipantPrediction[];
}

export interface AppSettings {
  predictionsPrivacyMode: 'hide_until_kickoff' | 'always_public';
  clubMonthlyPriceHtg: number;
  whatsappAlertsEnabled: boolean;
  freeTrialDays: number;
}

export interface PlayerOfficialSnapshot {
  rank: number;
  playerName: string;
  playerPhoto?: string;
  teamName: string;
  teamLogo?: string;
  jerseyNumber?: number | string;
  goals: number;
  assists: number;
  appearances: number;
  points: number;
  rating?: string | number;
  fetchedAt: string;
}

export interface PlayerRankingItem {
  id: string;
  playerId?: number | string;
  rank: number;
  playerName: string;
  playerFirstname?: string;
  playerLastname?: string;
  playerPhoto?: string;
  jerseyNumber?: number | string;
  teamId?: number | string;
  teamName: string;
  teamLogo?: string;
  competitionId: number;
  competitionName: string;
  season: number;
  rankingType: 'top_scorers' | 'points_performance';
  goals: number;
  assists: number;
  appearances: number;
  minutes?: number;
  points: number;
  penalties?: number;
  rating?: string | number;
  isManuallyModified: boolean;
  manualOverrideReason?: string;
  modifiedAt?: string;
  modifiedByAdminId?: string;
  modifiedByAdminName?: string;
  officialSnapshot?: PlayerOfficialSnapshot;
}

export interface PlayerRankingAudit {
  id: string;
  timestamp: string;
  adminId: string;
  adminName: string;
  action: 'create' | 'update' | 'delete' | 'restore_official' | 'reorder';
  competitionId: number;
  competitionName: string;
  rankingType: 'top_scorers' | 'points_performance';
  playerId?: string | number;
  playerName: string;
  details: string;
  changes?: Record<string, { before: any; after: any }>;
}

