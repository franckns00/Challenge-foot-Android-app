import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Language, SUPPORTED_LANGUAGES, LanguageOption } from './types';
import { translations } from './translations';

interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, params?: Record<string, string | number>) => string;
  currentOption: LanguageOption;
  languages: LanguageOption[];
}

const STORAGE_KEY = 'challengefoot_language';

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export const I18nProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === 'ht' || saved === 'fr' || saved === 'en') {
        return saved;
      }
    } catch {
      // fallback
    }
    // Default language is Haitian Creole (ht)
    return 'ht';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch {
      // storage unavailable
    }
    // Update html lang attribute
    document.documentElement.lang = lang;
  };

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const t = (key: string, params?: Record<string, string | number>): string => {
    const langDict = translations[language];
    let val = langDict ? langDict[key] : undefined;

    // Fallback to Haitian Creole if not found in current language
    if (!val && language !== 'ht') {
      val = translations.ht[key];
    }
    // Fallback to French if not found in ht
    if (!val && language !== 'fr') {
      val = translations.fr[key];
    }
    // If still missing, return readable label instead of ugly technical key
    if (!val) {
      const parts = key.split('.');
      const readable = parts[parts.length - 1].replace(/_/g, ' ');
      return readable.charAt(0).toUpperCase() + readable.slice(1);
    }

    if (params) {
      Object.entries(params).forEach(([paramKey, paramVal]) => {
        val = val!.replace(new RegExp(`\\{${paramKey}\\}`, 'g'), String(paramVal));
      });
    }

    return val;
  };

  const currentOption = SUPPORTED_LANGUAGES.find((opt) => opt.code === language) || SUPPORTED_LANGUAGES[0];

  return (
    <I18nContext.Provider
      value={{
        language,
        setLanguage,
        t,
        currentOption,
        languages: SUPPORTED_LANGUAGES,
      }}
    >
      {children}
    </I18nContext.Provider>
  );
};

export const useI18n = (): I18nContextType => {
  const ctx = useContext(I18nContext);
  if (!ctx) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return ctx;
};

export * from './types';
