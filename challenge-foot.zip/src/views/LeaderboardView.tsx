import React, { useState } from 'react';
import { useI18n } from '../i18n';
import { ChallengeTier, ParticipantRecord, CategoryFinanceReport } from '../types';
import {
  ARCHIVED_WEEKS,
  ArchivedRound,
} from '../data/participantsData';
import {
  Trophy,
  Award,
  Medal,
  Users,
  DollarSign,
  ShieldCheck,
  Search,
  Filter,
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  ChevronDown,
  Info,
  Download,
  Eye,
  X,
  FileSpreadsheet,
} from 'lucide-react';

interface LeaderboardViewProps {
  initialTier?: ChallengeTier;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({ initialTier = 'bronze' }) => {
  const { t, language } = useI18n();

  // State
  const [timeframe, setTimeframe] = useState<'day' | 'week' | 'all_time'>('day');
  const [selectedTier, setSelectedTier] = useState<ChallengeTier>(initialTier);
  const [selectedWeekId, setSelectedWeekId] = useState<string>('w42');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'winner' | 'outside_top5'>('all');
  const [pageSize, setPageSize] = useState<number | 'all'>('all'); // Default to show ALL (100) or 25 / 50
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [inspectingParticipant, setInspectingParticipant] = useState<ParticipantRecord | null>(null);

  // Active round data based on archive selection
  const currentRound: ArchivedRound =
    ARCHIVED_WEEKS.find((w) => w.id === selectedWeekId) || ARCHIVED_WEEKS[0];

  const participants: ParticipantRecord[] =
    currentRound.participantsByTier[selectedTier] || [];
  const financeReport: CategoryFinanceReport =
    currentRound.reportsByTier[selectedTier];

  // Filtering
  const filteredParticipants = participants.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.participantNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'winner'
        ? p.rank <= 5
        : p.rank > 5;
    return matchesSearch && matchesStatus;
  });

  const effectivePageSize = pageSize === 'all' ? filteredParticipants.length : pageSize;
  const totalPages = Math.ceil(filteredParticipants.length / (effectivePageSize || 1)) || 1;
  const paginatedParticipants =
    pageSize === 'all'
      ? filteredParticipants
      : filteredParticipants.slice(
          (currentPage - 1) * pageSize,
          currentPage * pageSize
        );

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Pozisyon (Rank)',
      'Nimewo Patisipan',
      'Non Patisipan',
      'Kategori',
      'Total Pwen',
      'Not Egzak (10pts)',
      'Bon Rezilta 1X2 (3pts)',
      'Rate',
      'Bonus Bite (+5pts)',
      'Estati',
      'Pri Genyen (HTG)',
    ];

    const rows = filteredParticipants.map((p) => [
      p.rank,
      p.participantNumber,
      `"${p.name}"`,
      p.tier.toUpperCase(),
      p.totalPoints,
      p.exactPredictions,
      p.correctOutcomes,
      p.missedPredictions,
      p.scorerBonus,
      p.rank <= 5 ? 'GAYAN TOP 5' : 'PA NAN 5 PREMYE YO',
      p.prizeWon,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `ChallengeFoot_${currentRound.id}_${selectedTier}_100_Patisipan.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-6 sm:py-8 space-y-8">
      {/* 1. Header & Week Archive Selector & Category Tabs */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-1.5">
            <span className="w-7 h-7 rounded-lg bg-blue-500/20 text-[#38BDF8] flex items-center justify-center">
              <Trophy className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-[#38BDF8]">
              {currentRound.label}
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              {currentRound.statusText}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t('leaderboard.title')} & {t('participants.all_title')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Classement certifié calculé par le serveur après validation des résultats officiels API-Football.
          </p>

          {/* Timeframe Switcher: Jour, Semaine, Général */}
          <div className="flex items-center gap-1.5 pt-3">
            <button
              onClick={() => setTimeframe('day')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer border ${
                timeframe === 'day'
                  ? 'bg-[#0B61DF] text-white border-blue-400 shadow'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              Classement du Jour
            </button>
            <button
              onClick={() => setTimeframe('week')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer border ${
                timeframe === 'week'
                  ? 'bg-[#0B61DF] text-white border-blue-400 shadow'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              Classement de la Semaine
            </button>
            <button
              onClick={() => setTimeframe('all_time')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer border ${
                timeframe === 'all_time'
                  ? 'bg-[#0B61DF] text-white border-blue-400 shadow'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              Classement Général
            </button>
          </div>
        </div>

        {/* Controls: Archive Dropdown + Category Switcher */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Historical Archives Dropdown */}
          <div className="flex items-center gap-2 bg-slate-900/90 px-3 py-2 rounded-2xl border border-slate-800">
            <Calendar className="w-4 h-4 text-blue-400 shrink-0" />
            <select
              value={selectedWeekId}
              onChange={(e) => {
                setSelectedWeekId(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer pr-2"
              title="Konsève ansyen klasman yo nan achiv"
            >
              {ARCHIVED_WEEKS.map((w) => (
                <option key={w.id} value={w.id} className="bg-slate-900 text-white">
                  {w.label}
                </option>
              ))}
            </select>
          </div>

          {/* Category Tabs: Bronze, Silver, Gold */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800">
            <button
              onClick={() => {
                setSelectedTier('bronze');
                setCurrentPage(1);
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedTier === 'bronze'
                  ? 'bg-amber-600 text-white shadow-lg shadow-amber-900/40 ring-2 ring-amber-400/50'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>BRONZE</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/30">100 HTG</span>
            </button>

            <button
              onClick={() => {
                setSelectedTier('silver');
                setCurrentPage(1);
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedTier === 'silver'
                  ? 'bg-slate-300 text-black shadow-lg ring-2 ring-white/50'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>SILVER</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/20">250 HTG</span>
            </button>

            <button
              onClick={() => {
                setSelectedTier('gold');
                setCurrentPage(1);
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedTier === 'gold'
                  ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-black shadow-lg ring-2 ring-yellow-400/60'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>GOLD</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/20">500 HTG</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tie-breaking rule & Certification Banner */}
      <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong>Règle de départage officielle :</strong> En cas d'égalité de points, les participants sont départagés par :
            1) Plus grand nombre de scores exacts (10 pts), 2) Plus grand nombre d'issues 1X2 correctes (3 pts), 3) Horodatage de validation le plus précoce.
          </span>
        </div>
        <span className="text-[10px] font-mono text-slate-400 shrink-0 pl-2">
          Calcul Serveur Vérifié
        </span>
      </div>

      {/* 2. REGLES FINANCIERES & CALCUL AUTOMATIQUE (40% / 60%) */}
      <div className="rounded-3xl bg-[#0D1C34] border border-blue-500/30 p-5 sm:p-6 shadow-xl relative overflow-hidden space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div>
            <span className="text-[11px] font-bold text-[#38BDF8] uppercase tracking-wider">
              {t('finances.title')} — Règ Finansye Ofisyèl
            </span>
            <h3 className="text-base sm:text-lg font-black text-white">
              Bilan Financier & Transparans — Catégorie {selectedTier.toUpperCase()}
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-amber-300 font-semibold flex items-center gap-1.5 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              100% Peman Konfime · 0 Ranbousman
            </span>
          </div>
        </div>

        {/* 4 Financial Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 text-xs">
          {/* Total confirmed participants */}
          <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
            <span className="text-slate-400 font-medium">{t('finances.count')}</span>
            <p className="text-xl sm:text-2xl font-black text-white font-mono tabular-nums">
              {financeReport.totalConfirmedParticipants} moun
            </p>
            <span className="text-[10px] text-slate-500 font-mono">
              Frè antre: {financeReport.entryFeePerPerson} HTG / moun
            </span>
          </div>

          {/* Total Money Collected */}
          <div className="p-3.5 rounded-xl bg-slate-900/90 border border-blue-500/30 space-y-1">
            <span className="text-slate-400 font-medium">{t('finances.total_collected')}</span>
            <p className="text-xl sm:text-2xl font-black text-[#38BDF8] font-mono tabular-nums">
              {financeReport.totalCollectedAmount.toLocaleString()} HTG
            </p>
            <span className="text-[10px] text-emerald-400 font-semibold">
              100% lajan reyèl konfime
            </span>
          </div>

          {/* Owner's Share (40%) */}
          <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1">
            <span className="text-slate-400 font-medium">{t('finances.owner_share')}</span>
            <p className="text-xl sm:text-2xl font-black text-amber-400 font-mono tabular-nums">
              {financeReport.ownerShareAmount.toLocaleString()} HTG
            </p>
            <span className="text-[10px] text-slate-400 font-mono">
              40% frè operasyon & platfòm
            </span>
          </div>

          {/* Winners Pool (60%) */}
          <div className="p-3.5 rounded-xl bg-gradient-to-br from-blue-900/40 to-slate-900 border border-emerald-500/40 space-y-1">
            <span className="text-emerald-300 font-medium">{t('finances.winners_fund')}</span>
            <p className="text-xl sm:text-2xl font-black text-emerald-400 font-mono tabular-nums">
              {financeReport.winnersShareAmount.toLocaleString()} HTG
            </p>
            <span className="text-[10px] text-emerald-200">
              60% pataje pami 5 premye gayan yo
            </span>
          </div>
        </div>

        {/* Detailed Breakdown formula note */}
        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-2 text-[11px] text-slate-300">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-blue-400 shrink-0" />
            <span>
              <strong>Règ kalkil otomatik :</strong> 40% ({financeReport.ownerShareAmount.toLocaleString()} HTG) rete pou administrasyon Challenge Foot, 60% ({financeReport.winnersShareAmount.toLocaleString()} HTG) distribye san reta pou 5 premye gayan yo (1ye: 40%, 2yèm: 25%, 3yèm: 15%, 4yèm: 12%, 5yèm: 8%).
            </span>
          </div>
          <span className="font-mono text-emerald-400 font-bold shrink-0">
            {financeReport.winnersShareAmount} HTG = 100% Fon Gayan
          </span>
        </div>
      </div>

      {/* 3. PODIUM TABLO « 5 GAYAN CHALLENGE SEMÈN NAN » */}
      <div className="rounded-3xl bg-gradient-to-b from-[#0D1C34] via-[#07101F] to-[#07101F] border border-yellow-500/50 p-5 sm:p-7 shadow-2xl space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-yellow-500/20">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-yellow-500/20 text-yellow-400 flex items-center justify-center font-bold text-xl shadow-inner">
              🏆
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-yellow-400 uppercase tracking-tight">
                  5 GAYAN CHALLENGE SEMÈN NAN
                </h2>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-yellow-500/20 text-yellow-300 font-bold border border-yellow-500/30">
                  {selectedTier.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Dat challenge la fini : <strong>{currentRound.endDate} a {currentRound.closingTime}</strong> · {currentRound.label}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-3 text-xs bg-slate-900/90 px-4 py-2.5 rounded-2xl border border-yellow-500/30">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Pri 5 Gayan yo (60%)</span>
              <strong className="text-emerald-400 text-sm sm:text-base font-mono">
                {financeReport.winnersShareAmount.toLocaleString()} HTG
              </strong>
            </div>
            <div className="hidden sm:block w-px h-6 bg-slate-800" />
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Mòd Peman</span>
              <span className="text-white font-bold">MonCash / NatCash</span>
            </div>
          </div>
        </div>

        {/* 5 Winners Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 pt-1">
          {financeReport.winners.map((w) => {
            const isFirst = w.rank === 1;
            const isSecond = w.rank === 2;
            const isThird = w.rank === 3;
            const medal = isFirst ? '🥇' : isSecond ? '🥈' : isThird ? '🥉' : `#${w.rank}`;
            const fullParticipant = participants.find((p) => p.rank === w.rank);

            return (
              <div
                key={w.rank}
                onClick={() => fullParticipant && setInspectingParticipant(fullParticipant)}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 relative overflow-hidden cursor-pointer hover:scale-[1.02] ${
                  isFirst
                    ? 'bg-gradient-to-b from-yellow-500/20 via-slate-900 to-slate-900 border-yellow-500 shadow-xl shadow-yellow-500/10'
                    : isSecond
                    ? 'bg-slate-900/95 border-slate-300/60 shadow-lg'
                    : isThird
                    ? 'bg-slate-900/95 border-amber-600/60 shadow-lg'
                    : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl">{medal}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/40 text-slate-200 font-bold">
                      {w.percentageOfFund}% fon an
                    </span>
                  </div>

                  <div className="mt-2.5 space-y-0.5">
                    <span className="text-[10px] font-mono text-[#38BDF8] font-bold">
                      {w.participantNumber}
                    </span>
                    <h4 className="text-xs sm:text-sm font-extrabold text-white truncate" title={w.name}>
                      {w.name}
                    </h4>
                    <span className="text-[10px] text-emerald-400 font-semibold block">
                      {isFirst ? '1ye Plas (Chanpyon)' : `${w.rank}yèm Plas`}
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5 pt-2 border-t border-slate-800 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Pwen :</span>
                    <span className="font-bold font-mono text-white">{w.points} pts</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Nòt Egzak :</span>
                    <span className="font-bold font-mono text-emerald-400">{w.exactPredictions}</span>
                  </div>
                  <div className="flex justify-between pt-1.5 border-t border-slate-800/80 text-xs">
                    <span className="text-slate-300 font-semibold">Pri Kach :</span>
                    <span className="font-black font-mono text-emerald-400 text-sm">
                      {w.prizeAmount.toLocaleString()} HTG
                    </span>
                  </div>
                </div>

                <div className="text-[10px] text-center text-blue-400 font-semibold pt-1 flex items-center justify-center gap-1 opacity-80 hover:opacity-100">
                  <Eye className="w-3 h-3" />
                  <span>Klike pou wè pwonostik li</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. LIS TOUT PATISIPAN YO (FULL LIST - ALL 100 IN BRONZE, ALL 60 IN SILVER, ALL 40 IN GOLD) */}
      <div className="rounded-3xl bg-[#0D1C34] border border-slate-800 overflow-hidden shadow-2xl space-y-0">
        {/* Table Controls: Search, Status Filter, Page Size, Export CSV */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-[#38BDF8]" />
              <span>
                {t('participants.all_title')} — Catégorie {selectedTier.toUpperCase()}
              </span>
              <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
                {participants.length} moun total
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Si gen {participants.length} moun nan {selectedTier.toUpperCase()}, tout {participants.length} non yo parèt la avèk tout detay nòt yo.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search Box */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Chèche non oswa #BR-001..."
                className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none w-48 sm:w-56"
              />
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-700 text-[11px]">
              <button
                onClick={() => {
                  setStatusFilter('all');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors cursor-pointer ${
                  statusFilter === 'all'
                    ? 'bg-[#0B61DF] text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Tout ({participants.length})
              </button>
              <button
                onClick={() => {
                  setStatusFilter('winner');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors cursor-pointer ${
                  statusFilter === 'winner'
                    ? 'bg-yellow-500 text-black font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Top 5
              </button>
              <button
                onClick={() => {
                  setStatusFilter('outside_top5');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors cursor-pointer ${
                  statusFilter === 'outside_top5'
                    ? 'bg-slate-700 text-white font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Pa nan 5 premye yo ({participants.length - 5})
              </button>
            </div>

            {/* View Page Size: Show All (100) vs 25 vs 50 */}
            <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-xl border border-slate-700 text-[11px]">
              <span className="text-slate-400 text-[10px]">Paj :</span>
              <button
                onClick={() => {
                  setPageSize('all');
                  setCurrentPage(1);
                }}
                className={`px-2 py-0.5 rounded cursor-pointer font-bold ${
                  pageSize === 'all' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Montre tout 100 patisipan yo sou menm paj"
              >
                Tout ({participants.length})
              </button>
              <button
                onClick={() => {
                  setPageSize(25);
                  setCurrentPage(1);
                }}
                className={`px-2 py-0.5 rounded cursor-pointer ${
                  pageSize === 25 ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                25
              </button>
              <button
                onClick={() => {
                  setPageSize(50);
                  setCurrentPage(1);
                }}
                className={`px-2 py-0.5 rounded cursor-pointer ${
                  pageSize === 50 ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                50
              </button>
            </div>

            {/* Export CSV button */}
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Telechaje tout lis la nan fòma CSV"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Ekspòte CSV</span>
            </button>
          </div>
        </div>

        {/* The Full Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/90 border-b border-slate-800 text-slate-400 uppercase text-[10px] font-bold tracking-wider">
              <tr>
                <th className="py-3 px-3 sm:px-4 text-center">{t('leaderboard.rank')}</th>
                <th className="py-3 px-3 sm:px-4">Nimewo & Non Patisipan</th>
                <th className="py-3 px-3 sm:px-4 text-center font-bold text-white">{t('leaderboard.total_points')}</th>
                <th className="py-3 px-3 sm:px-4 text-center">{t('participants.exact')} (10pts)</th>
                <th className="py-3 px-3 sm:px-4 text-center">{t('participants.correct')} (3pts)</th>
                <th className="py-3 px-3 sm:px-4 text-center">Pronos</th>
                <th className="py-3 px-3 sm:px-4 text-center">% Réussite</th>
                <th className="py-3 px-3 sm:px-4 text-center">{t('participants.status')}</th>
                <th className="py-3 px-3 sm:px-4 text-right">Pri Genyen</th>
                <th className="py-3 px-3 sm:px-4 text-center">Aksyon</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {paginatedParticipants.map((p) => {
                const isWinner = p.rank <= 5;
                return (
                  <tr
                    key={p.id}
                    className={`hover:bg-slate-800/50 transition-colors ${
                      isWinner ? 'bg-yellow-500/5' : ''
                    }`}
                  >
                    {/* Rank */}
                    <td className="py-3 px-3 sm:px-4 text-center font-mono font-bold">
                      {p.rank === 1 && (
                        <span className="w-6 h-6 rounded-full bg-yellow-400/20 text-yellow-400 flex items-center justify-center font-bold mx-auto border border-yellow-400/50">
                          1
                        </span>
                      )}
                      {p.rank === 2 && (
                        <span className="w-6 h-6 rounded-full bg-slate-300/20 text-slate-200 flex items-center justify-center font-bold mx-auto border border-slate-300/40">
                          2
                        </span>
                      )}
                      {p.rank === 3 && (
                        <span className="w-6 h-6 rounded-full bg-amber-600/20 text-amber-500 flex items-center justify-center font-bold mx-auto border border-amber-600/40">
                          3
                        </span>
                      )}
                      {p.rank > 3 && (
                        <span className="text-slate-400">#{p.rank}</span>
                      )}
                    </td>

                    {/* Participant Avatar, Number & Name */}
                    <td className="py-3 px-3 sm:px-4">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={p.avatarUrl}
                          alt={p.name}
                          className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 shrink-0"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-white font-bold">{p.name}</span>
                          </div>
                          <span className="text-[10px] font-mono text-[#38BDF8]">
                            {p.participantNumber}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Total Points */}
                    <td className="py-3 px-3 sm:px-4 text-center font-mono font-black text-sm text-white">
                      {p.totalPoints} pts
                    </td>

                    {/* Exact scores */}
                    <td className="py-3 px-3 sm:px-4 text-center font-mono font-bold text-emerald-400">
                      {p.exactPredictions}
                    </td>

                    {/* Correct 1X2 outcomes */}
                    <td className="py-3 px-3 sm:px-4 text-center font-mono text-blue-300">
                      {p.correctOutcomes}
                    </td>

                    {/* Pronostics Soumis */}
                    <td className="py-3 px-3 sm:px-4 text-center font-mono font-semibold text-slate-300">
                      10 / 10
                    </td>

                    {/* % Réussite calculé à partir des données réelles */}
                    <td className="py-3 px-3 sm:px-4 text-center font-mono font-black text-emerald-400">
                      {Math.min(100, Math.round(((p.exactPredictions + p.correctOutcomes) / 10) * 100))}%
                    </td>

                    {/* Status: Winner or Outside Top 5 */}
                    <td className="py-3 px-3 sm:px-4 text-center">
                      {isWinner ? (
                        <span className="px-2.5 py-0.5 rounded text-[10px] font-bold uppercase bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 shadow-sm">
                          {t('participants.status_winner')}
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-medium text-slate-400 bg-slate-900 border border-slate-800">
                          {t('participants.status_outside_top5')}
                        </span>
                      )}
                    </td>

                    {/* Prize Won */}
                    <td className="py-3 px-3 sm:px-4 text-right font-mono font-bold tabular-nums">
                      {p.prizeWon > 0 ? (
                        <span className="text-emerald-400 font-black text-xs">
                          {p.prizeWon.toLocaleString()} HTG
                        </span>
                      ) : (
                        <span className="text-slate-600">—</span>
                      )}
                    </td>

                    {/* Inspect Action */}
                    <td className="py-3 px-3 sm:px-4 text-center">
                      <button
                        onClick={() => setInspectingParticipant(p)}
                        className="p-1 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
                        title="Gade prediksyon detaye patisipan sa a"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination or Full Count Summary */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-400">
          <div>
            Montre <strong className="text-white">{paginatedParticipants.length}</strong> sou{' '}
            <strong className="text-white">{filteredParticipants.length}</strong> patisipan nan kategori{' '}
            <strong className="text-white">{selectedTier.toUpperCase()}</strong>
            {pageSize === 'all' && ' (Tout 100 non yo afiche nèt)'}
          </div>

          {pageSize !== 'all' && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 disabled:opacity-40 text-white cursor-pointer hover:bg-slate-800 transition-colors"
              >
                Anvan
              </button>
              <span className="font-mono text-white">
                Paj {currentPage} / {totalPages || 1}
              </span>
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 disabled:opacity-40 text-white cursor-pointer hover:bg-slate-800 transition-colors"
              >
                Apre
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 5. PARTICIPANT DETAILED MODAL */}
      {inspectingParticipant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0D1C34] border border-blue-500/50 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <img
                  src={inspectingParticipant.avatarUrl}
                  alt={inspectingParticipant.name}
                  className="w-10 h-10 rounded-full border border-slate-700"
                />
                <div>
                  <h3 className="text-base font-extrabold text-white">
                    {inspectingParticipant.name}
                  </h3>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-mono text-[#38BDF8] font-bold">
                      {inspectingParticipant.participantNumber}
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="uppercase font-bold text-amber-400">
                      {inspectingParticipant.tier}
                    </span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setInspectingParticipant(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">Pozisyon</span>
                <strong className="text-white text-base font-mono">
                  #{inspectingParticipant.rank}
                </strong>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">Total Pwen</span>
                <strong className="text-[#38BDF8] text-base font-mono">
                  {inspectingParticipant.totalPoints} pts
                </strong>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">Nòt Egzak</span>
                <strong className="text-emerald-400 text-base font-mono">
                  {inspectingParticipant.exactPredictions}
                </strong>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">Pri Kach</span>
                <strong className="text-emerald-400 text-base font-mono">
                  {inspectingParticipant.prizeWon > 0
                    ? `${inspectingParticipant.prizeWon.toLocaleString()} HTG`
                    : '0 HTG'}
                </strong>
              </div>
            </div>

            {/* Status & Payment confirmation info */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Estati Klasman :</span>
                <span className="font-bold text-white">
                  {inspectingParticipant.rank <= 5 ? (
                    <span className="text-emerald-400">Gayan Top 5 ({inspectingParticipant.prizeWon.toLocaleString()} HTG)</span>
                  ) : (
                    <span className="text-slate-400">Pa nan 5 premye yo</span>
                  )}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Frè Antre Peye :</span>
                <span className="font-mono text-emerald-400 font-semibold">
                  {inspectingParticipant.paidFee} HTG (Konfime pa MonCash/NatCash)
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Dat Soumisyon :</span>
                <span className="font-mono text-slate-300">
                  {new Date(inspectingParticipant.submittedAt).toLocaleString('fr-FR')}
                </span>
              </div>
            </div>

            {/* Simulated 10 matches breakdown preview */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300">
                Bilan sou 10 Match yo (150 pwen posib) :
              </h4>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-[11px] space-y-1.5 text-slate-300">
                <p>
                  🎯 <strong>{inspectingParticipant.exactPredictions} match jwenn nòt egzak</strong> ={' '}
                  <span className="font-mono text-emerald-400">
                    {inspectingParticipant.exactPredictions * 10} pwen
                  </span>
                </p>
                <p>
                  ✅ <strong>{inspectingParticipant.correctOutcomes} match jwenn bon rezilta 1X2</strong> ={' '}
                  <span className="font-mono text-blue-300">
                    {inspectingParticipant.correctOutcomes * 3} pwen
                  </span>
                </p>
                <p>
                  ❌ <strong>{inspectingParticipant.missedPredictions} match rate</strong> ={' '}
                  <span className="font-mono text-slate-500">0 pwen</span>
                </p>
                <p>
                  ⚽ <strong>Bonus Bitè</strong> ={' '}
                  <span className="font-mono text-amber-300">
                    +{inspectingParticipant.scorerBonus} pwen
                  </span>
                </p>
              </div>
            </div>

            <button
              onClick={() => setInspectingParticipant(null)}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer transition-colors"
            >
              Fèmen
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
