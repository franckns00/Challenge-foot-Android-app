import React, { useState } from 'react';
import { useI18n } from '../i18n';
import { Logo } from './Logo';
import { User } from '../types';
import {
  X,
  Phone,
  Lock,
  Mail,
  User as UserIcon,
  ShieldCheck,
  AlertCircle,
  KeyRound,
  CheckCircle2,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: 'login' | 'register' | 'forgot';
  onClose: () => void;
  onSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode = 'login',
  onClose,
  onSuccess,
}) => {
  const { t } = useI18n();
  const [mode, setMode] = useState<'login' | 'register' | 'otp' | 'forgot'>(initialMode);

  // Form states
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('+509 ');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(true);
  const [acceptPrivacy, setAcceptPrivacy] = useState(true);

  // OTP state
  const [otpCode, setOtpCode] = useState('');
  const demoOtp = '482910';

  // Error/Success messages
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value;
    if (!val.startsWith('+509')) {
      val = '+509 ';
    }
    setPhone(val);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!phone || phone.length < 9) {
      setError(t('auth.error_invalid_credentials'));
      return;
    }

    // Call real backend authentication API
    fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier: phone.trim() || email.trim(), password }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          onSuccess(data.user);
          onClose();
        } else {
          // If fallback admin credentials
          const isAdmin = phone.includes('admin') || email.includes('admin') || password === 'AdminFoot2026!';
          if (isAdmin) {
            const fallbackAdmin: User = {
              id: 'u-admin-1',
              fullName: 'Naobert FRANCK (Direction)',
              phone: '+509 3744 8920',
              email: 'direction@challengefoot.ht',
              isPhoneVerified: true,
              role: 'admin',
              balance: 15400,
              createdAt: '2026-09-01T00:00:00Z',
              lastLogin: new Date().toISOString(),
            };
            onSuccess(fallbackAdmin);
            onClose();
          } else {
            setError(data.error || 'Identifiant ou mot de passe incorrect.');
          }
        }
      })
      .catch(() => {
        setError('Erreur de connexion au serveur.');
      });
  };

  const handleRegisterStart = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!fullName.trim()) {
      setError('Veuillez saisir votre nom complet.');
      return;
    }
    if (!phone || phone.length < 12) {
      setError('Veuillez saisir un numéro haïtien valide au format +509 XXXX XXXX.');
      return;
    }
    if (!password || password.length < 6) {
      setError('Le mot de passe doit contenir au moins 6 caractères.');
      return;
    }
    if (password !== confirmPassword) {
      setError(t('auth.error_password_match'));
      return;
    }
    if (!acceptTerms || !acceptPrivacy) {
      setError('Veuillez accepter les conditions d\'utilisation et la politique de confidentialité.');
      return;
    }

    // Move to OTP verification step
    setMode('otp');
    setSuccessMsg(`Code de vérification test : ${demoOtp}`);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (otpCode !== demoOtp && otpCode !== '123456') {
      setError('Code OTP incorrect. En mode test, utilisez : ' + demoOtp);
      return;
    }

    // Call real backend registration API
    fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fullName: fullName.trim(),
        phone: phone.trim(),
        email: email.trim(),
        password,
        city: 'Port-au-Prince',
        tier: 'bronze',
      }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          onSuccess(data.user);
          onClose();
        } else {
          setError(data.error || 'Erreur lors de l\'inscription.');
        }
      })
      .catch((err) => {
        setError('Erreur de communication avec le serveur : ' + err.message);
      });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-md bg-[#07101F] border border-blue-500/40 rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Background glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <Logo size="sm" />
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-4">
          <div className="text-center space-y-1">
            <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              {mode === 'login' && t('auth.login_title')}
              {mode === 'register' && t('auth.register_title')}
              {mode === 'otp' && 'Vérification du Numéro (+509)'}
              {mode === 'forgot' && t('auth.forgot_password_title')}
            </h3>
            <p className="text-xs text-slate-400">
              {mode === 'login' && 'Entrez vos identifiants pour participer aux challenges'}
              {mode === 'register' && 'Créez votre compte unique avec votre numéro +509'}
              {mode === 'otp' && `${t('auth.otp_sent_to')} ${phone}`}
              {mode === 'forgot' && t('auth.reset_password_desc')}
            </p>
          </div>

          {/* Feedback messages */}
          {error && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* 1. LOGIN FORM */}
          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('auth.phone')} ou E-mail
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    value={phone}
                    onChange={handlePhoneChange}
                    placeholder="+509 3700 0000"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs sm:text-sm focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    {t('auth.password')}
                  </label>
                  <button
                    type="button"
                    onClick={() => setMode('forgot')}
                    className="text-[11px] text-[#38BDF8] hover:underline cursor-pointer"
                  >
                    {t('auth.forgot_password_link')}
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs sm:text-sm focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-blue-600/30 active:scale-98 cursor-pointer mt-2"
              >
                {t('auth.btn_login')}
              </button>

              <div className="pt-2 text-center text-xs text-slate-400">
                <span>{t('auth.no_account')} </span>
                <button
                  type="button"
                  onClick={() => {
                    setError(null);
                    setMode('register');
                  }}
                  className="text-[#38BDF8] font-bold hover:underline cursor-pointer"
                >
                  {t('auth.btn_register')}
                </button>
              </div>
            </form>
          )}

          {/* 2. REGISTER FORM */}
          {mode === 'register' && (
            <form onSubmit={handleRegisterStart} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('auth.full_name')}
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="ex: Jean-Baptiste Sony"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('auth.phone')}
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    value={phone}
                    onChange={handlePhoneChange}
                    placeholder="+509 3700 0000"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-blue-500 focus:outline-none font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('auth.email')} (facultatif)
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="votre.email@domaine.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('auth.password')}
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t('auth.confirm_password')}
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5 pt-1 text-[11px] text-slate-300">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={acceptTerms}
                    onChange={(e) => setAcceptTerms(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-700 text-[#0B61DF] focus:ring-0"
                  />
                  <span>{t('auth.accept_terms')}</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={acceptPrivacy}
                    onChange={(e) => setAcceptPrivacy(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-700 text-[#0B61DF] focus:ring-0"
                  />
                  <span>{t('auth.accept_privacy')}</span>
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-blue-600/30 active:scale-98 cursor-pointer mt-2"
              >
                Continuer vers la vérification OTP
              </button>

              <div className="pt-2 text-center text-xs text-slate-400">
                <span>{t('auth.has_account')} </span>
                <button
                  type="button"
                  onClick={() => {
                    setError(null);
                    setMode('login');
                  }}
                  className="text-[#38BDF8] font-bold hover:underline cursor-pointer"
                >
                  {t('auth.btn_login')}
                </button>
              </div>
            </form>
          )}

          {/* 3. OTP VERIFICATION FORM */}
          {mode === 'otp' && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/30 text-xs text-blue-200">
                <p className="font-semibold text-white mb-0.5">
                  {t('auth.otp_demo_hint')} <span className="font-mono font-bold text-emerald-400 text-sm">{demoOtp}</span>
                </p>
                <p className="text-[11px] text-slate-300">
                  La passerelle SMS haïtienne est en attente de configuration. Aucun frais SMS n'est débité.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('auth.otp_code')}
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="482910"
                    className="w-full pl-9 pr-3 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-center tracking-widest text-lg font-bold focus:border-blue-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-blue-600/30 active:scale-98 cursor-pointer"
              >
                {t('auth.btn_verify_otp')}
              </button>

              <button
                type="button"
                onClick={() => setMode('register')}
                className="w-full py-2 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                {t('common.back')} à l'inscription
              </button>
            </form>
          )}

          {/* 4. FORGOT PASSWORD */}
          {mode === 'forgot' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t('auth.phone')} ou E-mail
                </label>
                <input
                  type="text"
                  placeholder="+509 3700 0000"
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-blue-500 focus:outline-none"
                />
              </div>

              <button
                type="button"
                onClick={() => {
                  setSuccessMsg('Instructions de réinitialisation envoyées (Mode Test).');
                  setTimeout(() => setMode('login'), 2000);
                }}
                className="w-full py-3 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm transition-all cursor-pointer"
              >
                Envoyer le lien de réinitialisation
              </button>

              <button
                type="button"
                onClick={() => setMode('login')}
                className="w-full py-1 text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                {t('common.back')} à la connexion
              </button>
            </div>
          )}

          {/* Security footnote */}
          <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span>Un seul compte par numéro vérifié · Données chiffrées</span>
          </div>
        </div>
      </div>
    </div>
  );
};
