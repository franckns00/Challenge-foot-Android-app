import React, { useState, useEffect } from 'react';
import { I18nProvider, useI18n } from './i18n';
import { Header } from './components/Header';
import { TestModeBanner } from './components/TestModeBanner';
import { BottomNav } from './components/BottomNav';
import { MenuDrawer } from './components/MenuDrawer';
import { ApkDownloadModal } from './components/ApkDownloadModal';
import { AuthModal } from './components/AuthModal';

import { HomeView } from './views/HomeView';
import { AdvertisingView } from './views/AdvertisingView';
import { ChallengesView } from './views/ChallengesView';
import { LeaderboardView } from './views/LeaderboardView';
import { WalletView } from './views/WalletView';
import { AdminView } from './views/AdminView';
import {
  MatchesView,
  MyPredictionsView,
  RewardsView,
  ProfileView,
  PartnershipView,
  RulesView,
  AboutView,
  SettingsView,
} from './views/RemainingViews';
import { FootballStatsView } from './views/FootballStatsView';
import { ChallengeLiveView } from './views/ChallengeLiveView';
import { ClubView } from './views/ClubView';

import {
  INITIAL_CAMPAIGNS,
  INITIAL_CHALLENGE,
  INITIAL_LEADERBOARD,
  INITIAL_TRANSACTIONS,
} from './data/mockData';
import {
  User,
  Campaign,
  Challenge,
  LeaderboardEntry,
  Transaction,
  PredictionSubmission,
  ChallengeTier,
  MatchPick,
  PaymentMethod,
} from './types';

function ChallengeFootApp() {
  const { t, language } = useI18n();

  // Navigation State
  const [currentView, setCurrentView] = useState<string>('home');
  const [menuDrawerOpen, setMenuDrawerOpen] = useState(false);
  const [apkModalOpen, setApkModalOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');

  // Application Data States
  const [campaigns, setCampaigns] = useState<Campaign[]>(INITIAL_CAMPAIGNS);
  const [challenge, setChallenge] = useState<Challenge>(INITIAL_CHALLENGE);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(INITIAL_LEADERBOARD);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [predictions, setPredictions] = useState<PredictionSubmission[]>([]);

  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Authenticated User (Initialized with test account, can toggle/switch)
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('challengefoot_user');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      id: 'u-admin-1',
      fullName: 'Naobert FRANCK (Direction)',
      phone: '+509 3744 8920',
      email: 'direction@challengefoot.ht',
      isPhoneVerified: true,
      role: 'admin', // Admin by default to allow full dashboard & match testing
      balance: 15400,
      createdAt: '2026-09-01T00:00:00Z',
      lastLogin: new Date().toISOString(),
    };
  });

  // Save user session in localStorage
  useEffect(() => {
    try {
      if (user) {
        localStorage.setItem('challengefoot_user', JSON.stringify(user));
      } else {
        localStorage.removeItem('challengefoot_user');
      }
    } catch {}
  }, [user]);

  // Club Challenge Foot subscriber state (VIP status, ad-free experience, etc.)
  const [isClubSubscriber, setIsClubSubscriber] = useState<boolean>(false);

  useEffect(() => {
    if (user?.id) {
      fetch(`/api/club/status?userId=${user.id}`)
        .then((r) => r.json())
        .then((res) => {
          if (res.success) {
            setIsClubSubscriber(res.isActive);
          }
        })
        .catch(() => {});
    } else {
      setIsClubSubscriber(false);
    }
  }, [user]);

  // Network offline listener and Android Back Button ergonomics
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Android hardware / gesture back button
    const handleAndroidBack = () => {
      if (menuDrawerOpen) {
        setMenuDrawerOpen(false);
        return;
      }
      if (apkModalOpen) {
        setApkModalOpen(false);
        return;
      }
      if (authModalOpen) {
        setAuthModalOpen(false);
        return;
      }
      if (currentView !== 'home') {
        setCurrentView('home');
      }
    };

    // If running inside Capacitor native Android container
    import('@capacitor/app')
      .then(({ App: CapApp }) => {
        CapApp.addListener('backButton', () => {
          handleAndroidBack();
        });
      })
      .catch(() => {});

    window.addEventListener('popstate', handleAndroidBack);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('popstate', handleAndroidBack);
    };
  }, [menuDrawerOpen, apkModalOpen, authModalOpen, currentView]);

  // Fetch campaigns and challenge from server API on mount
  useEffect(() => {
    fetch('/api/campaigns?all=true')
      .then((res) => res.json())
      .then((data) => {
        if (data?.campaigns && Array.isArray(data.campaigns) && data.campaigns.length > 0) {
          setCampaigns(data.campaigns);
        }
      })
      .catch((err) => {
        console.log('Using local campaigns data', err);
      });

    fetch('/api/challenges/current')
      .then((res) => res.json())
      .then((data) => {
        if (data?.challenge) {
          setChallenge(data.challenge);
        }
      })
      .catch(() => {});
  }, []);

  // Handlers
  const handleNavigate = (view: string) => {
    if (view === 'download') {
      setApkModalOpen(true);
      return;
    }
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenLogin = () => {
    setAuthModalMode('login');
    setAuthModalOpen(true);
  };

  const handleOpenRegister = () => {
    setAuthModalMode('register');
    setAuthModalOpen(true);
  };

  const handleLogout = () => {
    setUser(null);
  };

  const handleCampaignClick = (id: string) => {
    fetch(`/api/campaigns/${id}/click`, { method: 'POST' }).catch(() => {});
    setCampaigns((prev) =>
      prev.map((c) => (c.id === id ? { ...c, clicks: (c.clicks || 0) + 1 } : c))
    );
  };

  const handleSaveCampaign = (camp: Campaign) => {
    // Save to server
    const isNew = !campaigns.some((c) => c.id === camp.id);
    const method = isNew ? 'POST' : 'PUT';
    const url = isNew ? '/api/campaigns' : `/api/campaigns/${camp.id}`;

    fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(camp),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.campaign) {
          if (isNew) {
            setCampaigns([data.campaign, ...campaigns]);
          } else {
            setCampaigns(campaigns.map((c) => (c.id === camp.id ? data.campaign : c)));
          }
        }
      })
      .catch(() => {
        // Local state update
        if (isNew) {
          setCampaigns([camp, ...campaigns]);
        } else {
          setCampaigns(campaigns.map((c) => (c.id === camp.id ? camp : c)));
        }
      });
  };

  const handleDeleteCampaign = (id: string) => {
    fetch(`/api/campaigns/${id}`, { method: 'DELETE' }).catch(() => {});
    setCampaigns((prev) => prev.filter((c) => c.id !== id));
  };

  const handleSubmitPredictions = (tier: ChallengeTier, picks: MatchPick[]) => {
    if (!user) return;

    fetch('/api/predictions/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        challengeId: challenge.id,
        userId: user.id,
        tier,
        picks,
      }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          setUser({ ...user, balance: data.newBalance });
          setPredictions([data.prediction, ...predictions]);
          alert('Vos pronostics ont été enregistrés avec succès sur le serveur et verrouillés pour le classement officiel !');
          setCurrentView('my-predictions');
        } else {
          alert(data.error || 'Erreur lors de la validation');
        }
      })
      .catch(() => {
        // Fallback local update
        const fee = tier === 'bronze' ? 100 : tier === 'silver' ? 250 : 500;
        const newBal = Math.max(0, user.balance - fee);
        setUser({ ...user, balance: newBal });
        alert(t('challenges.submitted_success'));
        setCurrentView('my-predictions');
      });
  };

  const handleDeposit = (amount: number, method: PaymentMethod) => {
    if (!user) return;

    fetch('/api/wallet/deposit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount, method }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          setUser({ ...user, balance: user.balance + amount });
          setTransactions([data.transaction, ...transactions]);
        }
      })
      .catch(() => {
        setUser({ ...user, balance: user.balance + amount });
      });
  };

  const handleWithdraw = (amount: number, phone: string, method: PaymentMethod) => {
    if (!user) return;

    fetch('/api/wallet/withdraw', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount, phone, method }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          setUser({ ...user, balance: Math.max(0, user.balance - amount) });
          setTransactions([data.transaction, ...transactions]);
          alert('Demande de retrait enregistrée et transmise à l\'administration pour vérification.');
        }
      })
      .catch(() => {
        setUser({ ...user, balance: Math.max(0, user.balance - amount) });
      });
  };

  const handleUpdateMatchResult = (
    matchId: string,
    homeScore: number,
    awayScore: number,
    scorerId: string
  ) => {
    // Update match state
    setChallenge((prev) => ({
      ...prev,
      matches: prev.matches.map((m) =>
        m.id === matchId
          ? {
              ...m,
              status: 'finished',
              homeScore,
              awayScore,
              actualGoalscorerId: scorerId,
            }
          : m
      ),
    }));

    // Recalculate points for submissions
    alert('Scores enregistrés ! Les points de chaque match ont été recalculés.');
  };

  const handleUpdateTransactionStatus = (txId: string, status: any) => {
    setTransactions((prev) =>
      prev.map((t) => (t.id === txId ? { ...t, status } : t))
    );
  };

  return (
    <div className="min-h-screen bg-[#07101F] text-slate-100 flex flex-col font-sans pb-20 lg:pb-8">
      {/* 1. Mandatory Test Mode Banner */}
      <TestModeBanner />

      {/* Network Offline Alert */}
      {!isOnline && (
        <div className="bg-red-600 text-white text-xs py-1.5 px-4 text-center font-bold flex items-center justify-center gap-2 animate-pulse">
          <span>⚠️ Connexion Internet interrompue. Les données locales sont protégées. Reconnexion automatique...</span>
        </div>
      )}

      {/* 2. Top Header Navigation */}
      <Header
        user={user}
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenLogin={handleOpenLogin}
        onOpenRegister={handleOpenRegister}
        onOpenDownload={() => setApkModalOpen(true)}
        onToggleMenu={() => setMenuDrawerOpen(true)}
        onLogout={handleLogout}
      />

      {/* 3. Main View Area */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomeView
            challenge={challenge}
            campaigns={campaigns}
            onNavigate={handleNavigate}
            onOpenDownload={() => setApkModalOpen(true)}
            onOpenRegister={handleOpenRegister}
            onCampaignClick={handleCampaignClick}
            isClubSubscriber={isClubSubscriber}
          />
        )}

        {currentView === 'advertising' && (
          <AdvertisingView
            campaigns={campaigns}
            onOpenDownload={() => setApkModalOpen(true)}
            onOpenRegister={handleOpenRegister}
            onNavigateToChallenges={() => handleNavigate('challenges')}
            onNavigateToWallet={() => handleNavigate('wallet')}
            onCampaignClick={handleCampaignClick}
          />
        )}

        {currentView === 'challenges' && (
          <ChallengesView
            challenge={challenge}
            user={user}
            onOpenLogin={handleOpenLogin}
            onSubmitPredictions={handleSubmitPredictions}
            onNavigateToLive={() => handleNavigate('challenge-live')}
          />
        )}

        {(currentView === 'challenge-live' || currentView === 'live' || currentView === 'matches') && (
          <ChallengeLiveView onNavigateToChallenge={() => handleNavigate('challenges')} />
        )}

        {currentView === 'stats' && (
          <FootballStatsView
            onNavigateToChallenge={() => handleNavigate('challenges')}
            onNavigateToLive={() => handleNavigate('challenge-live')}
          />
        )}

        {currentView === 'my-predictions' && (
          <MyPredictionsView
            user={user}
            challenge={challenge}
            predictions={predictions}
            onOpenLogin={handleOpenLogin}
            onNavigateToChallenges={() => handleNavigate('challenges')}
          />
        )}

        {(currentView === 'leaderboard' || currentView === 'bronze' || currentView === 'silver' || currentView === 'gold') && (
          <LeaderboardView
            initialTier={currentView === 'silver' ? 'silver' : currentView === 'gold' ? 'gold' : 'bronze'}
          />
        )}

        {currentView === 'rewards' && (
          <RewardsView />
        )}

        {currentView === 'club' && (
          <ClubView
            user={user}
            onOpenLogin={handleOpenLogin}
            onOpenRegister={handleOpenRegister}
            onNavigateToChallenges={() => handleNavigate('challenges')}
            onNavigateToWallet={() => handleNavigate('wallet')}
          />
        )}

        {(currentView === 'wallet' || currentView === 'withdraw' || currentView === 'history') && (
          <WalletView
            user={user}
            transactions={transactions}
            onOpenLogin={handleOpenLogin}
            onDeposit={handleDeposit}
            onWithdraw={handleWithdraw}
          />
        )}

        {currentView === 'profile' && (
          <ProfileView
            user={user}
            onOpenLogin={handleOpenLogin}
            onLogout={handleLogout}
          />
        )}

        {currentView === 'partnership' && (
          <PartnershipView />
        )}

        {currentView === 'rules' && (
          <RulesView />
        )}

        {currentView === 'about' && (
          <AboutView onOpenDownload={() => setApkModalOpen(true)} />
        )}

        {currentView === 'settings' && (
          <SettingsView onLogout={handleLogout} />
        )}

        {currentView === 'support' && (
          <div className="max-w-2xl mx-auto px-4 py-12 space-y-4">
            <h1 className="text-2xl font-bold text-white">{t('menu.support')}</h1>
            <p className="text-xs text-slate-300">
              Besoin d'aide pour vos pronostics, votre compte ou le mode test ? Contactez notre équipe de support.
            </p>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
              <p><strong>E-mail :</strong> support@challengefoot.ht</p>
              <p><strong>WhatsApp Support :</strong> +509 3744 8920</p>
              <p><strong>Heures d'ouverture :</strong> 7j/7, de 8h à 22h (Heure d'Haïti)</p>
            </div>
          </div>
        )}

        {currentView === 'admin' && (
          <AdminView
            campaigns={campaigns}
            matches={challenge.matches}
            transactions={transactions}
            onSaveCampaign={handleSaveCampaign}
            onDeleteCampaign={handleDeleteCampaign}
            onUpdateMatchResult={handleUpdateMatchResult}
            onUpdateTransactionStatus={handleUpdateTransactionStatus}
          />
        )}
      </main>

      {/* 4. Bottom Tab Bar for Mobile Devices */}
      <BottomNav
        currentView={currentView}
        onNavigate={handleNavigate}
        onToggleMenu={() => setMenuDrawerOpen(true)}
      />

      {/* 5. Full 17-item Slide-over Menu Drawer */}
      <MenuDrawer
        isOpen={menuDrawerOpen}
        onClose={() => setMenuDrawerOpen(false)}
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenDownload={() => setApkModalOpen(true)}
        user={user}
        onLogout={handleLogout}
      />

      {/* 6. APK Download Modal */}
      <ApkDownloadModal
        isOpen={apkModalOpen}
        onClose={() => setApkModalOpen(false)}
      />

      {/* 7. Authentication Modal (Register / Login / OTP) */}
      <AuthModal
        isOpen={authModalOpen}
        initialMode={authModalMode}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={(newUser) => setUser(newUser)}
      />
    </div>
  );
}

export default function App() {
  return (
    <I18nProvider>
      <ChallengeFootApp />
    </I18nProvider>
  );
}
