import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', showText = true, className = '' }) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  };

  const textSizes = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Crown + Soccer Ball Badge */}
      <div className={`relative ${iconSizes[size]} shrink-0 flex items-center justify-center`}>
        {/* Glow */}
        <div className="absolute inset-0 bg-[#0B61DF]/40 rounded-full blur-md" />
        
        <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 drop-shadow-md">
          <defs>
            <linearGradient id="cfBlue" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38BDF8" />
              <stop offset="100%" stopColor="#0B61DF" />
            </linearGradient>
            <linearGradient id="cfCrown" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#60A5FA" />
              <stop offset="100%" stopColor="#0B61DF" />
            </linearGradient>
          </defs>

          {/* Royal Crown on Top */}
          <path
            d="M 28 32 L 32 15 L 42 24 L 50 10 L 58 24 L 68 15 L 72 32 Z"
            fill="url(#cfCrown)"
            stroke="#FFFFFF"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          {/* Crown Jewels */}
          <circle cx="32" cy="14" r="2.5" fill="#38BDF8" stroke="#FFFFFF" strokeWidth="1" />
          <circle cx="50" cy="9" r="3" fill="#60A5FA" stroke="#FFFFFF" strokeWidth="1" />
          <circle cx="68" cy="14" r="2.5" fill="#38BDF8" stroke="#FFFFFF" strokeWidth="1" />

          {/* Dynamic "C" Swoosh Ring */}
          <path
            d="M 75 48 C 75 30, 60 25, 45 25 C 25 25, 12 40, 12 60 C 12 78, 28 92, 52 92 C 70 92, 85 80, 88 65"
            fill="none"
            stroke="url(#cfBlue)"
            strokeWidth="9"
            strokeLinecap="round"
          />

          {/* Inner Soccer Ball */}
          <circle cx="48" cy="58" r="22" fill="#FFFFFF" stroke="#0B61DF" strokeWidth="2.5" />
          {/* Soccer Pentagon Center */}
          <polygon
            points="48,46 56,52 53,61 43,61 40,52"
            fill="#07101F"
          />
          {/* Soccer Seams */}
          <line x1="48" y1="46" x2="48" y2="38" stroke="#07101F" strokeWidth="2" />
          <line x1="56" y1="52" x2="64" y2="49" stroke="#07101F" strokeWidth="2" />
          <line x1="53" y1="61" x2="59" y2="70" stroke="#07101F" strokeWidth="2" />
          <line x1="43" y1="61" x2="37" y2="70" stroke="#07101F" strokeWidth="2" />
          <line x1="40" y1="52" x2="32" y2="49" stroke="#07101F" strokeWidth="2" />

          {/* "F" Dynamic Swoosh Accent */}
          <path
            d="M 58 42 L 86 42 L 78 50 L 64 50 L 60 62 L 74 62 L 70 70 L 52 70 Z"
            fill="url(#cfBlue)"
          />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-baseline tracking-tight font-black leading-none italic">
            <span className={`text-white font-black tracking-wider uppercase font-sans ${textSizes[size]}`}>
              Challenge
            </span>
            <span className={`text-[#38BDF8] ml-1 font-extrabold uppercase ${textSizes[size]}`}>
              FOOT
            </span>
          </div>
          {size !== 'sm' && (
            <span className="text-[10px] text-slate-400 font-medium tracking-wide mt-0.5">
              Pwouve ou konn foutbòl.
            </span>
          )}
        </div>
      )}
    </div>
  );
};
