import React from 'react';
import { Radio, Clock, CheckCircle2, Shield, Flame, MapPin } from 'lucide-react';

export interface BeSoccerMatchProps {
  id: string | number;
  homeTeam: string;
  homeLogo?: string;
  homeScore?: number | null;
  awayTeam: string;
  awayLogo?: string;
  awayScore?: number | null;
  competition: string;
  competitionLogo?: string;
  country?: string;
  status: string; // 'NS', '1H', '2H', 'HT', 'ET', 'LIVE', 'FT', 'AET', 'PEN', 'PST', 'CANC'
  elapsed?: number | null;
  kickoffTime?: string;
  venue?: string;
  isChallengeMatch?: boolean;
  matchNumber?: number;
  userPrediction?: { home: number; away: number } | null;
  pointsEarned?: number | null;
  events?: any[];
  onClick?: () => void;
}

export const BeSoccerMatchRow: React.FC<BeSoccerMatchProps> = ({
  id,
  homeTeam,
  homeLogo,
  homeScore,
  awayTeam,
  awayLogo,
  awayScore,
  competition,
  competitionLogo,
  country,
  status = 'NS',
  elapsed,
  kickoffTime,
  venue,
  isChallengeMatch,
  matchNumber,
  userPrediction,
  pointsEarned,
  events = [],
  onClick,
}) => {
  const isLive = ['1H', '2H', 'HT', 'ET', 'LIVE'].includes(status);
  const isFinished = ['FT', 'AET', 'PEN'].includes(status);
  const isUpcoming = ['NS', 'TBD'].includes(status) || (!isLive && !isFinished);

  const formattedTime = kickoffTime
    ? new Date(kickoffTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : 'À VENIR';

  // Extract goal scorers if available
  const goalEvents = events.filter((e) => e.type === 'Goal');

  return (
    <div
      onClick={onClick}
      className={`rounded-xl bg-[#091528] border border-slate-800/90 hover:border-slate-700 transition shadow-sm overflow-hidden select-none ${
        onClick ? 'cursor-pointer active:scale-[0.99]' : ''
      }`}
    >
      {/* 1. Header: Competition & Kickoff / Live Indicator */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#060D19]/80 border-b border-slate-800/80 text-[11px]">
        <div className="flex items-center gap-1.5 truncate pr-2">
          {competitionLogo ? (
            <img
              src={competitionLogo}
              alt={competition}
              className="w-3.5 h-3.5 object-contain rounded-full bg-slate-900 shrink-0"
              loading="lazy"
            />
          ) : (
            <span className="text-[#38BDF8]">🏆</span>
          )}
          <span className="font-bold text-slate-300 truncate uppercase tracking-tight text-[10px]">
            {isChallengeMatch && matchNumber ? `Match #${matchNumber} · ` : ''}
            {competition} {country ? `(${country})` : ''}
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {isChallengeMatch && (
            <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
              CHALLENGE
            </span>
          )}
          <span className="text-[10px] font-mono text-slate-400">
            {isFinished ? 'TERMINÉ' : isLive ? 'EN DIRECT' : formattedTime}
          </span>
        </div>
      </div>

      {/* 2. Main Match Card: Authentic BeSoccer Clean Vertical Alignment */}
      <div className="p-3 grid grid-cols-12 items-center gap-2">
        {/* Left Column: Fixed Width Status & Minute Badge (3 cols) */}
        <div className="col-span-3 sm:col-span-2 flex flex-col items-center justify-center border-r border-slate-800/80 pr-2">
          {isLive ? (
            <div className="flex flex-col items-center justify-center">
              <span className="flex items-center gap-1 text-[10px] font-black text-red-400 font-mono tracking-tight animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 inline-block" />
                {status === 'HT' ? 'MI-TEMPS' : `${elapsed || 0}'`}
              </span>
              <span className="text-[9px] font-bold uppercase text-red-500/90 tracking-wider">
                LIVE
              </span>
            </div>
          ) : isFinished ? (
            <div className="flex flex-col items-center justify-center">
              <span className="text-[11px] font-black text-slate-300 font-mono">
                FT
              </span>
              <span className="text-[9px] font-semibold text-slate-400">
                Fin
              </span>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-slate-400">
              <Clock className="w-3.5 h-3.5 text-blue-400 mb-0.5" />
              <span className="text-[11px] font-bold text-slate-200 font-mono">
                {formattedTime}
              </span>
            </div>
          )}
        </div>

        {/* Center Column: Teams Names & Uniform Logos (7 cols) */}
        <div className="col-span-7 sm:col-span-8 flex flex-col justify-center space-y-2">
          {/* Home Team Row */}
          <div className="flex items-center gap-2.5 min-w-0">
            {homeLogo ? (
              <img
                src={homeLogo}
                alt={homeTeam}
                className="w-5 h-5 object-contain shrink-0 rounded-xs"
                loading="lazy"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <div className="w-5 h-5 rounded-full bg-slate-800 text-slate-400 text-[10px] flex items-center justify-center shrink-0">
                H
              </div>
            )}
            <span
              className={`text-xs font-bold truncate ${
                isFinished && typeof homeScore === 'number' && typeof awayScore === 'number' && homeScore > awayScore
                  ? 'text-white font-black'
                  : isFinished && typeof homeScore === 'number' && typeof awayScore === 'number' && homeScore < awayScore
                  ? 'text-slate-400'
                  : 'text-slate-100'
              }`}
            >
              {homeTeam}
            </span>
          </div>

          {/* Away Team Row */}
          <div className="flex items-center gap-2.5 min-w-0">
            {awayLogo ? (
              <img
                src={awayLogo}
                alt={awayTeam}
                className="w-5 h-5 object-contain shrink-0 rounded-xs"
                loading="lazy"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <div className="w-5 h-5 rounded-full bg-slate-800 text-slate-400 text-[10px] flex items-center justify-center shrink-0">
                A
              </div>
            )}
            <span
              className={`text-xs font-bold truncate ${
                isFinished && typeof homeScore === 'number' && typeof awayScore === 'number' && awayScore > homeScore
                  ? 'text-white font-black'
                  : isFinished && typeof homeScore === 'number' && typeof awayScore === 'number' && awayScore < homeScore
                  ? 'text-slate-400'
                  : 'text-slate-100'
              }`}
            >
              {awayTeam}
            </span>
          </div>
        </div>

        {/* Right Column: Dedicated Fixed Scores Column (2 cols) */}
        <div className="col-span-2 flex flex-col items-end justify-center space-y-2 font-mono font-black text-sm">
          {/* Home Score */}
          <span
            className={`w-6 h-5 flex items-center justify-center rounded text-center ${
              isLive
                ? 'text-emerald-400 bg-emerald-500/10'
                : isFinished
                ? 'text-white bg-slate-900'
                : 'text-slate-400'
            }`}
          >
            {homeScore !== null && homeScore !== undefined ? homeScore : '-'}
          </span>

          {/* Away Score */}
          <span
            className={`w-6 h-5 flex items-center justify-center rounded text-center ${
              isLive
                ? 'text-emerald-400 bg-emerald-500/10'
                : isFinished
                ? 'text-white bg-slate-900'
                : 'text-slate-400'
            }`}
          >
            {awayScore !== null && awayScore !== undefined ? awayScore : '-'}
          </span>
        </div>
      </div>

      {/* 3. Goalscorers Snippet (if available) */}
      {goalEvents.length > 0 && (
        <div className="px-3 py-1.5 bg-[#060D19]/60 border-t border-slate-800/80 text-[10px] text-slate-400 flex flex-wrap gap-2">
          {goalEvents.slice(0, 3).map((g: any, idx: number) => (
            <span key={idx} className="flex items-center gap-1">
              <span>⚽</span>
              <span className="font-semibold text-slate-300">{g.player?.name || 'Buteur'}</span>
              <span className="text-slate-400 font-mono">({g.time?.elapsed}')</span>
            </span>
          ))}
        </div>
      )}

      {/* 4. User Prediction Footnote (if Challenge prediction submitted) */}
      {userPrediction && (
        <div className="px-3 py-1.5 bg-[#08152B] border-t border-blue-500/20 text-[11px] flex items-center justify-between">
          <span className="text-slate-300">
            Mon Pronostic : <strong className="text-white font-mono">{userPrediction.home} - {userPrediction.away}</strong>
          </span>
          {pointsEarned !== null && pointsEarned !== undefined && (
            <span
              className={`font-mono font-black px-2 py-0.5 rounded text-[10px] ${
                pointsEarned === 10
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : pointsEarned === 3
                  ? 'bg-blue-500/20 text-blue-300'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {pointsEarned > 0 ? `+${pointsEarned} pts` : '0 pt'}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
