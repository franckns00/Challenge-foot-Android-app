import React, { useState } from 'react';
import { useI18n, Language } from '../i18n';
import { Logo } from './Logo';
import { User } from '../types';
import {
  Globe,
  Bell,
  Wallet,
  Menu,
  Shield,
  User as UserIcon,
  LogOut,
  ChevronDown,
  Download,
  Crown,
} from 'lucide-react';

interface HeaderProps {
  user: User | null;
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onOpenDownload: () => void;
  onToggleMenu: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  currentView,
  onNavigate,
  onOpenLogin,
  onOpenRegister,
  onOpenDownload,
  onToggleMenu,
  onLogout,
}) => {
  const { t, language, setLanguage, languages } = useI18n();
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [notifMenuOpen, setNotifMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const notifications = [
    {
      id: 'n1',
      title: language === 'ht' ? 'Chalanje Semèn #42 louvri!' : language === 'fr' ? 'Challenge Semaine #42 ouvert !' : 'Week #42 Challenge is Open!',
      time: 'Il y a 2h',
      read: false,
    },
    {
      id: 'n2',
      title: language === 'ht' ? 'Règ konkou ak Jouè disponib' : language === 'fr' ? 'Rosters et buteurs confirmés' : 'Squads and scorers updated',
      time: 'Il y a 5h',
      read: true,
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#07101F]/95 backdrop-blur-md border-b border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark & Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center text-left focus:outline-none cursor-pointer"
          >
            <Logo size="md" />
          </button>
        </div>

        {/* Zone 2: Navigation Links (Desktop 4-5 items) */}
        <nav className="hidden lg:flex items-center gap-6 text-xs xl:text-sm font-semibold text-slate-300">
          <button
            onClick={() => onNavigate('home')}
            className={`transition-colors cursor-pointer hover:text-white whitespace-nowrap ${
              currentView === 'home' ? 'text-[#38BDF8] border-b-2 border-[#38BDF8] pb-1' : ''
            }`}
          >
            {t('nav.home')}
          </button>
          <button
            onClick={() => onNavigate('challenges')}
            className={`transition-colors cursor-pointer hover:text-white whitespace-nowrap ${
              currentView === 'challenges' ? 'text-[#38BDF8] border-b-2 border-[#38BDF8] pb-1' : ''
            }`}
          >
            {t('nav.challenges')}
          </button>
          <button
            onClick={() => onNavigate('challenge-live')}
            className={`transition-colors cursor-pointer hover:text-white whitespace-nowrap flex items-center gap-1.5 ${
              currentView === 'challenge-live' ? 'text-red-400 border-b-2 border-red-400 pb-1 font-bold' : 'text-slate-300'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span>Challenge Live</span>
          </button>
          <button
            onClick={() => onNavigate('leaderboard')}
            className={`transition-colors cursor-pointer hover:text-white whitespace-nowrap ${
              currentView === 'leaderboard' ? 'text-[#38BDF8] border-b-2 border-[#38BDF8] pb-1' : ''
            }`}
          >
            {t('menu.leaderboard')}
          </button>
          <button
            onClick={() => onNavigate('wallet')}
            className={`transition-colors cursor-pointer hover:text-white whitespace-nowrap ${
              currentView === 'wallet' ? 'text-[#38BDF8] border-b-2 border-[#38BDF8] pb-1' : ''
            }`}
          >
            {t('nav.wallet')}
          </button>
          <button
            onClick={() => onNavigate('advertising')}
            className={`transition-colors cursor-pointer hover:text-white whitespace-nowrap ${
              currentView === 'advertising' ? 'text-[#38BDF8] border-b-2 border-[#38BDF8] pb-1' : ''
            }`}
          >
            {t('menu.advertising')}
          </button>
          <button
            onClick={() => onNavigate('club')}
            className={`transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black border ${
              currentView === 'club'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                : 'text-amber-400 border-amber-500/30 bg-amber-500/5 hover:bg-amber-500/15'
            }`}
          >
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>Club VIP</span>
          </button>
        </nav>

        {/* Zone 3: Actions (Language, Notifs, Balance / Auth, Hamburger) */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Language Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setLangMenuOpen(!langMenuOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 text-xs font-medium text-slate-200 transition-all cursor-pointer"
              title={t('settings.language')}
            >
              <Globe className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span className="uppercase font-bold tracking-wide">{language}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {langMenuOpen && (
              <div
                className="absolute right-0 mt-2 w-48 bg-[#0D1C34] border border-slate-700 rounded-xl shadow-2xl py-1 z-50 animate-in fade-in zoom-in-95 duration-100"
                onMouseLeave={() => setLangMenuOpen(false)}
              >
                <div className="px-3 py-1.5 text-[10px] uppercase font-bold tracking-wider text-slate-400 border-b border-slate-800">
                  {t('settings.language')}
                </div>
                {languages.map((item) => (
                  <button
                    key={item.code}
                    onClick={() => {
                      setLanguage(item.code);
                      setLangMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 text-xs text-left transition-colors cursor-pointer ${
                      language === item.code
                        ? 'bg-[#0B61DF] text-white font-semibold'
                        : 'text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span className="text-base">{item.flag}</span>
                      <span>{item.nativeName}</span>
                    </span>
                    {language === item.code && (
                      <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded">Active</span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Download APK Top Icon (Small Screens) */}
          <button
            onClick={onOpenDownload}
            className="hidden sm:flex md:hidden items-center justify-center w-9 h-9 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 text-[#38BDF8] transition-colors cursor-pointer"
            title={t('menu.download_app')}
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Notifications Bell */}
          <div className="relative">
            <button
              onClick={() => setNotifMenuOpen(!notifMenuOpen)}
              className="relative flex items-center justify-center w-9 h-9 rounded-lg bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 text-slate-300 hover:text-white transition-all cursor-pointer"
              title={t('nav.notifications')}
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#38BDF8]" />
            </button>

            {notifMenuOpen && (
              <div
                className="absolute right-0 mt-2 w-72 bg-[#0D1C34] border border-slate-700 rounded-xl shadow-2xl py-2 z-50 animate-in fade-in duration-100"
                onMouseLeave={() => setNotifMenuOpen(false)}
              >
                <div className="px-3 py-1.5 flex items-center justify-between border-b border-slate-800">
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    {t('nav.notifications')}
                  </span>
                  <span className="text-[10px] text-blue-400">2 nouvelles</span>
                </div>
                <div className="divide-y divide-slate-800/60 max-h-60 overflow-y-auto">
                  {notifications.map((n) => (
                    <div key={n.id} className="p-3 hover:bg-slate-800/50 transition-colors">
                      <p className="text-xs font-medium text-slate-200">{n.title}</p>
                      <span className="text-[10px] text-slate-500 mt-0.5 block">{n.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Account / Wallet Pill OR Login/Register Buttons */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-2 pl-2.5 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-blue-500 transition-all cursor-pointer"
              >
                <div className="w-6 h-6 rounded-full bg-[#0B61DF] flex items-center justify-center text-white text-[11px] font-bold">
                  {user.fullName.charAt(0)}
                </div>
                <div className="hidden sm:flex flex-col text-left">
                  <span className="text-xs font-bold text-white truncate max-w-[100px]">
                    {user.fullName}
                  </span>
                  <span className="text-[10px] font-mono font-semibold text-[#38BDF8] tabular-nums">
                    {user.balance.toLocaleString()} {t('common.haiti_currency')}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {userMenuOpen && (
                <div
                  className="absolute right-0 mt-2 w-56 bg-[#0D1C34] border border-slate-700 rounded-xl shadow-2xl py-1.5 z-50"
                  onMouseLeave={() => setUserMenuOpen(false)}
                >
                  <div className="px-4 py-2 border-b border-slate-800">
                    <p className="text-xs font-bold text-white">{user.fullName}</p>
                    <p className="text-[11px] text-slate-400 font-mono">{user.phone}</p>
                    <div className="mt-1.5 flex items-center justify-between text-xs">
                      <span className="text-slate-400">{t('nav.balance')}</span>
                      <span className="font-bold text-[#38BDF8] font-mono tabular-nums">
                        {user.balance.toLocaleString()} HTG
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onNavigate('wallet');
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-slate-200 hover:bg-slate-800 transition-colors text-left cursor-pointer"
                  >
                    <Wallet className="w-3.5 h-3.5 text-blue-400" />
                    <span>{t('menu.wallet')}</span>
                  </button>

                  <button
                    onClick={() => {
                      onNavigate('profile');
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-slate-200 hover:bg-slate-800 transition-colors text-left cursor-pointer"
                  >
                    <UserIcon className="w-3.5 h-3.5 text-blue-400" />
                    <span>{t('menu.profile')}</span>
                  </button>

                  {user.role === 'admin' && (
                    <button
                      onClick={() => {
                        onNavigate('admin');
                        setUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-amber-300 hover:bg-slate-800 transition-colors text-left cursor-pointer"
                    >
                      <Shield className="w-3.5 h-3.5 text-amber-400" />
                      <span>{t('nav.admin')}</span>
                    </button>
                  )}

                  <div className="border-t border-slate-800 my-1" />

                  <button
                    onClick={() => {
                      onLogout();
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-red-400 hover:bg-red-500/10 transition-colors text-left cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>{t('nav.logout')}</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={onOpenLogin}
                className="hidden sm:inline-flex px-3 py-1.5 text-xs font-semibold text-slate-200 hover:text-white transition-colors cursor-pointer"
              >
                {t('nav.login')}
              </button>
              <button
                onClick={onOpenRegister}
                className="px-3.5 py-1.5 bg-[#0B61DF] hover:bg-blue-600 text-white text-xs font-bold rounded-lg transition-all shadow-md shadow-blue-600/30 active:scale-95 cursor-pointer whitespace-nowrap"
              >
                {t('nav.register')}
              </button>
            </div>
          )}

          {/* Full Menu Hamburger Button */}
          <button
            onClick={onToggleMenu}
            className="flex items-center justify-center w-9 h-9 rounded-lg bg-slate-900 border border-slate-700 hover:border-slate-600 text-slate-200 hover:text-white transition-colors cursor-pointer"
            title={t('menu.title')}
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
