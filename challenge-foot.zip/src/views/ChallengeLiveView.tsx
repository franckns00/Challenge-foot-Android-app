import React, { useState, useEffect } from 'react';
import { useI18n } from '../i18n';
import {
  Activity,
  Tv,
  Info,
  Clock,
  Sparkles,
  RefreshCw,
  AlertCircle,
  Shield,
  ExternalLink,
  ChevronRight,
  Flame,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import { MatchDetailsModal } from '../components/MatchDetailsModal';

interface ChallengeLiveViewProps {
  onNavigateToChallenge?: () => void;
}

export const ChallengeLiveView: React.FC<ChallengeLiveViewProps> = ({ onNavigateToChallenge }) => {
  const { t } = useI18n();

  const [matches, setMatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshCountdown, setRefreshCountdown] = useState(60);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [dataSource, setDataSource] = useState<string>('database');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'live' | 'upcoming' | 'finished'>('all');

  // Tomorrow preparation state (Requirement: Préparer la sélection du jour suivant automatiquement)
  const [tomorrowMatches, setTomorrowMatches] = useState<any[]>([]);
  const [tomorrowDate, setTomorrowDate] = useState<string>('');
  const [showTomorrow, setShowTomorrow] = useState<boolean>(false);

  // Modal State
  const [activeModalFixtureId, setActiveModalFixtureId] = useState<number | string | null>(null);
  const [modalInitialTab, setModalInitialTab] = useState<'summary' | 'watch' | 'lineups' | 'stats'>('summary');
  const [activeModalMatchInfo, setActiveModalMatchInfo] = useState<any>(null);

  // Fetch strictly the 10 official Challenge matches
  const fetchChallengeLiveMatches = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/football/challenge-live');
      const data = await res.json();
      if (data.success && Array.isArray(data.matches)) {
        // Enforce absolute rule: strictly maximum 10 matches, no 11th match, no external matches
        setMatches(data.matches.slice(0, 10));
        setDataSource(data.source || 'api-sports');
        setLastUpdated(new Date());
      }
    } catch (e) {
      console.error('Failed to fetch challenge live matches:', e);
    } finally {
      setLoading(false);
      setRefreshCountdown(60);
    }
  };

  // Fetch tomorrow's auto-prepared matches
  const fetchTomorrowMatches = async () => {
    try {
      const res = await fetch('/api/football/auto-10/next-day');
      const data = await res.json();
      if (data.success && data.nextDayMatches && Array.isArray(data.nextDayMatches.matches)) {
        setTomorrowMatches(data.nextDayMatches.matches.slice(0, 10));
        setTomorrowDate(data.nextDayMatches.date || '');
      }
    } catch (e) {
      console.error('Failed to fetch next-day matches:', e);
    }
  };

  useEffect(() => {
    fetchChallengeLiveMatches();
    fetchTomorrowMatches();
    const interval = setInterval(() => {
      setRefreshCountdown((prev) => {
        if (prev <= 1) {
          fetchChallengeLiveMatches();
          return 60;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Filter based on the 4 official statuses: À VENIR, EN DIRECT, MI-TEMPS, TERMINÉ
  const filteredMatches = matches.filter((m) => {
    const statusShort = m.status || 'NS';
    const isLive = ['1H', '2H', 'ET', 'LIVE', 'HT'].includes(statusShort);
    const isFinished = ['FT', 'AET', 'PEN'].includes(statusShort);
    const isUpcoming = ['NS', 'TBD'].includes(statusShort) || (!isLive && !isFinished);

    if (selectedFilter === 'live') return isLive;
    if (selectedFilter === 'upcoming') return isUpcoming;
    if (selectedFilter === 'finished') return isFinished;
    return true; // 'all'
  });

  const liveMatchesCount = matches.filter((m) =>
    ['1H', '2H', 'ET', 'LIVE', 'HT'].includes(m.status || '')
  ).length;

  const handleOpenDetails = (match: any, tab: 'summary' | 'watch' = 'summary') => {
    setActiveModalFixtureId(match.id || match.apiFixtureId);
    setActiveModalMatchInfo(match);
    setModalInitialTab(tab);
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-5 sm:py-7 space-y-5 animate-fadeIn">
      {/* ----------------- 1. HEADER BANNER (CHALLENGE LIVE) ----------------- */}
      <div className="rounded-3xl bg-gradient-to-r from-[#071326] via-[#0B254E] to-[#071326] border border-blue-500/30 p-5 sm:p-6 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-7 h-7 rounded-xl bg-red-600/20 text-red-400 border border-red-500/40 flex items-center justify-center font-black text-xs shadow-sm">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping inline-block" />
              </span>
              <span className="text-[11px] font-black uppercase tracking-wider text-red-400 flex items-center gap-1.5">
                <span>CHALLENGE LIVE · DIRECT OFFICIEL</span>
              </span>
              <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                10 Matchs Exclusifs
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Les 10 Matchs du Challenge en Direct
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              Suivi en direct exclusif des 10 matchs officiellement sélectionnés pour le Challenge Foot du jour. Aucun match extérieur n'est ajouté.
            </p>
          </div>

          {/* Sync & Refresh timer */}
          <div className="flex items-center gap-2 text-xs self-start sm:self-auto">
            {lastUpdated && (
              <span className="text-slate-400 font-mono text-[11px] hidden sm:inline">
                Synchro : {lastUpdated.toLocaleTimeString()}
              </span>
            )}
            <button
              onClick={fetchChallengeLiveMatches}
              disabled={loading}
              className="px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border border-slate-700 shadow-sm active:scale-95"
              title="Actualiser les scores des 10 matchs"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-blue-400' : ''}`} />
              <span className="font-mono text-[11px]">{refreshCountdown}s</span>
            </button>
          </div>
        </div>

        {/* Action Link to enter predictions if participant hasn't completed yet */}
        {onNavigateToChallenge && (
          <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <span className="text-slate-300 text-[11px] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              Pronostiquez les 3 catégories (Buteur, 1N2, Score Exact) avant le coup d'envoi.
            </span>
            <button
              onClick={onNavigateToChallenge}
              className="px-3.5 py-1.5 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-black text-xs transition cursor-pointer self-start sm:self-auto shadow-md"
            >
              Accéder à la Grille
            </button>
          </div>
        )}
      </div>

      {/* ----------------- 2. STATUS FILTER PILLS BAR ----------------- */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs select-none">
        <button
          onClick={() => setSelectedFilter('all')}
          className={`px-3.5 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
            selectedFilter === 'all'
              ? 'bg-[#0B61DF] text-white border-blue-400 shadow-md'
              : 'bg-[#091528] text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          Tous les 10 Matchs ({matches.length})
        </button>

        <button
          onClick={() => setSelectedFilter('live')}
          className={`px-3.5 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 border ${
            selectedFilter === 'live'
              ? 'bg-red-600 text-white border-red-400 shadow-md'
              : 'bg-[#091528] text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500" />
          </span>
          <span>En Direct ({liveMatchesCount})</span>
        </button>

        <button
          onClick={() => setSelectedFilter('upcoming')}
          className={`px-3.5 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
            selectedFilter === 'upcoming'
              ? 'bg-[#0B61DF] text-white border-blue-400 shadow-md'
              : 'bg-[#091528] text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          À Venir ({matches.filter((m) => ['NS', 'TBD'].includes(m.status || '')).length})
        </button>

        <button
          onClick={() => setSelectedFilter('finished')}
          className={`px-3.5 py-1.5 rounded-xl font-black transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
            selectedFilter === 'finished'
              ? 'bg-[#0B61DF] text-white border-blue-400 shadow-md'
              : 'bg-[#091528] text-slate-400 border-slate-800 hover:text-white'
          }`}
        >
          Terminés ({matches.filter((m) => ['FT', 'AET', 'PEN'].includes(m.status || '')).length})
        </button>
      </div>

      {/* ----------------- 3. LIST OF THE 10 OFFICIAL CHALLENGE MATCHES ----------------- */}
      <div className="space-y-3">
        {filteredMatches.length > 0 ? (
          filteredMatches.map((m, idx) => {
            const statusShort = m.status || 'NS';
            const isLive = ['1H', '2H', 'ET', 'LIVE'].includes(statusShort);
            const isHT = statusShort === 'HT';
            const isFinished = ['FT', 'AET', 'PEN'].includes(statusShort);
            const isUpcoming = ['NS', 'TBD'].includes(statusShort) || (!isLive && !isHT && !isFinished);

            const displayStatus = isLive
              ? 'EN DIRECT'
              : isHT
              ? 'MI-TEMPS'
              : isFinished
              ? 'TERMINÉ'
              : 'À VENIR';

            const kickoffFormatted = m.kickoffTime
              ? new Date(m.kickoffTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              : '20:00';

            const goalEvents = Array.isArray(m.events) ? m.events.filter((e: any) => e.type === 'Goal') : [];

            return (
              <div
                key={m.id || idx}
                className="rounded-2xl bg-[#091528] border border-slate-800/90 hover:border-slate-700 transition shadow-sm overflow-hidden select-none"
              >
                {/* 1. Card Top Bar: Match Number, League, Kickoff/Status */}
                <div className="flex items-center justify-between px-3.5 py-2 bg-[#060D19] border-b border-slate-800/80 text-[11px]">
                  <div className="flex items-center gap-2 truncate">
                    <span className="font-mono font-black text-amber-400 text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/30">
                      Match #{m.matchNumber || idx + 1}
                    </span>
                    {m.leagueLogo && (
                      <img
                        src={m.leagueLogo}
                        alt=""
                        className="w-4 h-4 object-contain rounded-full bg-slate-900 shrink-0"
                        loading="lazy"
                      />
                    )}
                    <span className="font-bold text-slate-300 truncate uppercase tracking-tight text-[10px]">
                      {m.competition} {m.country ? `· ${m.country}` : ''}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] font-mono text-slate-400 font-bold">
                      {isLive ? `Minute ${m.elapsed || 0}'` : isFinished ? 'Score Final' : `Coup d'envoi ${kickoffFormatted}`}
                    </span>
                  </div>
                </div>

                {/* 2. Main Match Arena: Balanced Home - Score - Away */}
                <div className="p-3 sm:p-4 grid grid-cols-12 items-center gap-2">
                  
                  {/* Home Team (Left - 5 cols) */}
                  <div className="col-span-5 flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-slate-900 border border-slate-800 p-1.5 flex items-center justify-center shrink-0 shadow-sm">
                      {m.homeLogo ? (
                        <img
                          src={m.homeLogo}
                          alt={m.homeTeam}
                          className="w-full h-full object-contain"
                          loading="lazy"
                          onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                        />
                      ) : (
                        <Shield className="w-5 h-5 text-blue-400" />
                      )}
                    </div>
                    <span className="text-xs sm:text-sm font-black text-white truncate text-left">
                      {m.homeTeam}
                    </span>
                  </div>

                  {/* Center: Score & Status (2 cols) */}
                  <div className="col-span-2 flex flex-col items-center justify-center text-center">
                    {/* Status Pill */}
                    <div className="mb-0.5">
                      {isLive ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black bg-red-600/30 text-red-400 border border-red-500/50 animate-pulse">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500 inline-block" />
                          LIVE {m.elapsed ? `${m.elapsed}'` : ''}
                        </span>
                      ) : isHT ? (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          MI-TEMPS
                        </span>
                      ) : isFinished ? (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-slate-800 text-slate-300 border border-slate-700">
                          TERMINÉ
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
                          À VENIR
                        </span>
                      )}
                    </div>

                    {/* Big Score or Time */}
                    <div className="text-base sm:text-2xl font-mono font-black text-white tracking-wider">
                      {m.homeScore !== null && m.homeScore !== undefined ? m.homeScore : '-'}
                      <span className="mx-1 text-slate-500">:</span>
                      {m.awayScore !== null && m.awayScore !== undefined ? m.awayScore : '-'}
                    </div>

                    {isUpcoming && (
                      <span className="text-[10px] text-slate-400 font-mono">
                        {kickoffFormatted}
                      </span>
                    )}
                  </div>

                  {/* Away Team (Right - 5 cols) */}
                  <div className="col-span-5 flex items-center justify-end gap-2.5 min-w-0 text-right">
                    <span className="text-xs sm:text-sm font-black text-white truncate text-right">
                      {m.awayTeam}
                    </span>
                    <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl bg-slate-900 border border-slate-800 p-1.5 flex items-center justify-center shrink-0 shadow-sm">
                      {m.awayLogo ? (
                        <img
                          src={m.awayLogo}
                          alt={m.awayTeam}
                          className="w-full h-full object-contain"
                          loading="lazy"
                          onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                        />
                      ) : (
                        <Shield className="w-5 h-5 text-blue-400" />
                      )}
                    </div>
                  </div>
                </div>

                {/* 3. Goalscorers live strip if any */}
                {goalEvents.length > 0 && (
                  <div className="px-3.5 py-1.5 bg-[#060D19]/70 border-t border-slate-800/80 text-[10px] text-slate-300 flex flex-wrap gap-2.5">
                    {goalEvents.map((g: any, i: number) => (
                      <span key={i} className="flex items-center gap-1">
                        <span>⚽</span>
                        <strong className="text-white">{g.player || 'Buteur'}</strong>
                        <span className="text-slate-400 font-mono">({g.time}')</span>
                      </span>
                    ))}
                  </div>
                )}

                {/* 4. Action Buttons Bar (REGARDER LE MATCH & DÉTAILS DU MATCH) */}
                <div className="px-3.5 py-2.5 bg-[#060D19] border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <span className="text-[10px] text-slate-400 truncate hidden sm:inline">
                    {m.venue || 'Stade Officiel'}
                  </span>

                  <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                    {/* BUTTON 1: REGARDER LE MATCH */}
                    <button
                      onClick={() => handleOpenDetails(m, 'watch')}
                      className="flex-1 sm:flex-none px-3 py-1.5 rounded-xl bg-red-600/90 hover:bg-red-600 text-white font-black text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-sm active:scale-95"
                    >
                      <Tv className="w-3.5 h-3.5" />
                      <span>Regarder le Match</span>
                    </button>

                    {/* BUTTON 2: DÉTAILS DU MATCH */}
                    <button
                      onClick={() => handleOpenDetails(m, 'summary')}
                      className="flex-1 sm:flex-none px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-black text-xs flex items-center justify-center gap-1.5 transition cursor-pointer border border-slate-700 active:scale-95"
                    >
                      <Info className="w-3.5 h-3.5 text-blue-400" />
                      <span>Détails du Match</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        ) : !loading ? (
          <div className="text-center py-16 p-6 rounded-2xl bg-[#091528] border border-slate-800 space-y-2">
            <Clock className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-sm font-bold text-white">Aucun match du Challenge pour ce filtre</p>
            <p className="text-xs text-slate-400">
              Sélectionnez « Tous les 10 Matchs » pour voir la liste complète officielle.
            </p>
          </div>
        ) : (
          <div className="text-center py-16 p-6 rounded-2xl bg-[#091528] border border-slate-800 space-y-2">
            <RefreshCw className="w-8 h-8 text-blue-400 mx-auto animate-spin mb-2" />
            <p className="text-xs text-slate-300">Synchronisation des 10 matchs du Challenge...</p>
          </div>
        )}
      </div>

      {/* ----------------- 4. TOMORROW'S AUTO-PREPARED SCHEDULE ----------------- */}
      {tomorrowMatches.length > 0 && (
        <div className="rounded-2xl bg-[#091528] border border-blue-500/20 overflow-hidden shadow-sm">
          <div
            onClick={() => setShowTomorrow(!showTomorrow)}
            className="px-4 py-3 bg-[#060D19] flex items-center justify-between cursor-pointer hover:bg-slate-900 transition"
          >
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              <div>
                <h3 className="text-xs font-black text-white flex items-center gap-2">
                  <span>Programme de Demain ({tomorrowDate || 'Prochain Round'})</span>
                  <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-[#38BDF8] text-[9px] font-bold">
                    Préparé Automatiquement ({tomorrowMatches.length} Matchs)
                  </span>
                </h3>
                <p className="text-[10px] text-slate-400">
                  La liste officielle du prochain Challenge est déjà prête et sera activée automatiquement.
                </p>
              </div>
            </div>

            <button className="text-xs font-bold text-blue-400 hover:text-blue-300">
              {showTomorrow ? 'Masquer ▲' : 'Afficher ▼'}
            </button>
          </div>

          {showTomorrow && (
            <div className="p-3 divide-y divide-slate-800 space-y-2 animate-fadeIn">
              {tomorrowMatches.map((tm, idx) => (
                <div key={idx} className="pt-2 first:pt-0 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-mono text-[10px] font-bold text-amber-400 shrink-0">
                      #{idx + 1}
                    </span>
                    <span className="text-[11px] font-bold text-slate-300 truncate">
                      {tm.homeTeam} <span className="text-slate-500 font-normal">vs</span> {tm.awayTeam}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] text-slate-400 font-mono">
                      {tm.kickoffTime ? new Date(tm.kickoffTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '20:00'}
                    </span>
                    <span className="text-[10px] text-[#38BDF8] bg-blue-500/10 border border-blue-500/20 px-2 py-0.5 rounded-md font-bold">
                      {tm.competition}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ----------------- 5. INTEGRITY NOTICE ----------------- */}
      <div className="p-3.5 rounded-2xl bg-[#071120] border border-slate-800/80 text-[11px] text-slate-400 flex items-center gap-2">
        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
        <span>
          <strong>Règle d'Intégrité Challenge Foot :</strong> Seuls les 10 matchs officiels sélectionnés quotidiennement sont présentés ici. Les scores et statuts sont certifiés par l'API officielle.
        </span>
      </div>

      {/* ----------------- 5. DETAILED MATCH MODAL (IF OPEN) ----------------- */}
      {activeModalFixtureId && (
        <MatchDetailsModal
          fixtureId={activeModalFixtureId}
          initialMatchInfo={activeModalMatchInfo}
          initialTab={modalInitialTab}
          onClose={() => setActiveModalFixtureId(null)}
          onNavigateToChallenge={onNavigateToChallenge}
        />
      )}
    </div>
  );
};
