import React, { useState, useEffect } from 'react';
import { useI18n } from '../i18n';
import { User, ClubConfig, ClubAnalysisCard } from '../types';
import {
  Crown,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Clock,
  MessageSquare,
  Shield,
  Award,
  Ban,
  Wallet,
  Phone,
  ArrowRight,
  TrendingUp,
  BarChart2,
  RefreshCw,
  X,
  Star,
  Users,
  Info,
  HelpCircle,
} from 'lucide-react';

interface ClubViewProps {
  user: User | null;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onNavigateToChallenges: () => void;
  onNavigateToWallet: () => void;
}

export const ClubView: React.FC<ClubViewProps> = ({
  user,
  onOpenLogin,
  onOpenRegister,
  onNavigateToChallenges,
  onNavigateToWallet,
}) => {
  const { t, language } = useI18n();

  // Status & Subscription State
  const [loading, setLoading] = useState<boolean>(true);
  const [isActive, setIsActive] = useState<boolean>(false);
  const [subscription, setSubscription] = useState<any | null>(null);
  const [daysRemaining, setDaysRemaining] = useState<number>(0);
  const [expiringSoonJ3, setExpiringSoonJ3] = useState<boolean>(false);
  const [expiringSoonJ1, setExpiringSoonJ1] = useState<boolean>(false);
  const [config, setConfig] = useState<ClubConfig | null>(null);

  // Tab State for Active Subscribers
  const [activeTab, setActiveTab] = useState<'fiches' | 'stats' | 'leaderboard' | 'whatsapp'>('fiches');

  // Guarded Content Data
  const [fiches, setFiches] = useState<ClubAnalysisCard[]>([]);
  const [vipStats, setVipStats] = useState<any[]>([]);
  const [clubLeaderboard, setClubLeaderboard] = useState<any | null>(null);
  const [loadingContent, setLoadingContent] = useState<boolean>(false);

  // Modals & Action States
  const [showSubscribeModal, setShowSubscribeModal] = useState<boolean>(false);
  const [selectedMethod, setSelectedMethod] = useState<'wallet' | 'moncash' | 'natcash'>('wallet');
  const [subscribing, setSubscribing] = useState<boolean>(false);
  const [subscribeMessage, setSubscribeMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [showCancelModal, setShowCancelModal] = useState<boolean>(false);
  const [cancelling, setCancelling] = useState<boolean>(false);
  const [whatsappPhone, setWhatsappPhone] = useState<string>(user?.phone || '+509 ');
  const [togglingWhatsapp, setTogglingWhatsapp] = useState<boolean>(false);

  // Load Status
  const fetchClubStatus = () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    fetch(`/api/club/status?userId=${user.id}`)
      .then((r) => r.json())
      .then((res) => {
        if (res.success) {
          setIsActive(res.isActive);
          setSubscription(res.subscription);
          setDaysRemaining(res.daysRemaining || 0);
          setExpiringSoonJ3(res.expiringSoonJ3 || false);
          setExpiringSoonJ1(res.expiringSoonJ1 || false);
          if (res.config) setConfig(res.config);
          if (res.subscription?.userPhone) setWhatsappPhone(res.subscription.userPhone);
        }
      })
      .catch((err) => console.error('Error fetching club status:', err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchClubStatus();
  }, [user]);

  // Load Guarded Content when Subscriber is Active
  useEffect(() => {
    if ((isActive || user?.role === 'admin') && user) {
      setLoadingContent(true);

      Promise.all([
        fetch(`/api/club/premium-analysis?userId=${user.id}`).then((r) => r.json()),
        fetch(`/api/club/vip-stats?userId=${user.id}`).then((r) => r.json()),
        fetch('/api/club/leaderboard').then((r) => r.json()),
      ])
        .then(([fichesRes, statsRes, leadRes]) => {
          if (fichesRes.success && fichesRes.sheets) setFiches(fichesRes.sheets);
          if (statsRes.success && statsRes.stats) setVipStats(statsRes.stats);
          if (leadRes.success) setClubLeaderboard(leadRes);
        })
        .catch((err) => console.error('Error loading club content:', err))
        .finally(() => setLoadingContent(false));
    }
  }, [isActive, user]);

  // Handle Subscribe
  const handleSubscribe = async () => {
    if (!user) {
      setShowSubscribeModal(false);
      onOpenLogin();
      return;
    }

    setSubscribing(true);
    setSubscribeMessage(null);

    try {
      const res = await fetch('/api/club/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          paymentMethod: selectedMethod,
          whatsappAlerts: true,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSubscribeMessage({ type: 'success', text: data.message });
        setIsActive(true);
        setSubscription(data.subscription);
        setDaysRemaining(30);
        setTimeout(() => {
          setShowSubscribeModal(false);
          setSubscribeMessage(null);
          fetchClubStatus();
        }, 1500);
      } else {
        setSubscribeMessage({ type: 'error', text: data.error || 'Erreur lors de la souscription.' });
      }
    } catch (err: any) {
      setSubscribeMessage({ type: 'error', text: err.message || 'Erreur réseau.' });
    } finally {
      setSubscribing(false);
    }
  };

  // Handle Cancel
  const handleCancelSubscription = async () => {
    if (!user) return;
    setCancelling(true);
    try {
      const res = await fetch('/api/club/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          reason: 'Annulation demandée par le membre',
        }),
      });
      const data = await res.json();
      if (data.success) {
        setShowCancelModal(false);
        fetchClubStatus();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setCancelling(false);
    }
  };

  // Handle WhatsApp Toggle
  const handleToggleWhatsApp = async () => {
    if (!user) return;
    setTogglingWhatsapp(true);
    const nextVal = !subscription?.whatsappAlertsEnabled;
    try {
      const res = await fetch('/api/club/toggle-whatsapp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          enabled: nextVal,
          phone: whatsappPhone,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSubscription({ ...subscription, whatsappAlertsEnabled: nextVal });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setTogglingWhatsapp(false);
    }
  };

  const monthlyPrice = config?.monthlyPriceHtg || 130;

  return (
    <div className="min-h-screen bg-[#07101F] text-slate-100 pb-20">
      {/* 1. Header Banner */}
      <div className="relative overflow-hidden bg-gradient-to-b from-[#091C3E] via-[#071328] to-[#07101F] border-b border-blue-500/20">
        <div className="max-w-6xl mx-auto px-4 py-8 sm:py-12">
          {/* Badge & Mode Test notice */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-black tracking-wide">
              <Crown className="w-4 h-4 text-amber-400" />
              <span>CLUB CHALLENGE FOOT · VIP</span>
            </div>

            <div className="px-2.5 py-0.5 rounded-full bg-slate-800 text-[10px] text-slate-300 font-mono border border-slate-700">
              MODE TEST — Aucun argent réel
            </div>
          </div>

          <div className="max-w-3xl space-y-3">
            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight flex items-center gap-3">
              <span>{t('club.title')}</span>
              <span className="text-xs px-2.5 py-1 rounded-xl bg-[#0B61DF] text-white font-mono font-bold tracking-normal">
                $0.99 / mois (~{monthlyPrice} HTG)
              </span>
            </h1>

            <p className="text-sm sm:text-base text-[#38BDF8] font-bold">
              {t('club.tagline')}
            </p>

            {/* Critical Positioning Clarification */}
            <div className="p-3.5 rounded-2xl bg-[#060D19]/80 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
              <Info className="w-4 h-4 text-[#38BDF8] shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong>Positionnement officiel :</strong> {t('club.positioning')}
                <span className="block text-[11px] text-slate-400 mt-1">
                  Les participations quotidiennes (Bronze 100 G, Silver 250 G, Gold 500 G) restent indépendantes.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main Content Container */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        {loading ? (
          <div className="py-20 text-center space-y-3">
            <RefreshCw className="w-8 h-8 text-[#0B61DF] animate-spin mx-auto" />
            <p className="text-xs text-slate-400 font-medium">Chargement des données du Club...</p>
          </div>
        ) : !isActive && user?.role !== 'admin' ? (
          /* ================================================================= */
          /* PAYWALL CLUB CHALLENGE FOOT (FOR NON-SUBSCRIBERS)                */
          /* ================================================================= */
          <div className="space-y-8 animate-fadeIn">
            {/* Offer Overview Card */}
            <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#091A38] to-[#071328] border border-blue-500/30 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

              <div className="max-w-2xl space-y-4">
                <div className="flex items-center gap-2 text-amber-400 text-xs font-black uppercase tracking-wider">
                  <Sparkles className="w-4 h-4" />
                  <span>Abonnement Optionnel · Réservé aux Membres</span>
                </div>

                <h2 className="text-xl sm:text-3xl font-black text-white leading-tight">
                  Prenez une longueur d'avance sur les 10 matchs du jour
                </h2>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Le Club Challenge Foot met entre vos mains les outils analytiques professionnels des pronostiqueurs d'élite : analyses poussées, statistiques de forme, probabilités mathématiques 1X2 et alertes WhatsApp personnalisées.
                </p>

                {/* Price & Guarantee Pill */}
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <div className="px-4 py-2.5 rounded-2xl bg-[#060D19] border border-blue-500/40 flex items-center gap-3">
                    <span className="text-2xl font-black text-white font-mono">{monthlyPrice} HTG</span>
                    <span className="text-[11px] text-slate-400 leading-tight">
                      / 30 jours<br />(soit ~0.99 $)
                    </span>
                  </div>

                  <span className="text-xs text-slate-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Sans engagement récurrent · Renouvellement manuel</span>
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3 pt-3">
                  <button
                    onClick={() => {
                      if (!user) {
                        onOpenLogin();
                      } else {
                        setShowSubscribeModal(true);
                      }
                    }}
                    className="px-6 py-3.5 rounded-2xl bg-[#0B61DF] hover:bg-blue-600 text-white font-black text-sm flex items-center gap-2 shadow-lg shadow-blue-600/30 transition transform active:scale-95 cursor-pointer"
                  >
                    <Crown className="w-4 h-4 text-amber-300" />
                    <span>Rejoindre le Club ({monthlyPrice} HTG)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={onNavigateToChallenges}
                    className="px-5 py-3.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
                  >
                    Continuer sans abonnement
                  </button>
                </div>
              </div>
            </div>

            {/* The 5 Exclusive Advantages Grid */}
            <div className="space-y-4">
              <h3 className="text-sm sm:text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>Les 5 Avantages Exclusifs du Club</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* 1. Statistiques VIP */}
                <div className="p-5 rounded-2xl bg-[#091528] border border-slate-800 hover:border-blue-500/40 transition space-y-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center">
                    <BarChart2 className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-black text-white">{t('club.adv1_name')}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {t('club.adv1_desc')}
                  </p>
                </div>

                {/* 2. Fiches Analyse Premium */}
                <div className="p-5 rounded-2xl bg-[#091528] border border-slate-800 hover:border-blue-500/40 transition space-y-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-black text-white">{t('club.adv2_name')}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {t('club.adv2_desc')}
                  </p>
                </div>

                {/* 3. Alertes WhatsApp */}
                <div className="p-5 rounded-2xl bg-[#091528] border border-slate-800 hover:border-blue-500/40 transition space-y-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-black text-white">{t('club.adv3_name')}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {t('club.adv3_desc')}
                  </p>
                </div>

                {/* 4. Badge VIP + Classement Club */}
                <div className="p-5 rounded-2xl bg-[#091528] border border-slate-800 hover:border-blue-500/40 transition space-y-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center">
                    <Award className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-black text-white">{t('club.adv4_name')}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {t('club.adv4_desc')}
                  </p>
                </div>

                {/* 5. Sans Publicité */}
                <div className="p-5 rounded-2xl bg-[#091528] border border-slate-800 hover:border-blue-500/40 transition space-y-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center">
                    <Ban className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-black text-white">{t('club.adv5_name')}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {t('club.adv5_desc')}
                  </p>
                </div>

                {/* Clear separation Gold vs Club */}
                <div className="p-5 rounded-2xl bg-[#060D19] border border-slate-800/80 space-y-2 flex flex-col justify-center">
                  <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5" />
                    <span>Rappel Réglementaire</span>
                  </span>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Les avantages <strong>Gold</strong> (matchs 24h à l'avance, retraits prioritaires) restent strictement réservés aux participants de la catégorie Gold. L'abonnement Club est cumulable et indépendant.
                  </p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* ================================================================= */
          /* SUBSCRIBER PORTAL (ACTIVE VIP MEMBERS)                            */
          /* ================================================================= */
          <div className="space-y-6 animate-fadeIn">
            {/* Subscriber Status Bar */}
            <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-[#091C3E] to-[#071328] border border-blue-500/30 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                  <Crown className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-white">Membre VIP Club Challenge Foot</h3>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold">
                      {subscription?.status === 'annulé' ? 'Résilié (accès maintenu)' : 'Actif'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    {daysRemaining > 0 ? `${daysRemaining} jour(s) d'accès restant(s)` : 'Accès vérifié'} · Renouvellement manuel
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowSubscribeModal(true)}
                  className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition cursor-pointer shadow"
                >
                  {t('club.btn_renew')}
                </button>

                <button
                  onClick={() => setShowCancelModal(true)}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white font-bold text-xs transition cursor-pointer"
                >
                  Résilier
                </button>
              </div>
            </div>

            {/* Reminder Alerts (J-3 or J-1) */}
            {expiringSoonJ1 ? (
              <div className="p-3.5 rounded-2xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-center gap-2.5">
                <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
                <span>{t('club.reminder_j1')}</span>
              </div>
            ) : expiringSoonJ3 ? (
              <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs flex items-center gap-2.5">
                <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
                <span>{t('club.reminder_j3')}</span>
              </div>
            ) : null}

            {/* Sub-Tabs: Fiches, Stats VIP, Classement Club, WhatsApp */}
            <div className="grid grid-cols-2 sm:grid-cols-4 p-1.5 rounded-2xl bg-[#060D19] border border-slate-800 gap-1.5">
              <button
                onClick={() => setActiveTab('fiches')}
                className={`py-2.5 px-3 rounded-xl font-black text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                  activeTab === 'fiches' ? 'bg-[#0B61DF] text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Fiches Analyse (10)</span>
              </button>

              <button
                onClick={() => setActiveTab('stats')}
                className={`py-2.5 px-3 rounded-xl font-black text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                  activeTab === 'stats' ? 'bg-[#0B61DF] text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <BarChart2 className="w-4 h-4 text-blue-300" />
                <span>Statistiques VIP</span>
              </button>

              <button
                onClick={() => setActiveTab('leaderboard')}
                className={`py-2.5 px-3 rounded-xl font-black text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                  activeTab === 'leaderboard' ? 'bg-[#0B61DF] text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Award className="w-4 h-4 text-purple-300" />
                <span>Classement Club</span>
              </button>

              <button
                onClick={() => setActiveTab('whatsapp')}
                className={`py-2.5 px-3 rounded-xl font-black text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                  activeTab === 'whatsapp' ? 'bg-[#0B61DF] text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-emerald-300" />
                <span>Alertes WhatsApp</span>
              </button>
            </div>

            {/* TAB 1: FICHES ANALYSE PREMIUM */}
            {activeTab === 'fiches' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Fiches Analyse des 10 Matchs du Jour</span>
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">10 fiches certifiées</span>
                </div>

                {loadingContent ? (
                  <div className="py-16 text-center text-xs text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto text-blue-400 mb-2" />
                    Génération des fiches analytiques poussées...
                  </div>
                ) : fiches.length === 0 ? (
                  <p className="text-xs text-slate-400 py-8 text-center">Aucune fiche disponible pour l'instant.</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {fiches.map((f, idx) => (
                      <div
                        key={f.matchId || idx}
                        className="rounded-2xl bg-[#091528] border border-slate-800 hover:border-slate-700 transition p-4 sm:p-5 space-y-3"
                      >
                        {/* Match Header */}
                        <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                          <span className="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 text-[10px] font-mono font-bold">
                            Match #{f.matchNumber} · {f.competition}
                          </span>
                          <span className="text-[11px] font-mono text-emerald-400 font-bold">
                            {f.time || 'Aujourd\'hui'}
                          </span>
                        </div>

                        {/* Teams Duel */}
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2 min-w-0">
                            {f.homeLogo && <img src={f.homeLogo} alt="" className="w-6 h-6 object-contain" />}
                            <span className="text-xs font-black text-white truncate">{f.homeTeam}</span>
                          </div>
                          <span className="text-xs font-black text-slate-500">vs</span>
                          <div className="flex items-center gap-2 min-w-0 justify-end">
                            <span className="text-xs font-black text-white truncate">{f.awayTeam}</span>
                            {f.awayLogo && <img src={f.awayLogo} alt="" className="w-6 h-6 object-contain" />}
                          </div>
                        </div>

                        {/* Tactical Key */}
                        <div className="p-3 rounded-xl bg-[#060D19] border border-slate-800/80 text-xs text-slate-300 space-y-1">
                          <strong className="text-blue-400 text-[11px] block">Clé tactique du match :</strong>
                          <p className="text-[11px] leading-relaxed">{f.tacticalKey}</p>
                        </div>

                        {/* Data Predictions Recommendation */}
                        <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
                          <div className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
                            <span className="text-[10px] text-emerald-400 font-bold block">Score Probable Data :</span>
                            <span className="text-sm font-black text-white font-mono">{f.probableScore}</span>
                          </div>

                          <div className="p-2.5 rounded-xl bg-blue-950/20 border border-blue-500/30">
                            <span className="text-[10px] text-blue-400 font-bold block">Indice de Confiance :</span>
                            <div className="flex items-center gap-1 mt-0.5">
                              {Array.from({ length: 5 }).map((_, sIdx) => (
                                <Star
                                  key={sIdx}
                                  className={`w-3.5 h-3.5 ${
                                    sIdx < f.confidenceStars ? 'text-amber-400 fill-amber-400' : 'text-slate-700'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: STATISTIQUES VIP */}
            {activeTab === 'stats' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <BarChart2 className="w-4 h-4 text-blue-400" />
                    <span>Statistiques VIP & Modèles Mathématiques 1X2</span>
                  </h3>
                </div>

                <div className="space-y-3">
                  {vipStats.map((st, sIdx) => (
                    <div
                      key={st.matchId || sIdx}
                      className="p-4 rounded-2xl bg-[#091528] border border-slate-800 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-white">
                          Match #{st.matchNumber} · {st.homeTeam} vs {st.awayTeam}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono uppercase">{st.competition}</span>
                      </div>

                      {/* 1X2 Model Probabilities Bar */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-[11px] font-mono">
                          <span className="text-blue-400">1 ({st.homeTeam}) : {st.probabilities1X2?.homeWin}%</span>
                          <span className="text-slate-300">Nul (X) : {st.probabilities1X2?.draw}%</span>
                          <span className="text-emerald-400">2 ({st.awayTeam}) : {st.probabilities1X2?.awayWin}%</span>
                        </div>
                        <div className="w-full h-3 rounded-full bg-slate-900 overflow-hidden flex">
                          <div style={{ width: `${st.probabilities1X2?.homeWin}%` }} className="bg-blue-600 h-full" />
                          <div style={{ width: `${st.probabilities1X2?.draw}%` }} className="bg-amber-400 h-full" />
                          <div style={{ width: `${st.probabilities1X2?.awayWin}%` }} className="bg-emerald-500 h-full" />
                        </div>
                      </div>

                      {/* H2H & Scorers */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-800/80 text-xs">
                        <div className="p-2 rounded-xl bg-[#060D19] border border-slate-800 text-[11px] text-slate-300">
                          <strong className="text-slate-400 block mb-1">Historique H2H :</strong>
                          <span>{st.h2hSummary}</span>
                        </div>

                        <div className="p-2 rounded-xl bg-[#060D19] border border-slate-800 text-[11px] text-slate-300">
                          <strong className="text-slate-400 block mb-1">Tendance Buteurs :</strong>
                          {st.goalscorerTrends?.map((gt: any, gIdx: number) => (
                            <span key={gIdx} className="block truncate">
                              • {gt.name} ({gt.team}) — prob. {gt.probability}%
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: CLASSEMENT MENSUEL CLUB */}
            {activeTab === 'leaderboard' && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-[#091528] border border-purple-500/30 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-black text-white flex items-center gap-2">
                      <Award className="w-4 h-4 text-purple-400" />
                      <span>Classement Mensuel Parallèle · Club Challenge Foot</span>
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Réservé exclusivement aux abonnés du Club. Récompenses exclusives à la fin de chaque mois.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-mono">
                    <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                      1er : 2 500 HTG
                    </span>
                    <span className="px-2.5 py-1 rounded-lg bg-slate-400/20 text-slate-300 border border-slate-400/30 font-bold">
                      2e : 1 500 HTG
                    </span>
                    <span className="px-2.5 py-1 rounded-lg bg-amber-700/20 text-amber-400 border border-amber-700/30 font-bold">
                      3e : 1 000 HTG
                    </span>
                  </div>
                </div>

                {/* Leaderboard Table */}
                <div className="rounded-2xl bg-[#091528] border border-slate-800 overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 bg-[#060D19] text-[10px] font-black uppercase text-slate-400">
                        <th className="p-3">Rang</th>
                        <th className="p-3">Membre VIP</th>
                        <th className="p-3 text-center">Scores Exacts</th>
                        <th className="p-3 text-center">Points</th>
                        <th className="p-3 text-right">Prize Estimé</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {(clubLeaderboard?.leaderboard || []).map((mb: any) => (
                        <tr key={mb.userId} className="hover:bg-slate-800/30 transition">
                          <td className="p-3 font-mono font-black text-amber-400">
                            #{mb.rank}
                          </td>
                          <td className="p-3 font-bold text-white flex items-center gap-2">
                            <span>{mb.userName}</span>
                            <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[9px] font-black">
                              VIP Club
                            </span>
                          </td>
                          <td className="p-3 text-center font-mono text-slate-300">
                            {mb.exactScores}
                          </td>
                          <td className="p-3 text-center font-mono font-black text-emerald-400">
                            {mb.points} pts
                          </td>
                          <td className="p-3 text-right font-mono font-bold text-amber-300">
                            {mb.prizeHtg > 0 ? `${mb.prizeHtg} HTG` : '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB 4: ALERTES WHATSAPP */}
            {activeTab === 'whatsapp' && (
              <div className="p-6 rounded-3xl bg-[#091528] border border-slate-800 space-y-6">
                <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white">Alertes WhatsApp Exclusives</h3>
                    <p className="text-xs text-slate-400">
                      Rappels automatiques 2h avant la clôture des pronostics, résultats de vos matchs et classements
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[#060D19] border border-slate-800 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <span className="text-xs font-bold text-white block">Statut des alertes WhatsApp :</span>
                      <span className="text-[11px] text-slate-400">
                        {subscription?.whatsappAlertsEnabled ? 'Actif sur votre ligne' : 'Désactivé'}
                      </span>
                    </div>

                    <button
                      onClick={handleToggleWhatsApp}
                      disabled={togglingWhatsapp}
                      className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
                        subscription?.whatsappAlertsEnabled
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      }`}
                    >
                      {togglingWhatsapp && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                      <span>
                        {subscription?.whatsappAlertsEnabled ? 'Alertes Activées' : 'Activer les Alertes'}
                      </span>
                    </button>
                  </div>

                  <div className="pt-3 border-t border-slate-800 flex items-center gap-2">
                    <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      value={whatsappPhone}
                      onChange={(e) => setWhatsappPhone(e.target.value)}
                      placeholder="+509 3700 0000"
                      className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono w-48 focus:outline-none focus:border-emerald-500"
                    />
                    <span className="text-[10px] text-slate-400">Numéro WhatsApp certifié</span>
                  </div>
                </div>

                {/* Queue & Provider Technical Notice (for Naobert) */}
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 space-y-1.5">
                  <strong className="text-slate-300 block">Implémentation technique WhatsApp :</strong>
                  <p>
                    File d'envoi asynchrone compatible Meta Cloud API / Twilio WhatsApp. En mode test, les messages sont simulés et tracés dans le journal d'accès pour vérification immédiate.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 3. Subscribe / Renew Modal */}
      {showSubscribeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-md bg-[#071326] border border-blue-500/40 rounded-3xl p-6 space-y-5 shadow-2xl relative">
            <button
              onClick={() => {
                setShowSubscribeModal(false);
                setSubscribeMessage(null);
              }}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                <Crown className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">Souscription Club Challenge Foot</h3>
                <p className="text-xs text-slate-400">30 jours d'accès complet · Renouvelable manuellement</p>
              </div>
            </div>

            {/* Test Mode Notice */}
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs">
              <strong>MODE TEST :</strong> Aucun argent réel. Le montant de {monthlyPrice} HTG sera déduit de votre portefeuille test.
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 block">Moyen de paiement :</label>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedMethod('wallet')}
                  className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-start gap-1 cursor-pointer transition ${
                    selectedMethod === 'wallet'
                      ? 'bg-blue-600/20 border-blue-500 text-white shadow'
                      : 'bg-[#060D19] border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-blue-400 font-bold">
                    <Wallet className="w-3.5 h-3.5" />
                    <span>Wallet ({user?.balance?.toLocaleString() || 0} G)</span>
                  </div>
                  <span className="text-[10px] text-slate-400">Déduction automatique</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedMethod('moncash')}
                  className={`p-3 rounded-xl border text-xs font-bold flex flex-col items-start gap-1 cursor-pointer transition ${
                    selectedMethod === 'moncash'
                      ? 'bg-red-600/20 border-red-500 text-white shadow'
                      : 'bg-[#060D19] border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-red-400 font-bold">
                    <Phone className="w-3.5 h-3.5" />
                    <span>MonCash / NatCash</span>
                  </div>
                  <span className="text-[10px] text-slate-400">Validation manuelle</span>
                </button>
              </div>
            </div>

            {subscribeMessage && (
              <div
                className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                  subscribeMessage.type === 'success'
                    ? 'bg-emerald-950/40 border border-emerald-500/40 text-emerald-300'
                    : 'bg-red-950/40 border border-red-500/40 text-red-300'
                }`}
              >
                {subscribeMessage.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                )}
                <span>{subscribeMessage.text}</span>
              </div>
            )}

            <button
              onClick={handleSubscribe}
              disabled={subscribing}
              className="w-full py-3 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-black text-xs transition cursor-pointer flex items-center justify-center gap-2 shadow-lg"
            >
              {subscribing && <RefreshCw className="w-4 h-4 animate-spin" />}
              <span>Confirmer l'abonnement ({monthlyPrice} HTG)</span>
            </button>
          </div>
        </div>
      )}

      {/* 4. Cancel Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="w-full max-w-md bg-[#071326] border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-black text-white">Résilier l'abonnement Club ?</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              La résiliation est <strong>libre et sans frais</strong>. Conformément aux conditions :
            </p>
            <ul className="text-xs text-slate-400 space-y-1 list-disc list-inside">
              <li>Aucun remboursement n'est effectué après activation.</li>
              <li>Vous conservez votre accès complet aux avantages jusqu'à la fin de vos 30 jours déjà payés.</li>
              <li>Aucun renouvellement ne sera effectué.</li>
            </ul>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleCancelSubscription}
                disabled={cancelling}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs cursor-pointer transition"
              >
                {cancelling ? 'Résiliation en cours...' : 'Confirmer la résiliation'}
              </button>
              <button
                onClick={() => setShowCancelModal(false)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs cursor-pointer hover:bg-slate-700"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
