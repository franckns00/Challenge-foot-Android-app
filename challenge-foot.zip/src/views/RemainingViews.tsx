import React, { useState } from 'react';
import { useI18n } from '../i18n';
import { User, Match, PredictionSubmission, Challenge, Transaction } from '../types';
import { Logo } from '../components/Logo';
import {
  UserCheck,
  ShieldCheck,
  Lock,
  Download,
  Trash2,
  Calendar,
  CheckCircle2,
  Award,
  BookOpen,
  Info,
  Settings,
  Handshake,
  Mail,
  Send,
  HelpCircle,
  Clock,
  Sparkles,
} from 'lucide-react';

import { BeSoccerMatchRow } from '../components/BeSoccerMatchRow';

/* ----------------- 1. MATCHES VIEW (STYLE BESOCCER) ----------------- */
export const MatchesView: React.FC<{ matches: Match[] }> = ({ matches }) => {
  const { t } = useI18n();

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-6 sm:py-8 space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <span>{t('menu.matches')}</span>
          <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
            Style BeSoccer
          </span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1">
          Calendrier officiel des 10 rencontres du Challenge avec alignement strict des équipes, logos et statuts.
        </p>
      </div>

      <div className="space-y-3">
        {matches.map((m, idx) => (
          <BeSoccerMatchRow
            key={m.id}
            id={m.id}
            homeTeam={m.homeTeam}
            homeLogo={m.homeLogo}
            homeScore={m.homeScore}
            awayTeam={m.awayTeam}
            awayLogo={m.awayLogo}
            awayScore={m.awayScore}
            competition={m.competition}
            status={m.status === 'finished' ? 'FT' : m.status === 'live' ? 'LIVE' : 'NS'}
            kickoffTime={m.kickOffTime}
            venue={m.venue}
            isChallengeMatch={true}
            matchNumber={m.matchNumber || idx + 1}
          />
        ))}
      </div>
    </div>
  );
};

/* ----------------- 2. MY PREDICTIONS VIEW ----------------- */
export const MyPredictionsView: React.FC<{
  user: User | null;
  challenge: Challenge;
  predictions: PredictionSubmission[];
  onOpenLogin: () => void;
  onNavigateToChallenges: () => void;
}> = ({ user, challenge, predictions, onOpenLogin, onNavigateToChallenges }) => {
  const { t } = useI18n();

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-xl font-bold text-white">Connexion Requise</h2>
        <p className="text-xs text-slate-400">
          Connectez-vous pour consulter vos grilles de pronostics soumises et vos points.
        </p>
        <button onClick={onOpenLogin} className="px-6 py-2.5 rounded-xl bg-[#0B61DF] text-white font-bold text-xs cursor-pointer">
          Se connecter
        </button>
      </div>
    );
  }

  // Find user's submissions or build active scorecard
  const userSubmissions = predictions.filter((p) => p.userId === user.id);

  // Demo participant metrics for current user (Jean-Baptiste Sony: 1st rank, 115 points)
  const isDemoWinner = user.role === 'admin' || user.id === 'u-player-1';
  const demoRank = isDemoWinner ? 1 : 14;
  const demoPoints = isDemoWinner ? 115 : 68;
  const demoExact = isDemoWinner ? 7 : 3;
  const demoCorrect = isDemoWinner ? 2 : 4;
  const demoMissed = isDemoWinner ? 1 : 3;
  const demoBonus = isDemoWinner ? 30 : 15;
  const demoPrize = isDemoWinner ? 2400 : 0;
  const isTop5 = demoRank <= 5;

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-6 sm:py-8 space-y-6">
      <div className="pb-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t('nav.my_predictions')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Tableau de bord de vos performances, points calculés et statut de récompense.
          </p>
        </div>
        <button
          onClick={onNavigateToChallenges}
          className="px-4 py-2 bg-[#0B61DF] hover:bg-blue-600 text-white rounded-xl text-xs font-bold transition-all cursor-pointer self-start sm:self-auto"
        >
          Nouveau Pronostic
        </button>
      </div>

      {/* PERSONAL PARTICIPANT SCORECARD CARD */}
      <div className="rounded-3xl bg-gradient-to-br from-[#0D1C34] via-[#07101F] to-[#0D1C34] border border-blue-500/40 p-5 sm:p-7 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-500/20 text-[#38BDF8] border border-blue-500/40 flex items-center justify-center font-bold text-lg">
              {user.fullName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-white">{user.fullName}</h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
                  #BR-001
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Catégorie : <strong className="text-amber-400 uppercase">Bronze (100 HTG)</strong> · Semèn #42
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right">
            <span className="text-xs text-slate-400">Classement Officiel :</span>
            <div className="flex items-baseline gap-1 sm:justify-end">
              <span className="text-2xl font-black text-white font-mono">#{demoRank}</span>
              <span className="text-xs text-slate-500">/ 100 patisipan</span>
            </div>
          </div>
        </div>

        {/* 4 Stats Chips */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <span className="text-slate-400">Total Pwen :</span>
            <p className="text-xl font-black text-white font-mono">{demoPoints} pts</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <span className="text-slate-400">Nòt Egzak (10pts) :</span>
            <p className="text-xl font-black text-emerald-400 font-mono">{demoExact}</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <span className="text-slate-400">Prediksyon Rate :</span>
            <p className="text-xl font-black text-slate-500 font-mono">{demoMissed}</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <span className="text-slate-400">Bonus Bitè (+5pts) :</span>
            <p className="text-xl font-black text-amber-300 font-mono">+{demoBonus} pts</p>
          </div>
        </div>

        {/* PRIZE OR NOT IN TOP 5 NOTICE */}
        {isTop5 ? (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-yellow-500/20 via-amber-500/20 to-yellow-500/20 border border-yellow-500/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <span className="text-2xl">🥇</span>
              <div>
                <p className="font-extrabold text-white text-sm">
                  Felisitasyon ! Ou klase nan 5 premye gayan yo (1ye Plas)
                </p>
                <p className="text-amber-200 text-[11px]">
                  Pri lajan kach : <strong className="text-white font-mono text-sm">{demoPrize.toLocaleString()} HTG</strong> (40% fon gayan yo)
                </p>
              </div>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold uppercase text-[10px]">
              Estati : Apwouve (Mode Test)
            </span>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-3 text-xs text-slate-300">
            <Info className="w-5 h-5 text-slate-400 shrink-0" />
            <p>
              <strong>{t('participants.not_in_top5_notice')}</strong> Bon kouraj pou pwochen chalanje a ! Pwen ou yo ak analiz ou yo byen anrejistre.
            </p>
          </div>
        )}
      </div>

      {/* Grid of Picks */}
      {userSubmissions.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-base font-bold text-white">Détail des 10 Pronostics Soumis</h3>
          {userSubmissions.map((sub) => (
            <div key={sub.id} className="rounded-2xl bg-[#0D1C34] border border-slate-800 p-5 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
                <span className="font-bold text-white uppercase">{challenge.title}</span>
                <span className="text-slate-400 font-mono text-[11px]">{new Date(sub.submittedAt).toLocaleString()}</span>
              </div>

              <div className="divide-y divide-slate-800 text-xs">
                {sub.picks.map((pick, idx) => {
                  const match = challenge.matches.find((m) => m.id === pick.matchId);
                  return (
                    <div key={idx} className="py-2 flex items-center justify-between">
                      <span className="font-semibold text-white">
                        #{idx + 1} {match ? `${match.homeTeam} vs ${match.awayTeam}` : 'Match'}
                      </span>
                      <span className="font-mono font-bold text-emerald-400 bg-slate-900 px-2 py-0.5 rounded">
                        {pick.homeScore} - {pick.awayScore} ({pick.outcome1x2})
                      </span>
                      <span className="text-slate-300 text-right">
                        Buteur : <strong className="text-[#38BDF8]">{pick.goalscorerName}</strong>
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/* ----------------- 3. REWARDS VIEW ----------------- */
export const RewardsView: React.FC = () => {
  const { t } = useI18n();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {t('rewards.title')}
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1">
          Barème officiel de redistribution des prix et conditions d'attribution transparentes.
        </p>
      </div>

      <div className="rounded-2xl bg-[#0D1C34] border border-blue-500/30 p-6 space-y-4">
        <h3 className="text-base font-bold text-white">
          {t('rewards.prize_distribution')}
        </h3>
        <div className="space-y-2 text-xs text-slate-200">
          <div className="flex justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span className="font-bold text-yellow-400">1ère Place (Vainqueur)</span>
            <span className="font-mono font-bold text-white">40% du pool</span>
          </div>
          <div className="flex justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span className="font-bold text-slate-300">2ème Place</span>
            <span className="font-mono font-bold text-white">25% du pool</span>
          </div>
          <div className="flex justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span className="font-bold text-amber-500">3ème Place</span>
            <span className="font-mono font-bold text-white">15% du pool</span>
          </div>
          <div className="flex justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span>4ème Place</span>
            <span className="font-mono font-bold text-white">12% du pool</span>
          </div>
          <div className="flex justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span>5ème Place</span>
            <span className="font-mono font-bold text-white">8% du pool</span>
          </div>
        </div>

        <p className="text-xs text-[#38BDF8] pt-2">
          {t('rewards.gold_jackpot_extra')}
        </p>
      </div>
    </div>
  );
};

/* ----------------- 4. PERSONAL DATA (PROFILE) ----------------- */
export const ProfileView: React.FC<{ user: User | null; onOpenLogin: () => void; onLogout: () => void }> = ({
  user,
  onOpenLogin,
  onLogout,
}) => {
  const { t } = useI18n();

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-xl font-bold text-white">Connexion Requise</h2>
        <p className="text-xs text-slate-400">Connectez-vous pour voir vos informations personnelles.</p>
        <button onClick={onOpenLogin} className="px-6 py-2.5 rounded-xl bg-[#0B61DF] text-white font-bold text-xs cursor-pointer">
          Se connecter
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {t('profile.title')}
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Gestion de votre compte, statut de vérification et sécurité des données.
        </p>
      </div>

      <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 p-6 space-y-4 text-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <span className="text-slate-400">Nom complet :</span>
          <span className="font-bold text-white">{user.fullName}</span>
        </div>
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <span className="text-slate-400">Catégorie / Niveau :</span>
          <span className="font-bold uppercase px-2.5 py-0.5 rounded bg-yellow-500/20 text-yellow-300 border border-yellow-500/40">
            {user.role === 'admin' ? 'ADMINISTRATEUR (GOLD)' : 'JOUEUR OFFICIEL'}
          </span>
        </div>
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <span className="text-slate-400">Numéro de téléphone :</span>
          <span className="font-mono font-bold text-white flex items-center gap-2">
            <span>{user.phone}</span>
            {user.isPhoneVerified && (
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
                {t('auth.phone_verified')}
              </span>
            )}
          </span>
        </div>
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <span className="text-slate-400">Adresse e-mail :</span>
          <span className="font-mono text-white">{user.email}</span>
        </div>
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <span className="text-slate-400">Solde disponible :</span>
          <span className="font-mono text-emerald-400 font-black text-sm">{user.balance.toLocaleString()} HTG</span>
        </div>
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <span className="text-slate-400">{t('profile.account_status')}</span>
          <span className="text-emerald-400 font-bold uppercase">Actif (Mode Test Sécurisé)</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-slate-400">{t('profile.created_at')}</span>
          <span className="text-slate-300 font-mono">{new Date(user.createdAt).toLocaleDateString()}</span>
        </div>
      </div>

      {/* SECTION 9BIS.B : GESTION DU CONSENTEMENT DE LOCALISATION GPS */}
      <div className="rounded-2xl bg-[#0D1C34] border border-blue-500/30 p-6 space-y-4 text-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-[#38BDF8] flex items-center justify-center font-bold">
              📍
            </span>
            <h3 className="text-sm font-bold text-white">Localisation & Vie Privée (Consentement Éclairé)</h3>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
            Désactivé par défaut
          </span>
        </div>

        <p className="text-slate-300 leading-relaxed text-[11px]">
          Challenge Foot respecte strictement votre vie privée. La localisation GPS n'est collectée qu'avec votre accord explicite, exclusivement pour la prévention des fraudes multi-comptes et la conformité territoriale en Haïti. Rétention de <strong>12 mois glissants</strong> avec effacement automatique quotidien. Vous pouvez révoquer ce consentement à tout instant : la collecte s'arrête immédiatement et toutes vos données GPS sont purgées. Aucun suivi en arrière-plan.
        </p>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div>
            <span className="font-bold text-white block">Autoriser la localisation précise</span>
            <span className="text-[10px] text-slate-400">
              Statut actuel : {user.gpsConsent ? 'Activé (Opt-in actif)' : 'Non activé (Protection maximale)'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (navigator.geolocation) {
                  navigator.geolocation.getCurrentPosition(
                    (pos) => {
                      fetch('/api/auth/gps-consent', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          userId: user.id,
                          enabled: true,
                          coords: { lat: pos.coords.latitude, lng: pos.coords.longitude },
                        }),
                      })
                        .then(() => alert('Consentement GPS enregistré pour 12 mois glissants avec horodatage dans le registre d\'audit.'))
                        .catch(() => alert('Consentement enregistré localement.'));
                    },
                    () => {
                      alert('Accès GPS refusé sur l\'appareil. Aucune coordonnée n\'a été collectée.');
                    }
                  );
                } else {
                  alert('La géolocalisation n\'est pas supportée sur ce navigateur.');
                }
              }}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[11px] cursor-pointer"
            >
              Donner mon Consentement
            </button>
            <button
              onClick={() => {
                fetch('/api/auth/gps-consent', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ userId: user.id, enabled: false }),
                })
                  .then(() => alert('Consentement GPS révoqué avec succès. Toutes coordonnées précises ont été purgées.'))
                  .catch(() => alert('Consentement révoqué.'));
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-[11px] cursor-pointer"
            >
              Révoquer
            </button>
          </div>
        </div>
      </div>

      <div className="pt-2 flex flex-wrap gap-3">
        <button
          onClick={() => {
            const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(user, null, 2));
            const dlAnchor = document.createElement('a');
            dlAnchor.setAttribute('href', dataStr);
            dlAnchor.setAttribute('download', `ChallengeFoot_UserData_${user.id}.json`);
            dlAnchor.click();
          }}
          className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-semibold text-slate-200 hover:text-white transition-colors cursor-pointer"
        >
          {t('profile.export_data')}
        </button>
        <button
          onClick={onLogout}
          className="px-4 py-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-xs font-semibold text-red-400 hover:bg-red-500/20 transition-colors cursor-pointer"
        >
          {t('nav.logout')}
        </button>
      </div>
    </div>
  );
};

/* ----------------- 5. PARTNERSHIP VIEW ----------------- */
export const PartnershipView: React.FC = () => {
  const { t } = useI18n();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', type: 'Sponsor', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {t('partnership.title')}
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1">
          {t('partnership.desc')}
        </p>
      </div>

      {submitted ? (
        <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs text-center space-y-2">
          <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
          <p className="text-sm font-bold text-white">Proposition envoyée avec succès !</p>
          <p>L'équipe administrative de Challenge Foot prendra contact avec vous rapidement.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="rounded-2xl bg-[#0D1C34] border border-slate-800 p-6 space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-300 mb-1">{t('partnership.form_name')}</label>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-blue-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block font-semibold text-slate-300 mb-1">{t('partnership.form_email')}</label>
            <input
              type="email"
              required
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-blue-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block font-semibold text-slate-300 mb-1">{t('partnership.form_type')}</label>
            <select
              value={form.type}
              onChange={(e) => setForm({ ...form, type: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-blue-500 focus:outline-none"
            >
              <option value="Sponsor">Sponsor / Marque commerciale</option>
              <option value="Medya">Média sportif / Radio / Télévision</option>
              <option value="Kreyatè">Créateur de contenu / Influenceur</option>
              <option value="Kominote">Communauté de supporters</option>
            </select>
          </div>
          <div>
            <label className="block font-semibold text-slate-300 mb-1">{t('partnership.form_message')}</label>
            <textarea
              rows={4}
              required
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-blue-500 focus:outline-none"
            />
          </div>
          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold transition-all shadow-md cursor-pointer"
          >
            {t('partnership.submit_btn')}
          </button>
        </form>
      )}
    </div>
  );
};

/* ----------------- 6. RULES & ABOUT & SETTINGS ----------------- */
export const RulesView: React.FC = () => {
  const { t } = useI18n();

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 text-xs text-slate-300 leading-relaxed">
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {t('rules.title')}
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          {t('rules.legal_disclaimer')}
        </p>
      </div>

      <div className="space-y-4 rounded-2xl bg-[#0D1C34] border border-slate-800 p-6">
        <h3 className="text-base font-bold text-white">1. Nature du Concours</h3>
        <p>
          Challenge Foot est un <strong>concours de pronostics basé à 100% sur la compétence</strong> et l'expertise analytique des joueurs (Skill Contest). Ce n'est ni une loterie, ni un jeu de hasard, ni un bookmaker de paris sportifs. Aucun gain n'est attribué par tirage au sort.
        </p>

        <h3 className="text-base font-bold text-white">2. Attribution des Points</h3>
        <ul className="list-disc pl-5 space-y-1">
          <li><strong>Score exact :</strong> 10 points.</li>
          <li><strong>Bon résultat 1X2 :</strong> 3 points (non cumulable avec le score exact).</li>
          <li><strong>Buteur correct :</strong> +5 points (cumulable).</li>
          <li><strong>Maximum théorique :</strong> 15 points par match, soit 150 points pour 10 matchs.</li>
        </ul>

        <h3 className="text-base font-bold text-white">3. Départages en cas d'Égalité</h3>
        <p>
          En cas d'égalité au classement : 1) Nombre de scores exacts trouvés, 2) Nombre de buteurs exacts, 3) Proximité du total cumulé de buts, 4) Date et heure de soumission la plus ancienne.
        </p>

        <h3 className="text-base font-bold text-white">4. Clôture des Pronostics</h3>
        <p>
          La clôture intervient strictement 1 heure avant le coup d'envoi du tout premier match de la grille hebdomadaire.
        </p>
      </div>
    </div>
  );
};

export const AboutView: React.FC<{ onOpenDownload: () => void }> = ({ onOpenDownload }) => {
  const { t } = useI18n();

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 text-xs text-slate-300">
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {t('about.title')}
        </h1>
        <p className="text-xs text-slate-400 mt-1">{t('about.version')}</p>
      </div>

      <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 p-6 space-y-4">
        <Logo size="lg" />
        <p className="text-sm font-semibold text-white">« {t('app.tagline')} »</p>
        <p className="leading-relaxed">
          {t('about.mission')}
        </p>
        <p className="leading-relaxed">
          Plateforme mobile-first développée avec une architecture haute performance, supportant l'intégration des services de paiement MonCash et NatCash sous contrôle strict du mode test.
        </p>
        <div className="pt-2">
          <button onClick={onOpenDownload} className="px-5 py-2.5 rounded-xl bg-[#0B61DF] text-white font-bold cursor-pointer">
            {t('ad.btn_download')} (APK)
          </button>
        </div>
      </div>
    </div>
  );
};

export const SettingsView: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {
  const { t, language, setLanguage, languages } = useI18n();

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      <div className="pb-4 border-b border-slate-800">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          {t('settings.title')}
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Configuration des préférences linguistiques et de l'affichage.
        </p>
      </div>

      {/* Language Switcher Setting Box */}
      <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 p-6 space-y-4">
        <div>
          <h3 className="text-base font-bold text-white">{t('settings.language')}</h3>
          <p className="text-xs text-slate-400 mt-0.5">{t('settings.language_desc')}</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {languages.map((item) => (
            <button
              key={item.code}
              onClick={() => setLanguage(item.code)}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                language === item.code
                  ? 'bg-[#0B61DF] border-blue-400 text-white font-bold shadow-md'
                  : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-xl">{item.flag}</span>
                <span className="text-xs">{item.nativeName}</span>
              </div>
              {language === item.code && (
                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded">Actif</span>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
