import React, { useState, useEffect } from 'react';
import { useI18n } from '../i18n';
import { ApiHealthCheck } from '../components/ApiHealthCheck';
import { Campaign, Match, Transaction, AdPlacement, AdCtaType } from '../types';
import {
  Shield,
  Megaphone,
  Calendar,
  Users,
  CreditCard,
  Plus,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  Save,
  X,
  RefreshCw,
  Download,
  AlertTriangle,
  FileText,
  Lock,
  MapPin,
  Activity,
  BarChart3,
  DollarSign,
  TrendingUp,
  Search,
  Filter,
  FileSpreadsheet,
  Flame,
  Radio,
  LocateFixed,
  ShieldAlert,
  Navigation,
  Crosshair,
  ChevronRight,
  Crown,
} from 'lucide-react';

interface AdminViewProps {
  campaigns: Campaign[];
  matches: Match[];
  transactions: Transaction[];
  onSaveCampaign: (campaign: Campaign) => void;
  onDeleteCampaign: (id: string) => void;
  onUpdateMatchResult: (matchId: string, homeScore: number, awayScore: number, scorerId: string) => void;
  onUpdateTransactionStatus: (txId: string, status: any) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  campaigns,
  matches,
  transactions,
  onSaveCampaign,
  onDeleteCampaign,
  onUpdateMatchResult,
  onUpdateTransactionStatus,
}) => {
  const { t, language } = useI18n();

  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'leaderboard_mgmt' | 'matches' | 'ads' | 'withdrawals' | 'audit_logs' | 'privacy_gps' | 'club'
  >('dashboard');

  // Club Challenge Foot Admin State
  const [clubStats, setClubStats] = useState<any | null>(null);
  const [clubSubscribers, setClubSubscribers] = useState<any[]>([]);
  const [clubConfig, setClubConfig] = useState<any | null>(null);
  const [loadingClub, setLoadingClub] = useState(false);
  const [manualActivateUserId, setManualActivateUserId] = useState('');
  const [manualActivateReason, setManualActivateReason] = useState('');
  const [manualActivateDays, setManualActivateDays] = useState(30);
  const [manualActivatePayment, setManualActivatePayment] = useState<'admin_manual' | 'moncash' | 'natcash'>('moncash');
  const [activatingClub, setActivatingClub] = useState(false);
  const [clubActionMsg, setClubActionMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [savingClubConfig, setSavingClubConfig] = useState(false);

  // Real Stats from Server
  const [statsData, setStatsData] = useState<any>(null);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [accessLogs, setAccessLogs] = useState<any[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [leaderboardData, setLeaderboardData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // GPS Live Heatmap & Anti-Fraud State
  const [gpsMapData, setGpsMapData] = useState<any>(null);
  const [selectedGpsZone, setSelectedGpsZone] = useState<any | null>(null);
  const [inspectingPlayer, setInspectingPlayer] = useState<any | null>(null);
  const [gpsInspectReason, setGpsInspectReason] = useState('');
  const [revealedPlayerCoords, setRevealedPlayerCoords] = useState<any | null>(null);
  const [gpsAuditLoading, setGpsAuditLoading] = useState(false);
  const [gpsSubTab, setGpsSubTab] = useState<'heatmap' | 'alerts' | 'policy'>('heatmap');

  // Match Correction Form State
  const [selectedMatchId, setSelectedMatchId] = useState(matches[0]?.id || 'm1');
  const [resHomeScore, setResHomeScore] = useState(2);
  const [resAwayScore, setResAwayScore] = useState(1);
  const [resScorerId, setResScorerId] = useState('');
  const [correctionReason, setCorrectionReason] = useState('');
  const [correctionNotice, setCorrectionNotice] = useState<string | null>(null);

  // Cancellation Modal State (for technical errors only)
  const [cancellationTarget, setCancellationTarget] = useState<any | null>(null);
  const [cancellationReason, setCancellationReason] = useState('');

  // Leaderboard filters
  const [leaderboardTier, setLeaderboardTier] = useState<'bronze' | 'silver' | 'gold'>('bronze');
  const [playerSearch, setPlayerSearch] = useState('');

  // Ad Form Editing State
  const [editingCampaign, setEditingCampaign] = useState<Campaign | null>(null);
  const [showPreview, setShowPreview] = useState(false);

  // 10 Matchs Automatiques Manager State
  const [auto10Data, setAuto10Data] = useState<any | null>(null);
  const [refreshingAuto10, setRefreshingAuto10] = useState(false);
  const [applyingAuto10, setApplyingAuto10] = useState(false);
  const [auto10Msg, setAuto10Msg] = useState<string | null>(null);

  const fetchAuto10Data = () => {
    fetch('/api/football/auto-10')
      .then((r) => r.json())
      .then((res) => {
        if (res.success && res.autoSelectedMatches) {
          setAuto10Data(res.autoSelectedMatches);
        }
      })
      .catch(() => {});
  };

  // Mode de confidentialité & Tests de conformité
  const [privacyMode, setPrivacyMode] = useState<boolean>(true);
  const [togglingPrivacy, setTogglingPrivacy] = useState<boolean>(false);
  const [testResultsData, setTestResultsData] = useState<any | null>(null);
  const [runningTests, setRunningTests] = useState<boolean>(false);

  const fetchAdminSettings = () => {
    fetch('/api/admin/settings')
      .then((r) => r.json())
      .then((res) => {
        if (res.success && res.settings) {
          setPrivacyMode(res.settings.hidePredictionsUntilKickoff);
        }
      })
      .catch(() => {});
  };

  const handleTogglePrivacyMode = async () => {
    setTogglingPrivacy(true);
    try {
      const nextVal = !privacyMode;
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hidePredictionsUntilKickoff: nextVal, adminId: 'u-admin-1' }),
      });
      const data = await res.json();
      if (data.success) {
        setPrivacyMode(nextVal);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setTogglingPrivacy(false);
    }
  };

  const handleRunRulesTests = async () => {
    setRunningTests(true);
    try {
      const res = await fetch('/api/admin/verify-prediction-rules');
      const data = await res.json();
      setTestResultsData(data);
    } catch (e) {
      console.error(e);
    } finally {
      setRunningTests(false);
    }
  };

  const handleRefreshAuto10 = async () => {
    setRefreshingAuto10(true);
    setAuto10Msg(null);
    try {
      const res = await fetch('/api/admin/football/auto-10/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminId: 'u-admin-1' }),
      });
      const json = await res.json();
      if (json.success) {
        setAuto10Data(json.autoSelectedMatches);
        setAuto10Msg(`Succès : ${json.message}`);
        fetchAdminData();
      } else {
        setAuto10Msg(`Erreur : ${json.error}`);
      }
    } catch (err: any) {
      setAuto10Msg('Erreur réseau lors de l\'actualisation.');
    } finally {
      setRefreshingAuto10(false);
    }
  };

  const handleApplyAuto10ToChallenge = async () => {
    if (!window.confirm('Voulez-vous remplacer les matchs du Challenge actif par ces 10 matchs officiels API-Football ?')) {
      return;
    }
    setApplyingAuto10(true);
    setAuto10Msg(null);
    try {
      const res = await fetch('/api/admin/football/auto-10/apply-to-challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminId: 'u-admin-1' }),
      });
      const json = await res.json();
      if (json.success) {
        setAuto10Msg(`Succès : ${json.message}`);
        fetchAdminData();
      } else {
        setAuto10Msg(`Erreur : ${json.error}`);
      }
    } catch (err: any) {
      setAuto10Msg('Erreur lors de l\'application au challenge.');
    } finally {
      setApplyingAuto10(false);
    }
  };

  // Preset images for convenience
  const presetImages = [
    { label: 'Bannière Officielle Stade', url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1200&q=80' },
    { label: 'MonCash & NatCash Mobile', url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Trophée & Ballon d\'Or', url: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=1200&q=80' },
    { label: 'Action Buteur Match', url: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?auto=format&fit=crop&w=1200&q=80' },
  ];

  const fetchAdminData = () => {
    setLoading(true);
    fetchAuto10Data();
    fetchAdminSettings();
    Promise.all([
      fetch('/api/admin/stats').then((r) => r.json()),
      fetch('/api/admin/audit-logs').then((r) => r.json()),
      fetch('/api/admin/access-logs').then((r) => r.json()),
      fetch('/api/admin/users').then((r) => r.json()),
      fetch(`/api/leaderboard?tier=${leaderboardTier}`).then((r) => r.json()),
      fetch('/api/admin/gps-live-map').then((r) => r.json()),
    ])
      .then(([statsRes, auditRes, accessRes, usersRes, leadRes, gpsRes]) => {
        if (statsRes.success) setStatsData(statsRes);
        if (auditRes.success) setAuditLogs(auditRes.auditLogs);
        if (accessRes.success) setAccessLogs(accessRes.accessLogs);
        if (usersRes.success) setAllUsers(usersRes.users);
        if (leadRes.success) setLeaderboardData(leadRes);
        if (gpsRes.success) setGpsMapData(gpsRes);
      })
      .catch((err) => console.error('Admin fetch error', err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchAdminData();
  }, [leaderboardTier]);

  // Handle Match Result Correction with Mandatory Written Reason
  const handleSubmitMatchCorrection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!correctionReason || correctionReason.trim().length < 5) {
      alert('JUSTIFICATION OBLIGATOIRE : Veuillez saisir un motif écrit clair (minimum 5 caractères).');
      return;
    }

    fetch('/api/admin/match-result', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        matchId: selectedMatchId,
        homeScore: resHomeScore,
        awayScore: resAwayScore,
        scorerId: resScorerId,
        adminId: 'u-admin-1',
        reason: correctionReason,
      }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          setCorrectionNotice('Correction enregistrée dans le journal d\'audit et points recalculés côté serveur !');
          setCorrectionReason('');
          onUpdateMatchResult(selectedMatchId, resHomeScore, resAwayScore, resScorerId);
          fetchAdminData();
          setTimeout(() => setCorrectionNotice(null), 4000);
        } else {
          alert(data.error || 'Erreur lors de la correction');
        }
      })
      .catch((err) => alert('Erreur réseau : ' + err.message));
  };

  // Handle Cancellation of a Technical-Error Prediction (Mandatory Reason & Refund)
  const handleConfirmCancellation = () => {
    if (!cancellationTarget) return;
    if (!cancellationReason || cancellationReason.trim().length < 8) {
      alert('JUSTIFICATION OBLIGATOIRE : Un motif technique documenté est requis (min 8 caractères).');
      return;
    }

    fetch('/api/admin/cancel-prediction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        predictionId: cancellationTarget.id,
        adminId: 'u-admin-1',
        reason: cancellationReason,
      }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          alert('Participation annulée. Remboursement automatique effectué et consigné dans le journal d\'audit.');
          setCancellationTarget(null);
          setCancellationReason('');
          fetchAdminData();
        } else {
          alert(data.error);
        }
      })
      .catch((err) => alert('Erreur : ' + err.message));
  };

  // Handle User Block / Unblock
  const handleToggleBlockUser = (userId: string, isBlocked: boolean) => {
    const reason = prompt(
      isBlocked
        ? 'Motif obligatoire du blocage (fraude, multi-compte, etc.) :'
        : 'Motif du déblocage :'
    );
    if (!reason || reason.trim().length < 4) {
      alert('Action annulée : un motif écrit est obligatoire.');
      return;
    }

    fetch('/api/admin/users/block-toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, isBlocked, reason, adminId: 'u-admin-1' }),
    })
      .then((r) => r.json())
      .then((d) => {
        if (d.success) {
          alert(`Statut mis à jour et archivé dans le journal d'audit.`);
          fetchAdminData();
        }
      });
  };

  // Handle Withdrawal Decision
  const handleWithdrawalDecision = (txId: string, status: 'confirmed' | 'rejected') => {
    let rejectionReason = '';
    if (status === 'rejected') {
      rejectionReason = prompt('Motif obligatoire du rejet de retrait :') || '';
      if (!rejectionReason || rejectionReason.trim().length < 4) {
        alert('Action annulée : un motif écrit est obligatoire pour rejeter un retrait.');
        return;
      }
    }

    fetch('/api/admin/withdrawals/decide', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ txId, status, rejectionReason, adminId: 'u-admin-1' }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          onUpdateTransactionStatus(txId, status);
          fetchAdminData();
        }
      });
  };

  // Handle GPS Individual Player Inspection with Mandatory Written Audit Log
  const handleInspectPlayerGps = () => {
    if (!inspectingPlayer) return;
    if (!gpsInspectReason || gpsInspectReason.trim().length < 6) {
      alert('JUSTIFICATION D\'AUDIT OBLIGATOIRE : Veuillez saisir un motif d\'enquête précis (min 6 caractères).');
      return;
    }
    setGpsAuditLoading(true);
    fetch('/api/admin/audit-gps-access', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adminId: 'u-admin-1',
        targetPlayerId: inspectingPlayer.id,
        targetPlayerName: inspectingPlayer.name,
        zoneName: selectedGpsZone?.name || 'Haïti',
        reason: gpsInspectReason,
      }),
    })
      .then((r) => r.json())
      .then((res) => {
        if (res.success) {
          setRevealedPlayerCoords(inspectingPlayer.coords);
          // Refresh audit logs so this action appears immediately in audit view
          fetch('/api/admin/audit-logs')
            .then((r) => r.json())
            .then((ar) => {
              if (ar.success) setAuditLogs(ar.auditLogs);
            });
        } else {
          alert(res.error || 'Erreur lors de la validation d\'accès.');
        }
      })
      .catch((err) => alert('Erreur : ' + err.message))
      .finally(() => setGpsAuditLoading(false));
  };

  const handleClosePlayerInspection = () => {
    setInspectingPlayer(null);
    setGpsInspectReason('');
    setRevealedPlayerCoords(null);
  };

  const selectedMatch = matches.find((m) => m.id === selectedMatchId) || matches[0];

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-6 sm:py-8 space-y-6">
      {/* 1. Header & Navigation */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Console d'Administration & Traçabilité Officielle
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              Serveur Connecté & Authentifié
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Administration & Contrôle Challenge Foot
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Statistiques temps réel, gestion du classement officiel, corrections contrôlées et journal d'audit immuable.
          </p>
        </div>

        {/* Refresh Action */}
        <button
          onClick={fetchAdminData}
          disabled={loading}
          className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-200 flex items-center gap-2 cursor-pointer self-start lg:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-blue-400' : ''}`} />
          <span>Actualiser les données</span>
        </button>
      </div>

      {/* 2. Admin Navigation Tabs */}
      <div className="flex border-b border-slate-800 gap-2 overflow-x-auto text-xs font-bold pb-2">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
            activeTab === 'dashboard'
              ? 'bg-[#0B61DF] text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Statistiques Temps Réel</span>
        </button>

        <button
          onClick={() => setActiveTab('leaderboard_mgmt')}
          className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
            activeTab === 'leaderboard_mgmt'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-amber-300" />
          <span>Gestion du Classement</span>
        </button>

        <button
          onClick={() => setActiveTab('matches')}
          className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
            activeTab === 'matches'
              ? 'bg-[#0B61DF] text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Saisie des Résultats</span>
        </button>

        <button
          onClick={() => setActiveTab('audit_logs')}
          className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
            activeTab === 'audit_logs'
              ? 'bg-purple-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Journal d'Audit Immuable</span>
        </button>

        <button
          onClick={() => setActiveTab('withdrawals')}
          className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
            activeTab === 'withdrawals'
              ? 'bg-[#0B61DF] text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>Retraits ({transactions.filter((t) => t.type === 'withdrawal' && t.status === 'processing').length})</span>
        </button>

        <button
          onClick={() => setActiveTab('ads')}
          className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
            activeTab === 'ads'
              ? 'bg-[#0B61DF] text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          <span>Publicité ({campaigns.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('privacy_gps')}
          className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
            activeTab === 'privacy_gps'
              ? 'bg-emerald-600 text-white shadow-md ring-2 ring-emerald-400/40'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Flame className="w-4 h-4 text-amber-300" />
          <span>Carte GPS en Direct & Anti-Fraude</span>
          <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-red-500/20 text-red-300 border border-red-500/30">
            2 alertes
          </span>
        </button>
      </div>

      {/* ========================================================
          TAB 1: SECTION 9BIS - STATISTIQUES UTILISATEURS TEMPS RÉEL & SANTÉ SYSTÈME
          ======================================================== */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6 animate-fade-in">
          {/* Health-check component for Backend reachability & API_FOOTBALL_KEY configuration */}
          <ApiHealthCheck />

          {/* Key Metrics Grid */}
          {statsData && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5 text-xs">
            {/* Total Accounts */}
            <div className="p-4 rounded-2xl bg-[#0D1C34] border border-blue-500/30 space-y-1">
              <span className="text-slate-400 font-medium">Comptes Utilisateurs</span>
              <p className="text-2xl font-black text-white font-mono">
                {statsData.accounts.total}
              </p>
              <div className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                <span>{statsData.accounts.verifiedPhones} vérifiés</span>
                <span className="text-slate-500">·</span>
                <span className="text-slate-400">{statsData.accounts.unverifiedPhones} en attente</span>
              </div>
            </div>

            {/* Inscriptions Today / Week */}
            <div className="p-4 rounded-2xl bg-[#0D1C34] border border-blue-500/30 space-y-1">
              <span className="text-slate-400 font-medium">Nouvelles Inscriptions</span>
              <p className="text-2xl font-black text-[#38BDF8] font-mono">
                +{statsData.accounts.newThisWeek}
              </p>
              <span className="text-[10px] text-slate-400">
                Aujourd'hui : +{statsData.accounts.newToday} · Ce mois : +{statsData.accounts.newThisMonth}
              </span>
            </div>

            {/* Entrées Financières Totales */}
            <div className="p-4 rounded-2xl bg-[#0D1C34] border border-emerald-500/30 space-y-1">
              <span className="text-slate-400 font-medium">Entrées Hebdomadaires</span>
              <p className="text-2xl font-black text-emerald-400 font-mono">
                {statsData.finances.totalWeeklyEntries.toLocaleString()} HTG
              </p>
              <span className="text-[10px] text-slate-400 font-mono">
                Bronze: {statsData.finances.bronzeEntries} | Silver: {statsData.finances.silverEntries} | Gold: {statsData.finances.goldEntries}
              </span>
            </div>

            {/* Commission Opérateur 40% & 35% */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-950/40 via-[#0D1C34] to-[#0D1C34] border border-amber-500/40 space-y-1">
              <span className="text-amber-300 font-medium">Commissions Opérateur</span>
              <p className="text-2xl font-black text-amber-400 font-mono">
                {statsData.finances.operatorCommission.total.toLocaleString()} HTG
              </p>
              <span className="text-[10px] text-slate-300">
                Standard: 40% ({statsData.finances.operatorCommission.standard40} HTG) | Gold: 35% ({statsData.finances.operatorCommission.gold35} HTG)
              </span>
            </div>
          </div>

          {/* Activity Breakdown & Security Alerts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Breakdown by Tier */}
            <div className="p-5 rounded-2xl bg-[#0D1C34] border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-400" />
                <span>Activité & Répartition des Joueurs par Catégorie</span>
              </h3>
              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Bronze (100 HTG)</span>
                    <strong className="text-white font-mono">{statsData.activity.breakdown.bronze} participations</strong>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                    <div className="bg-amber-600 h-full rounded-full" style={{ width: '60%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Silver (250 HTG)</span>
                    <strong className="text-white font-mono">{statsData.activity.breakdown.silver} participations</strong>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                    <div className="bg-slate-300 h-full rounded-full" style={{ width: '25%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Gold (500 HTG)</span>
                    <strong className="text-white font-mono">{statsData.activity.breakdown.gold} participations</strong>
                  </div>
                  <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                    <div className="bg-yellow-400 h-full rounded-full" style={{ width: '15%' }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Security Alerts (Real-time detection) */}
            <div className="p-5 rounded-2xl bg-[#0D1C34] border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Alertes de Sécurité & Fraude</span>
                </span>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-mono">
                  {statsData.alerts.length} événements
                </span>
              </h3>

              <div className="space-y-2.5 max-h-56 overflow-y-auto text-xs">
                {statsData.alerts.map((al: any) => (
                  <div
                    key={al.id}
                    className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-start justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <span className="font-bold text-white block">{al.description}</span>
                      <p className="text-[11px] text-slate-400">{al.details}</p>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(al.createdAt).toLocaleString('fr-FR')}
                      </span>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0">
                      Vérifié
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )}

      {/* ========================================================
          TAB 2: SECTION 11 - GESTION COMPLÈTE DU CLASSEMENT
          ======================================================== */}
      {activeTab === 'leaderboard_mgmt' && (
        <div className="space-y-6 animate-fade-in">
          <div className="p-5 rounded-3xl bg-[#0D1C34] border border-amber-500/40 space-y-4 shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div>
                <span className="text-[11px] font-bold uppercase text-amber-400 tracking-wider">
                  Section 11 · Gestion Officielle du Classement
                </span>
                <h2 className="text-lg font-black text-white">
                  Contrôle du Classement Réel & Recalcul Côté Serveur
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Connecté à la base de données persistante de Challenge Foot. Toute correction exige une justification écrite consignée dans le journal d'audit.
                </p>
              </div>

              {/* Tier Switcher for Leaderboard */}
              <div className="flex items-center gap-1.5 bg-slate-900 p-1.5 rounded-2xl border border-slate-700 text-xs">
                <button
                  onClick={() => setLeaderboardTier('bronze')}
                  className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer transition-all ${
                    leaderboardTier === 'bronze' ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Bronze (100 HTG)
                </button>
                <button
                  onClick={() => setLeaderboardTier('silver')}
                  className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer transition-all ${
                    leaderboardTier === 'silver' ? 'bg-slate-300 text-black shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Silver (250 HTG)
                </button>
                <button
                  onClick={() => setLeaderboardTier('gold')}
                  className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer transition-all ${
                    leaderboardTier === 'gold' ? 'bg-yellow-400 text-black shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Gold (500 HTG)
                </button>
              </div>
            </div>

            {/* Financial Overview of Category */}
            {leaderboardData && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs pt-1">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-400 block">Participants Classés</span>
                  <strong className="text-lg font-mono text-white">{leaderboardData.participantsCount}</strong>
                </div>
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-400 block">Total Entrées</span>
                  <strong className="text-lg font-mono text-[#38BDF8]">{leaderboardData.totalCollected?.toLocaleString()} HTG</strong>
                </div>
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-400 block">Part Opérateur</span>
                  <strong className="text-lg font-mono text-amber-400">{leaderboardData.ownerShare?.toLocaleString()} HTG</strong>
                </div>
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-400 block">Fonds 5 Gagnants (60%)</span>
                  <strong className="text-lg font-mono text-emerald-400">{leaderboardData.winnersFund?.toLocaleString()} HTG</strong>
                </div>
              </div>
            )}

            {/* Absolute Rule Banner */}
            <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
              <Lock className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
              <div>
                <strong>RÈGLE ABSOLUE DE SÉCURITÉ :</strong> Aucun administrateur ne peut modifier le pronostic d'un joueur après la clôture officielle. Si une anomalie technique est avérée, l'administrateur peut uniquement <em>annuler la participation</em> avec un motif écrit obligatoire, ce qui déclenche automatiquement le remboursement traçable des frais d'entrée.
              </div>
            </div>
          </div>

          {/* Ranked Players Table */}
          <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 overflow-hidden shadow-xl space-y-0">
            <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-blue-400" />
                  <span>Joueurs Classés — Catégorie {leaderboardTier.toUpperCase()}</span>
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                  <input
                    type="text"
                    value={playerSearch}
                    onChange={(e) => setPlayerSearch(e.target.value)}
                    placeholder="Filtrer par nom ou #ID..."
                    className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none w-48"
                  />
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase text-[10px] font-bold">
                  <tr>
                    <th className="py-3 px-4">Rang</th>
                    <th className="py-3 px-4">Participant</th>
                    <th className="py-3 px-4 text-center">Total Points</th>
                    <th className="py-3 px-4 text-center">Nòt Egzak (10pts)</th>
                    <th className="py-3 px-4 text-center">Bon 1X2 (3pts)</th>
                    <th className="py-3 px-4 text-center">Bonus Buteur</th>
                    <th className="py-3 px-4 text-center">Statut</th>
                    <th className="py-3 px-4 text-right">Prix Gagné</th>
                    <th className="py-3 px-4 text-center">Action Admin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {leaderboardData?.participants
                    ?.filter((p: any) =>
                      p.userName.toLowerCase().includes(playerSearch.toLowerCase()) ||
                      p.participantNumber.toLowerCase().includes(playerSearch.toLowerCase())
                    )
                    .map((p: any) => {
                      const isWinner = p.rank <= 5;
                      return (
                        <tr key={p.id} className={`hover:bg-slate-800/40 transition-colors ${isWinner ? 'bg-yellow-500/5' : ''}`}>
                          <td className="py-3 px-4 font-mono font-bold">
                            {p.rank === 1 ? '🥇 1' : p.rank === 2 ? '🥈 2' : p.rank === 3 ? '🥉 3' : `#${p.rank}`}
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-bold text-white block">{p.userName}</span>
                            <span className="font-mono text-[10px] text-[#38BDF8]">{p.participantNumber}</span>
                          </td>
                          <td className="py-3 px-4 text-center font-mono font-black text-sm text-white">
                            {p.totalPoints} pts
                          </td>
                          <td className="py-3 px-4 text-center font-mono text-emerald-400 font-bold">
                            {p.exactScoresCount}
                          </td>
                          <td className="py-3 px-4 text-center font-mono text-blue-300">
                            {p.correctOutcomesCount}
                          </td>
                          <td className="py-3 px-4 text-center font-mono text-amber-300 font-semibold">
                            +{p.scorerBonus} pts
                          </td>
                          <td className="py-3 px-4 text-center">
                            {isWinner ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-yellow-500/20 text-yellow-300 border border-yellow-500/40">
                                Gagnant Top 5
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] text-slate-400 bg-slate-900 border border-slate-800">
                                Classé
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                            {p.prizeWon > 0 ? `${p.prizeWon.toLocaleString()} HTG` : '—'}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => {
                                setCancellationTarget(p);
                                setCancellationReason('');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-red-600/20 hover:bg-red-600/40 text-red-300 border border-red-500/30 text-[11px] font-semibold cursor-pointer"
                              title="Annulation exceptionnelle pour incident technique avec motif obligatoire et remboursement"
                            >
                              Annuler Participation
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 3: SECTION 11.B - SAISIE & CORRECTION DES RÉSULTATS + AUTO-10
          ======================================================== */}
      {activeTab === 'matches' && (
        <div className="space-y-6">
          {/* Card 1: GESTIONNAIRE DES 10 MATCHS AUTOMATIQUES (API-FOOTBALL) */}
          <div className="rounded-2xl bg-gradient-to-r from-[#0D1C34] via-[#0B254E] to-[#0D1C34] border border-blue-500/40 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <span className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
                  <Sparkles className="w-5 h-5" />
                </span>
                <div>
                  <h2 className="text-lg font-black text-white flex items-center gap-2">
                    <span>10 Matchs Choisis Automatiquement (API-Football)</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      Générateur Officiel
                    </span>
                  </h2>
                  <p className="text-xs text-slate-300">
                    Système automatisé de détection des 10 affiches à venir dans les grandes compétitions européennes.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleRefreshAuto10}
                  disabled={refreshingAuto10}
                  className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer active:scale-95 shadow-md"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${refreshingAuto10 ? 'animate-spin' : ''}`} />
                  <span>{refreshingAuto10 ? 'Sélection en cours...' : 'Générer / Rafraîchir les 10 Matchs'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleApplyAuto10ToChallenge}
                  disabled={applyingAuto10 || !auto10Data?.matches?.length}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer active:scale-95 shadow-md disabled:opacity-50"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{applyingAuto10 ? 'Application...' : 'Appliquer au Challenge en Cours'}</span>
                </button>
              </div>
            </div>

            {auto10Msg && (
              <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{auto10Msg}</span>
              </div>
            )}

            {/* Criteria & Current 10 Matches List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>
                  Grille active : <strong>{auto10Data?.count || 0} match(s)</strong> enregistrés pour le {auto10Data?.date || 'Aujourd’hui'}
                </span>
                {auto10Data?.generatedAt && (
                  <span className="font-mono text-[11px] text-slate-500">
                    Générée le {new Date(auto10Data.generatedAt).toLocaleString()}
                  </span>
                )}
              </div>

              {auto10Data?.matches && auto10Data.matches.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
                  {auto10Data.matches.map((m: any, idx: number) => (
                    <div
                      key={m.id || idx}
                      className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-[10px] text-[#38BDF8] font-bold">
                        <span>#{idx + 1} {m.competition}</span>
                        <span className="font-mono text-slate-400">
                          {m.kickoffTime ? new Date(m.kickoffTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'NS'}
                        </span>
                      </div>
                      <div className="font-bold text-white text-[11px] truncate">
                        {m.homeTeam} vs {m.awayTeam}
                      </div>
                      <div className="text-[9px] text-slate-500 font-mono truncate">
                        API ID: #{m.apiFixtureId || m.id}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400">
                  Cliquez sur « Générer / Rafraîchir les 10 Matchs » pour lancer la détection automatique API-Football.
                </div>
              )}
            </div>
          </div>

          {/* Card 1B: MODE CONFIDENTIALITÉ & AUDIT DE CONFORMITÉ DES RÈGLES */}
          <div className="rounded-2xl bg-[#0D1C34] border border-blue-500/30 p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white flex items-center gap-2">
                    <span>Mode de Confidentialité & Équité des Pronostics</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
                      Règle Concours
                    </span>
                  </h2>
                  <p className="text-xs text-slate-300">
                    Configuration de la visibilité des pronostics entre participants pour garantir l'intégrité du concours.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleTogglePrivacyMode}
                  disabled={togglingPrivacy}
                  className={`px-4 py-2.5 rounded-xl font-black text-xs flex items-center gap-2 transition cursor-pointer shadow-md ${
                    privacyMode
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                      : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                  }`}
                >
                  {togglingPrivacy ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : privacyMode ? (
                    <EyeOff className="w-4 h-4 text-amber-400" />
                  ) : (
                    <Eye className="w-4 h-4 text-emerald-400" />
                  )}
                  <span>
                    {privacyMode
                      ? 'Actif : Masqué jusqu\'au coup d\'envoi'
                      : 'Inactif : Visible en temps réel'}
                  </span>
                </button>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#060D19] border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p>
                  <strong>Principe d'équité :</strong> Lorsque ce mode est actif, aucun joueur ne peut copier les pronostics d'autres participants avant le coup d'envoi. Dès que le coup d'envoi officiel du match est donné, tous les pronostics deviennent automatiquement publics en lecture seule.
                </p>
                <p className="text-slate-400 text-[11px]">
                  En tant qu'administrateur, vous conservez toujours l'accès intégral à tous les pronostics enregistrés en base de données.
                </p>
              </div>
            </div>

            {/* Verification of the 6 mandatory tests */}
            <div className="pt-3 border-t border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Contrôle Automatique des 6 Règles Obligatoires</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Vérification serveur des règles de sélection, de fermeture automatique et d'anti-fraude
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleRunRulesTests}
                  disabled={runningTests}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${runningTests ? 'animate-spin' : ''}`} />
                  <span>{runningTests ? 'Vérification...' : 'Lancer le Test de Conformité'}</span>
                </button>
              </div>

              {testResultsData && (
                <div className="space-y-2 p-3.5 rounded-xl bg-[#060D19] border border-slate-800">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
                    <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{testResultsData.allPassed ? '100% DES RÈGLES VALIDÉES AVEC SUCCÈS' : 'ATTENTION REQUISE'}</span>
                    </span>
                    <span className="font-mono text-[10px] text-slate-400">
                      Vérifié à {new Date(testResultsData.verifiedAt).toLocaleTimeString()}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {(testResultsData.results || []).map((t: any, idx: number) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-slate-900 border border-slate-800/80 space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-[11px] truncate flex items-center gap-1.5">
                            <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-[10px] flex items-center justify-center shrink-0">
                              ✓
                            </span>
                            <span>{t.name}</span>
                          </span>
                          <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 shrink-0">
                            PASSÉ
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 pl-5">
                          {t.details}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Card 2: SAISIE & CORRECTION DES RÉSULTATS */}
          <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 p-6 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-blue-400" />
                  <span>Saisie & Correction Manuelle des Résultats avec Justification Obligatoire</span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Validez le score final et le buteur officiel pour recalculer instantanément les points des participants (10pts score, 3pts 1X2, 5pts buteur).
                </p>
              </div>
            </div>

            {correctionNotice && (
              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{correctionNotice}</span>
              </div>
            )}

          <form onSubmit={handleSubmitMatchCorrection} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Sélectionner le match à certifier :
              </label>
              <select
                value={selectedMatchId}
                onChange={(e) => setSelectedMatchId(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-bold focus:border-blue-500 focus:outline-none"
              >
                {matches.map((m) => (
                  <option key={m.id} value={m.id}>
                    #{m.matchNumber} {m.homeTeam} vs {m.awayTeam} ({m.competition})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Score {selectedMatch.homeTeam} (Domicile)
                </label>
                <input
                  type="number"
                  min="0"
                  value={resHomeScore}
                  onChange={(e) => setResHomeScore(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-center font-bold text-base focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Score {selectedMatch.awayTeam} (Extérieur)
                </label>
                <input
                  type="number"
                  min="0"
                  value={resAwayScore}
                  onChange={(e) => setResAwayScore(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-center font-bold text-base focus:border-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Buteur Officiel du Match (Bonus +5 pts) :
              </label>
              <select
                value={resScorerId}
                onChange={(e) => setResScorerId(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-blue-500 focus:outline-none"
              >
                <option value="">Aucun buteur / Match 0-0</option>
                {[...selectedMatch.homePlayers, ...selectedMatch.awayPlayers].map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.team}) - [{p.position}]
                  </option>
                ))}
              </select>
            </div>

            {/* MANDATORY WRITTEN JUSTIFICATION */}
            <div>
              <label className="block text-xs font-semibold text-amber-300 mb-1 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-amber-400" />
                <span>Motif / Justification écrite obligatoire (Traçabilité Journal d'Audit) :</span>
              </label>
              <textarea
                rows={2}
                value={correctionReason}
                onChange={(e) => setCorrectionReason(e.target.value)}
                placeholder="Exemple : Feuille de match officielle UEFA validée, score final certifié après prolongation..."
                className="w-full p-2.5 rounded-xl bg-slate-900 border border-amber-500/50 text-white text-xs placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs sm:text-sm transition-all shadow-lg active:scale-98 cursor-pointer flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Valider le Résultat & Recalculer le Classement Automatiquement</span>
            </button>
          </form>
        </div>
      </div>
    )}

      {/* ========================================================
          TAB 4: SECTION 9BIS.C & D - JOURNAL D'AUDIT APPEND-ONLY
          ======================================================== */}
      {activeTab === 'audit_logs' && (
        <div className="space-y-6 animate-fade-in">
          <div className="p-5 rounded-3xl bg-[#0D1C34] border border-purple-500/40 space-y-3 shadow-xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-purple-400" />
                <h2 className="text-lg font-bold text-white">
                  Journal d'Audit Interne Append-Only (Immuable)
                </h2>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Protégé Côté Serveur · Non Modifiable
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Chaque correction, recalcul de points, annulation technique ou décision financière produit une entrée horodatée avec son motif obligatoire. Les entrées ne peuvent être ni modifiées ni supprimées depuis l'interface administrateur.
            </p>
          </div>

          <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 uppercase text-[10px] font-bold">
                  <tr>
                    <th className="py-3 px-4">Date & Heure</th>
                    <th className="py-3 px-4">Administrateur</th>
                    <th className="py-3 px-4">Type d'Opération</th>
                    <th className="py-3 px-4">Valeur Avant &gt; Après</th>
                    <th className="py-3 px-4">Motif Justificatif Obligatoire</th>
                    <th className="py-3 px-4 text-right">IP Source</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {auditLogs.map((log: any) => (
                    <tr key={log.id} className="hover:bg-slate-800/40">
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                        {new Date(log.timestamp).toLocaleString('fr-FR')}
                      </td>
                      <td className="py-3 px-4 font-bold text-white">
                        {log.adminName}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-500/20 text-[#38BDF8] border border-blue-500/30">
                          {log.actionType}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[11px]">
                        <span className="text-slate-400">{log.previousValue}</span>
                        <span className="text-slate-500 mx-1">→</span>
                        <span className="text-emerald-400 font-semibold">{log.newValue}</span>
                      </td>
                      <td className="py-3 px-4 text-[11px] text-amber-200">
                        {log.reason}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-[10px] text-slate-500">
                        {log.ipAddress}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 5: RETRAITS MONCASH & NATCASH
          ======================================================== */}
      {activeTab === 'withdrawals' && (
        <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 overflow-hidden shadow-xl space-y-0">
          <div className="p-5 border-b border-slate-800 flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-amber-400" />
              <span>Demandes de Retrait MonCash & NatCash en Attente</span>
            </h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/70 border-b border-slate-800 text-slate-400 uppercase text-[10px] font-bold">
                <tr>
                  <th className="py-3 px-4">Date & Réf</th>
                  <th className="py-3 px-4">Utilisateur / Tél</th>
                  <th className="py-3 px-4">Méthode</th>
                  <th className="py-3 px-4 text-center">Statut Actuel</th>
                  <th className="py-3 px-4 text-right">Montant</th>
                  <th className="py-3 px-4 text-right">Action Admin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {transactions
                  .filter((t) => t.type === 'withdrawal')
                  .map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-mono text-[11px]">
                        {tx.referenceId}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-bold text-white">{tx.description}</p>
                      </td>
                      <td className="py-3 px-4 font-bold uppercase text-[11px]">
                        {tx.method}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                            tx.status === 'confirmed'
                              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                              : tx.status === 'rejected'
                              ? 'bg-red-500/20 text-red-400 border-red-500/30'
                              : 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                          }`}
                        >
                          {tx.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-amber-400">
                        {tx.amount.toLocaleString()} HTG
                      </td>
                      <td className="py-3 px-4 text-right space-x-2">
                        {tx.status === 'processing' && (
                          <>
                            <button
                              onClick={() => handleWithdrawalDecision(tx.id, 'confirmed')}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold cursor-pointer"
                            >
                              Approuver
                            </button>
                            <button
                              onClick={() => handleWithdrawalDecision(tx.id, 'rejected')}
                              className="px-2.5 py-1 rounded-lg bg-red-600/30 hover:bg-red-600/50 text-red-300 text-[11px] font-semibold cursor-pointer"
                            >
                              Rejeter (Motif)
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 6: PUBLICITÉ CHALLENGE FOOT (PRESERVED)
          ======================================================== */}
      {activeTab === 'ads' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-[#38BDF8]" />
              <span>Gestion des Publicités Challenge Foot</span>
            </h2>
            <button
              onClick={() => {
                setEditingCampaign({
                  id: `camp-${Date.now()}`,
                  title: {
                    fr: 'Nouvelle Campagne Challenge Foot',
                    ht: 'Nouvo Kanpay Challenge Foot',
                    en: 'New Challenge Foot Campaign',
                  },
                  description: {
                    fr: 'Participez au concours et prouvez vos connaissances !',
                    ht: 'Patisipe nan konkou a epi pwouve konesans ou!',
                    en: 'Enter the contest and prove your football skills!',
                  },
                  imageUrl: presetImages[0].url,
                  targetUrl: '/challenges',
                  ctaType: 'challenge',
                  ctaCustomLabel: {
                    fr: 'Participer',
                    ht: 'Patisipe',
                    en: 'Enter',
                  },
                  placement: 'both',
                  startDate: new Date().toISOString().split('T')[0],
                  endDate: '2027-12-31',
                  isActive: true,
                  clicks: 0,
                });
                setShowPreview(false);
              }}
              className="px-4 py-2 rounded-xl bg-[#0B61DF] hover:bg-blue-600 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Créer une Publicité</span>
            </button>
          </div>

          {editingCampaign && (
            <div className="rounded-2xl bg-[#0D1C34] border border-blue-500/50 p-6 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <h3 className="text-sm font-bold text-white">Édition de la Publicité</h3>
                <button
                  onClick={() => setEditingCampaign(null)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Titre (Français) :</label>
                  <input
                    type="text"
                    value={editingCampaign.title.fr}
                    onChange={(e) =>
                      setEditingCampaign({
                        ...editingCampaign,
                        title: { ...editingCampaign.title, fr: e.target.value },
                      })
                    }
                    className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Description (Français) :</label>
                  <textarea
                    rows={2}
                    value={editingCampaign.description.fr}
                    onChange={(e) =>
                      setEditingCampaign({
                        ...editingCampaign,
                        description: { ...editingCampaign.description, fr: e.target.value },
                      })
                    }
                    className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">URL de l'Image :</label>
                  <input
                    type="text"
                    value={editingCampaign.imageUrl}
                    onChange={(e) =>
                      setEditingCampaign({ ...editingCampaign, imageUrl: e.target.value })
                    }
                    className="w-full p-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono text-[11px]"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      onSaveCampaign(editingCampaign);
                      setEditingCampaign(null);
                    }}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold cursor-pointer"
                  >
                    Enregistrer la Publicité
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingCampaign(null)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl cursor-pointer"
                  >
                    Annuler
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Campaigns Table */}
          <div className="rounded-2xl bg-[#0D1C34] border border-slate-800 overflow-hidden shadow-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/70 border-b border-slate-800 text-slate-400 uppercase text-[10px] font-bold">
                <tr>
                  <th className="py-3 px-4">Campagne</th>
                  <th className="py-3 px-4">Emplacement</th>
                  <th className="py-3 px-4 text-center">Statut</th>
                  <th className="py-3 px-4 text-center">Clics</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {campaigns.map((camp) => (
                  <tr key={camp.id} className="hover:bg-slate-800/40">
                    <td className="py-3 px-4">
                      <span className="font-bold text-white block">{camp.title.fr || camp.title.ht}</span>
                      <span className="text-[11px] text-slate-400 truncate max-w-xs block">
                        {camp.description.fr || camp.description.ht}
                      </span>
                    </td>
                    <td className="py-3 px-4 uppercase text-[10px] font-mono font-bold text-blue-300">
                      {camp.placement}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          camp.isActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        {camp.isActive ? 'Actif' : 'Inactif'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-bold">
                      {camp.clicks || 0}
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      <button
                        onClick={() => setEditingCampaign(camp)}
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteCampaign(camp.id)}
                        className="p-1 rounded bg-red-600/20 hover:bg-red-600/40 text-red-300 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 7: SECTION 9BIS.C - CARTE GPS EN DIRECT & ANTI-FRAUDE
          ======================================================== */}
      {activeTab === 'privacy_gps' && (
        <div className="space-y-6 animate-fade-in text-xs text-slate-300">
          {/* 1. GUIDING RULE BANNER (Mandatory Founder Directive) */}
          <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-emerald-950/60 via-[#0D1C34] to-blue-950/60 border border-emerald-500/50 shadow-xl space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
                  <Shield className="w-4 h-4" />
                </span>
                <div>
                  <h2 className="text-base font-extrabold text-white tracking-tight flex items-center gap-2">
                    <span>Carte GPS en Direct & Surveillance Anti-Fraude</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Opt-In Actif Uniquement
                    </span>
                  </h2>
                  <p className="text-[11px] text-slate-400">
                    Détection de la fraude multi-comptes et visualisation de la densité territoriale en Haïti.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-lg border border-emerald-800">
                  Fenêtre : 12 Mois Glissants
                </span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-black/40 border border-emerald-500/30 flex items-start gap-2.5 text-emerald-200">
              <ShieldAlert className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <p className="text-[11px] leading-relaxed">
                <strong className="text-white font-bold uppercase tracking-wider">RÈGLE FONDAMENTALE :</strong> La carte sert exclusivement à détecter la fraude et à visualiser la distribution globale des joueurs — <strong>pas à surveiller des individus</strong>. Aucun point individuel n'est affiché par défaut.
              </p>
            </div>
          </div>

          {/* 2. SUB-NAVIGATION FOR GPS TAB */}
          <div className="flex border-b border-slate-800 gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setGpsSubTab('heatmap')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                gpsSubTab === 'heatmap'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Carte de Chaleur (Densité par Zone)</span>
            </button>

            <button
              onClick={() => setGpsSubTab('alerts')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                gpsSubTab === 'alerts'
                  ? 'bg-red-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-300" />
              <span>Alertes Automatiques Autonomes</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-red-950 text-red-200 border border-red-500/50 font-mono">
                {gpsMapData?.automaticAlerts?.length || 2}
              </span>
            </button>

            <button
              onClick={() => setGpsSubTab('policy')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                gpsSubTab === 'policy'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Gouvernance & 12 Mois Glissants</span>
            </button>
          </div>

          {/* 3. AUTOMATIC ALERT BANNER (Active regardless of sub-tab) */}
          {gpsMapData?.automaticAlerts && gpsMapData.automaticAlerts.length > 0 && (
            <div className="p-4 rounded-2xl bg-red-950/40 border border-red-500/50 space-y-3 shadow-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-red-300 font-bold text-xs uppercase tracking-wider">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span>Alertes Détectées Autonomement par le Système (Sans Surveillance Requise)</span>
                </div>
                <span className="text-[10px] font-mono text-red-300 bg-red-900/60 px-2 py-0.5 rounded border border-red-700">
                  {gpsMapData.automaticAlerts.length} Cas Suspects Actifs
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {gpsMapData.automaticAlerts.map((alt: any) => (
                  <div
                    key={alt.id}
                    className="p-3.5 rounded-xl bg-slate-900/90 border border-red-500/30 space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-bold text-white text-xs flex items-center gap-1.5">
                        <span className="text-red-400">●</span>
                        <span>{alt.title}</span>
                      </h4>
                      <span className="text-[10px] font-mono text-red-400 px-1.5 py-0.5 rounded bg-red-950 border border-red-800">
                        {alt.type === 'MULTI_ACCOUNTS_SAME_GPS' ? 'Multi-Comptes (Position Identique)' : 'Incohérence Vitesse'}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      {alt.description}
                    </p>

                    {alt.type === 'MULTI_ACCOUNTS_SAME_GPS' && (
                      <div className="p-2 rounded bg-black/50 border border-slate-800 text-[10px] text-slate-400 space-y-1">
                        <div className="flex justify-between text-slate-300 font-semibold">
                          <span>Localisation commune :</span>
                          <span className="text-amber-400 font-mono">{alt.location}</span>
                        </div>
                        <div className="text-slate-400">
                          Comptes impliqués : <span className="text-slate-300 font-mono">{alt.accounts.join(', ')}</span>
                        </div>
                      </div>
                    )}

                    {alt.type === 'IMPOSSIBLE_TRAVEL_SPEED' && (
                      <div className="p-2 rounded bg-black/50 border border-slate-800 text-[10px] text-slate-400 space-y-1">
                        <div className="flex justify-between">
                          <span>Départ : {alt.origin}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Arrivée : {alt.destination}</span>
                        </div>
                        <div className="flex justify-between text-amber-300 font-mono font-bold">
                          <span>Écart : {alt.timeDelta} ({alt.distanceKm} km)</span>
                          <span className="text-red-400">Vitesse impossible &gt; 3 700 km/h</span>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[10px] text-slate-500">
                        Détecté à {new Date(alt.detectedAt).toLocaleTimeString()}
                      </span>
                      <button
                        onClick={() => {
                          const reason = prompt('Motif obligatoire du verrouillage préventif :');
                          if (reason && reason.trim().length >= 5) {
                            alert('Mesure préventive enregistrée dans le journal d\'audit avec motif.');
                            fetchAdminData();
                          }
                        }}
                        className="px-2.5 py-1 rounded bg-red-600/30 hover:bg-red-600/50 text-red-200 border border-red-500/40 text-[10px] font-bold cursor-pointer transition-colors"
                      >
                        Action Anti-Fraude
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. TAB SUBVIEW: HEATMAP DE DENSITÉ PAR ZONE */}
          {gpsSubTab === 'heatmap' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
                {/* SVG Visual Heatmap Representation */}
                <div className="lg:col-span-7 p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <Flame className="w-4 h-4 text-orange-400" />
                        <span>Carte de Chaleur Territoriale (Heatmap Haïti)</span>
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        Concentration agrégée des joueurs avec consentement GPS actif. Aucun point individuel affiché.
                      </p>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                      Vue Agrégée
                    </span>
                  </div>

                  {/* Interactive SVG Heatmap */}
                  <div className="relative w-full aspect-[16/10] bg-[#050C18] rounded-2xl border border-slate-800 overflow-hidden flex items-center justify-center p-3">
                    {/* SVG Base of Haiti stylized with Density Circles */}
                    <svg viewBox="0 0 800 500" className="w-full h-full">
                      <defs>
                        {/* Radial Gradients for Heatmap Intensity */}
                        <radialGradient id="heatOuest" cx="50%" cy="50%" r="50%">
                          <stop offset="0%" stopColor="#EF4444" stopOpacity="0.85" />
                          <stop offset="40%" stopColor="#F97316" stopOpacity="0.5" />
                          <stop offset="80%" stopColor="#FBBF24" stopOpacity="0.2" />
                          <stop offset="100%" stopColor="#EF4444" stopOpacity="0" />
                        </radialGradient>
                        <radialGradient id="heatNord" cx="50%" cy="50%" r="50%">
                          <stop offset="0%" stopColor="#F97316" stopOpacity="0.8" />
                          <stop offset="50%" stopColor="#FBBF24" stopOpacity="0.4" />
                          <stop offset="100%" stopColor="#F97316" stopOpacity="0" />
                        </radialGradient>
                        <radialGradient id="heatArtibonite" cx="50%" cy="50%" r="50%">
                          <stop offset="0%" stopColor="#FBBF24" stopOpacity="0.7" />
                          <stop offset="60%" stopColor="#38BDF8" stopOpacity="0.3" />
                          <stop offset="100%" stopColor="#FBBF24" stopOpacity="0" />
                        </radialGradient>
                        <radialGradient id="heatSud" cx="50%" cy="50%" r="50%">
                          <stop offset="0%" stopColor="#10B981" stopOpacity="0.7" />
                          <stop offset="60%" stopColor="#0B61DF" stopOpacity="0.3" />
                          <stop offset="100%" stopColor="#10B981" stopOpacity="0" />
                        </radialGradient>
                        <radialGradient id="heatDiaspora" cx="50%" cy="50%" r="50%">
                          <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.7" />
                          <stop offset="60%" stopColor="#6366F1" stopOpacity="0.3" />
                          <stop offset="100%" stopColor="#38BDF8" stopOpacity="0" />
                        </radialGradient>
                      </defs>

                      {/* Stylized Haiti Coastline Path */}
                      <path
                        d="M 280,140 Q 340,110 420,115 T 530,140 Q 560,160 540,180 T 480,210 Q 440,200 400,220 T 360,260 Q 310,270 290,290 T 260,330 Q 240,360 210,380 T 130,420 Q 90,430 70,410 T 110,380 Q 180,360 220,320 T 280,300 Q 320,310 370,300 T 430,310 Q 480,320 520,300 T 560,280 Q 550,250 510,240 T 450,230 Q 390,230 350,200 T 290,180 Z"
                        fill="#0A182E"
                        stroke="#1E293B"
                        strokeWidth="2"
                      />

                      {/* Department Boundaries Outlines */}
                      <line x1="390" y1="120" x2="390" y2="220" stroke="#1E3A5F" strokeDasharray="3,3" />
                      <line x1="330" y1="210" x2="430" y2="310" stroke="#1E3A5F" strokeDasharray="3,3" />
                      <line x1="220" y1="330" x2="280" y2="310" stroke="#1E3A5F" strokeDasharray="3,3" />

                      {/* HEATMAP CIRCLES (Density Aggregates) */}
                      {/* 1. Ouest & Port-au-Prince (CRITICAL / HIGH HEAT: 64%) */}
                      <circle
                        cx="380"
                        cy="305"
                        r="95"
                        fill="url(#heatOuest)"
                        className="animate-pulse cursor-pointer hover:opacity-90"
                        onClick={() => setSelectedGpsZone(gpsMapData?.zones?.find((z: any) => z.id === 'ouest_paup'))}
                      />
                      <circle cx="380" cy="305" r="8" fill="#EF4444" />
                      <text x="380" y="325" fill="#FFFFFF" fontSize="12" fontWeight="bold" textAnchor="middle">
                        Port-au-Prince (64%)
                      </text>
                      <text x="380" y="340" fill="#FCA5A5" fontSize="10" textAnchor="middle">
                        42 Joueurs Opt-In
                      </text>

                      {/* 2. Nord & Cap-Haïtien (HIGH HEAT: 18%) */}
                      <circle
                        cx="450"
                        cy="145"
                        r="60"
                        fill="url(#heatNord)"
                        className="cursor-pointer hover:opacity-90"
                        onClick={() => setSelectedGpsZone(gpsMapData?.zones?.find((z: any) => z.id === 'nord_cap'))}
                      />
                      <circle cx="450" cy="145" r="6" fill="#F97316" />
                      <text x="450" y="165" fill="#FFFFFF" fontSize="11" fontWeight="bold" textAnchor="middle">
                        Cap-Haïtien (18%)
                      </text>

                      {/* 3. Artibonite & Gonaïves (MEDIUM HEAT: 9%) */}
                      <circle
                        cx="330"
                        cy="210"
                        r="45"
                        fill="url(#heatArtibonite)"
                        className="cursor-pointer hover:opacity-90"
                        onClick={() => setSelectedGpsZone(gpsMapData?.zones?.find((z: any) => z.id === 'artibonite_gon'))}
                      />
                      <circle cx="330" cy="210" r="5" fill="#FBBF24" />
                      <text x="330" y="228" fill="#FFFFFF" fontSize="10" fontWeight="bold" textAnchor="middle">
                        Gonaïves (9%)
                      </text>

                      {/* 4. Grand Sud & Les Cayes (LOW HEAT: 4%) */}
                      <circle
                        cx="130"
                        cy="410"
                        r="35"
                        fill="url(#heatSud)"
                        className="cursor-pointer hover:opacity-90"
                        onClick={() => setSelectedGpsZone(gpsMapData?.zones?.find((z: any) => z.id === 'sud_cayes'))}
                      />
                      <circle cx="130" cy="410" r="5" fill="#10B981" />
                      <text x="130" y="430" fill="#FFFFFF" fontSize="10" fontWeight="bold" textAnchor="middle">
                        Les Cayes (4%)
                      </text>

                      {/* 5. Diaspora Hubs (5%) */}
                      <circle
                        cx="680"
                        cy="120"
                        r="40"
                        fill="url(#heatDiaspora)"
                        className="cursor-pointer hover:opacity-90"
                        onClick={() => setSelectedGpsZone(gpsMapData?.zones?.find((z: any) => z.id === 'diaspora_intl'))}
                      />
                      <circle cx="680" cy="120" r="5" fill="#38BDF8" />
                      <text x="680" y="138" fill="#FFFFFF" fontSize="10" fontWeight="bold" textAnchor="middle">
                        Diaspora (5%)
                      </text>
                      <text x="680" y="152" fill="#93C5FD" fontSize="9" textAnchor="middle">
                        USA · Canada · RD
                      </text>
                    </svg>

                    {/* Overlay legend */}
                    <div className="absolute bottom-3 left-3 bg-slate-950/90 border border-slate-800 rounded-xl p-2.5 space-y-1 text-[10px]">
                      <div className="font-bold text-white text-[11px] mb-1">Densité Joueurs Opt-In</div>
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-red-500" />
                        <span className="text-slate-300">Forte concentration (&gt; 50 %)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-orange-500" />
                        <span className="text-slate-300">Moyenne (15 - 49 %)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-emerald-500" />
                        <span className="text-slate-300">Modérée (&lt; 15 %)</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Zone Breakdown & Drill-Down Panel */}
                <div className="lg:col-span-5 p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <LocateFixed className="w-4 h-4 text-emerald-400" />
                        <span>Zones & Densités Régionales</span>
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        Touchez une zone pour explorer sa liste de joueurs consentants.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                    {(gpsMapData?.zones || []).map((zone: any) => {
                      const isSelected = selectedGpsZone?.id === zone.id;
                      return (
                        <div
                          key={zone.id}
                          onClick={() => setSelectedGpsZone(isSelected ? null : zone)}
                          className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#0D1C34] border-emerald-500 ring-2 ring-emerald-500/20'
                              : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span
                                className={`w-3 h-3 rounded-full ${
                                  zone.densityPercent >= 50
                                    ? 'bg-red-500 animate-pulse'
                                    : zone.densityPercent >= 15
                                    ? 'bg-orange-500'
                                    : 'bg-emerald-500'
                                }`}
                              />
                              <div>
                                <span className="font-bold text-white text-xs block">
                                  {zone.name}
                                </span>
                                <span className="text-[10px] text-slate-400">
                                  {zone.subDistricts?.join(', ')}
                                </span>
                              </div>
                            </div>

                            <div className="text-right">
                              <span className="font-mono font-bold text-white text-xs block">
                                {zone.densityPercent} %
                              </span>
                              <span className="text-[10px] text-emerald-400 font-mono">
                                {zone.activeOptInCount} opt-in
                              </span>
                            </div>
                          </div>

                          {/* Selected Zone Drill-Down: Opt-in Players List */}
                          {isSelected && (
                            <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2">
                              <div className="flex items-center justify-between text-[11px]">
                                <span className="text-slate-400 font-semibold">
                                  Joueurs consentants de la zone ({zone.samplePlayers?.length || 0}) :
                                </span>
                                <span className="text-[10px] text-amber-400 font-mono">
                                  Accès individuel consigné à l'audit
                                </span>
                              </div>

                              <div className="space-y-1.5">
                                {(zone.samplePlayers || []).map((p: any) => (
                                  <div
                                    key={p.id}
                                    className="p-2 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2"
                                  >
                                    <div>
                                      <div className="flex items-center gap-1.5">
                                        <span className="font-bold text-white text-[11px]">{p.name}</span>
                                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                                          {p.participantNumber}
                                        </span>
                                        {p.status === 'flagged_multi' && (
                                          <span className="text-[9px] font-bold text-red-400 bg-red-950 px-1 rounded border border-red-800">
                                            Alerte Multi
                                          </span>
                                        )}
                                        {p.status === 'flagged_speed' && (
                                          <span className="text-[9px] font-bold text-amber-400 bg-amber-950 px-1 rounded border border-amber-800">
                                            Téléportation
                                          </span>
                                        )}
                                      </div>
                                      <span className="text-[10px] text-slate-400">
                                        {p.city} · Tier {p.tier?.toUpperCase()} · {p.lastActive}
                                      </span>
                                    </div>

                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setInspectingPlayer(p);
                                        setGpsInspectReason('');
                                        setRevealedPlayerCoords(null);
                                      }}
                                      className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px] flex items-center gap-1 shrink-0 cursor-pointer shadow"
                                    >
                                      <Crosshair className="w-3 h-3 text-cyan-300" />
                                      <span>Position Précise</span>
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 5. TAB SUBVIEW: AUDIT & GOVERNANCE RULES */}
          {gpsSubTab === 'policy' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <Lock className="w-4 h-4 text-emerald-400" />
                  <span>Cycle Glissant 12 Mois (Décision du Fondateur)</span>
                </h3>
                <ul className="space-y-2 text-slate-300 text-[11px] leading-relaxed">
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span><strong>12 Mois Glissants à Renouvellement Automatique :</strong> Chaque jour à 00:00 UTC, les positions GPS de plus de 12 mois sont purgées automatiquement.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span><strong>Cycle Individuel par Joueur :</strong> La fenêtre roulante est calculée indépendamment pour chaque compte à partir de ses propres dates de participation.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span><strong>Révocation Immédiate :</strong> Dès qu'un joueur désactive la localisation dans son profil, la collecte s'arrête instantanément et toutes ses données GPS sont supprimées.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <span><strong>Interdiction de Suivi en Arrière-Plan :</strong> La position n'est relevée qu'au moment de l'accès applicatif. Aucun traçage en arrière-plan sans autorisation spécifique.</span>
                  </li>
                </ul>
              </div>

              <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-blue-400" />
                  <span>Traçabilité des Consultations Administratives</span>
                </h3>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Pour garantir l'intégrité et prévenir tout abus, le système impose une traçabilité totale :
                </p>
                <div className="space-y-2 text-[11px]">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <strong className="text-white block mb-0.5">Motif Écrit Obligatoire</strong>
                    <span className="text-slate-400">L'admin doit consigner la raison d'enquête (soupçon de multi-compte, litige financier) avant d'afficher les coordonnées.</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <strong className="text-white block mb-0.5">Journal d'Audit Immuable</strong>
                    <span className="text-slate-400">L'identifiant admin, le joueur ciblé, l'horodatage exact et le motif sont inscrits dans la table d'audit non supprimable.</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 6. TAB SUBVIEW: ALERTS LIST */}
          {gpsSubTab === 'alerts' && (
            <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400" />
                <span>Règles de Détection Automatique des Cas Suspects</span>
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-950 border border-red-500/30 space-y-2">
                  <div className="flex items-center gap-2 text-red-400 font-bold text-xs">
                    <Users className="w-4 h-4" />
                    <span>Règle 1 : Multi-Comptes Même Position GPS</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">
                    Si <strong>5 comptes ou plus</strong> sont connectés depuis la même position GPS exacte (dans un rayon de moins de 15 mètres), le système déclenche une alerte de syndicat ou ferme de comptes.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-2">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                    <Navigation className="w-4 h-4" />
                    <span>Règle 2 : Villes Incohérentes (Téléportation)</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">
                    Si un joueur se connecte successivement depuis deux villes distantes dans un laps de temps physiquement impossible (ex: Cap-Haïtien puis Port-au-Prince en moins d'une heure), le système signale une usurpation de compte ou utilisation de proxy/VPN.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          MODAL: CONSULTATION INDIVIDUELLE GPS AVEC TRAÇABILITÉ AUDIT
          ======================================================== */}
      {inspectingPlayer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0D1C34] border border-blue-500/50 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 text-blue-400 font-bold text-sm">
                <Crosshair className="w-5 h-5 text-[#38BDF8]" />
                <span>Consultation Exceptionnelle de Position GPS Précise</span>
              </div>
              <button
                onClick={handleClosePlayerInspection}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Privacy Warning */}
            <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-[11px] leading-relaxed">
              <div className="flex items-center gap-1.5 font-bold text-amber-300 mb-1">
                <ShieldAlert className="w-4 h-4" />
                <span>Avertissement Légal & Traçabilité Obligatoire</span>
              </div>
              Conformément à la politique du fondateur, chaque accès à la position exacte d'un joueur est <strong>enregistré de manière permanente dans le journal d'audit immuable</strong> (qui consulte, quand, et pourquoi).
            </div>

            {/* Target Player Card */}
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Joueur ciblé :</span>
                <strong className="text-white">{inspectingPlayer.name} ({inspectingPlayer.participantNumber})</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Téléphone :</span>
                <span className="text-slate-300 font-mono">{inspectingPlayer.phone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Ville déclarée :</span>
                <span className="text-slate-300">{inspectingPlayer.city}</span>
              </div>
            </div>

            {/* Mandatory Reason Input (if coordinates not yet revealed) */}
            {!revealedPlayerCoords ? (
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-white">
                  Motif d'enquête écrit obligatoire (min 6 caractères) :
                </label>
                <textarea
                  rows={3}
                  value={gpsInspectReason}
                  onChange={(e) => setGpsInspectReason(e.target.value)}
                  placeholder="Ex : Enquête anti-fraude signalement multi-comptes Delmas 33..."
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-blue-500/40 text-white text-xs placeholder-slate-500 focus:outline-none"
                />

                <div className="flex items-center gap-2 pt-2">
                  <button
                    onClick={handleInspectPlayerGps}
                    disabled={gpsAuditLoading || gpsInspectReason.trim().length < 6}
                    className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white rounded-xl font-bold text-xs cursor-pointer transition-colors shadow flex items-center justify-center gap-2"
                  >
                    {gpsAuditLoading && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                    <span>Consigner à l'Audit & Révéler la Position</span>
                  </button>
                  <button
                    onClick={handleClosePlayerInspection}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs cursor-pointer"
                  >
                    Annuler
                  </button>
                </div>
              </div>
            ) : (
              /* Coordinates Revealed Display */
              <div className="space-y-3 pt-2">
                <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Accès Consigné à l'Audit Immuable — Coordonnées Révélées</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                    <div className="p-2 rounded bg-black/40 border border-slate-800">
                      <span className="text-slate-400 block">Latitude</span>
                      <strong className="text-white font-mono">{revealedPlayerCoords.lat}° N</strong>
                    </div>
                    <div className="p-2 rounded bg-black/40 border border-slate-800">
                      <span className="text-slate-400 block">Longitude</span>
                      <strong className="text-white font-mono">{revealedPlayerCoords.lng}° O</strong>
                    </div>
                  </div>

                  <div className="text-[10px] text-slate-400 pt-1 flex justify-between">
                    <span>Précision GPS : <strong>± {revealedPlayerCoords.accuracy} mètres</strong></span>
                    <span className="text-emerald-400">Signalé par l'appareil joueur</span>
                  </div>
                </div>

                <button
                  onClick={handleClosePlayerInspection}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-xs cursor-pointer"
                >
                  Fermer
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: ANNULATION TECHNIQUE DE PARTICIPATION (JUSTIFICATION ÉCRITE)
          ======================================================== */}
      {cancellationTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0D1C34] border border-red-500/50 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 text-red-400 font-bold">
                <AlertTriangle className="w-5 h-5" />
                <span>Annulation Technique de Participation</span>
              </div>
              <button
                onClick={() => setCancellationTarget(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <p>
                <strong>Joueur concerné :</strong> {cancellationTarget.userName} ({cancellationTarget.participantNumber})
              </p>
              <p>
                <strong>Catégorie :</strong> {cancellationTarget.tier?.toUpperCase()} ({cancellationTarget.tier === 'gold' ? '500 HTG' : cancellationTarget.tier === 'silver' ? '250 HTG' : '100 HTG'})
              </p>
              <p className="text-[11px] text-amber-300 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20">
                L'annulation remboursera immédiatement le solde du joueur et consigne l'opération dans le journal d'audit immuable.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-white mb-1">
                Motif technique obligatoire (min 8 caractères) :
              </label>
              <textarea
                rows={3}
                value={cancellationReason}
                onChange={(e) => setCancellationReason(e.target.value)}
                placeholder="Exemple : Incident réseau prouvé lors de la validation du ticket, doublon de frais d'entrée..."
                className="w-full p-2.5 rounded-xl bg-slate-900 border border-red-500/40 text-white text-xs placeholder-slate-500 focus:outline-none"
                required
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleConfirmCancellation}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl font-bold text-xs cursor-pointer transition-colors"
              >
                Confirmer l'Annulation & Rembourser
              </button>
              <button
                onClick={() => setCancellationTarget(null)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
